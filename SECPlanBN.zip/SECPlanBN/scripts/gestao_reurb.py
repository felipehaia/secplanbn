# scripts/gestao_reurb.py

import os
import json
from qgis.core import QgsProject, QgsFeature
from qgis.gui import QgsGui
from qgis.utils import iface
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QLineEdit, QLabel, QPushButton, QMenu, QWidgetAction,
    QCheckBox, QMessageBox, QRadioButton, QButtonGroup, QGroupBox,
    QWidget, QListWidget, QAbstractItemView, QFormLayout,
    QToolButton
)

from .analises import carregar_config_analises, executar_analise_urbana
from .gestao_reurb_vinculos import GerenciadorVinculosReurb
from .atualiza_geometria_processos_reurb import atualizar_geometria_processo_por_vinculos

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "preferencias_colunas.txt")
ORDEM_ETAPAS_PATH = os.path.join(os.path.dirname(__file__), "ordem_etapas.txt")


class DialogOrdenacaoEtapas(QDialog):
    """Diálogo interativo com Drag & Drop para ordenar as etapas visualmente."""
    def __init__(self, etapas_existentes, ordem_atual, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configurar Ordem das Etapas")
        self.resize(350, 400)

        layout = QVBoxLayout(self)

        lbl = QLabel("Arraste as etapas para reordenar ou use os botões ao lado:")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        lay_corpo = QHBoxLayout()

        # Lista interativa
        self.list_widget = QListWidget()
        self.list_widget.setDragDropMode(QAbstractItemView.InternalMove)
        self.list_widget.setDefaultDropAction(Qt.MoveAction)

        # Monta a lista combinando a ordem salva com eventuais etapas novas
        ordem_normalizada = [e.upper() for e in ordem_atual]
        todas_etapas = list(ordem_normalizada)

        for e in etapas_existentes:
            if e.upper() not in todas_etapas:
                todas_etapas.append(e.upper())

        for etapa in todas_etapas:
            self.list_widget.addItem(etapa)

        lay_corpo.addWidget(self.list_widget)

        # Botões de mover para cima/baixo
        lay_botoes_lateral = QVBoxLayout()
        btn_up = QPushButton("▲ Subir")
        btn_up.clicked.connect(self.mover_para_cima)
        btn_down = QPushButton("▼ Descer")
        btn_down.clicked.connect(self.mover_para_baixo)

        lay_botoes_lateral.addWidget(btn_up)
        lay_botoes_lateral.addWidget(btn_down)
        lay_botoes_lateral.addStretch()
        lay_corpo.addLayout(lay_botoes_lateral)

        layout.addLayout(lay_corpo)

        # Botões de Ação Inferiores
        lay_acoes = QHBoxLayout()
        lay_acoes.addStretch()

        btn_salvar = QPushButton("💾 Salvar")
        btn_salvar.clicked.connect(self.accept)
        btn_cancelar = QPushButton("Cancelar")
        btn_cancelar.clicked.connect(self.reject)

        lay_acoes.addWidget(btn_salvar)
        lay_acoes.addWidget(btn_cancelar)
        layout.addLayout(lay_acoes)

    def mover_para_cima(self):
        row = self.list_widget.currentRow()
        if row > 0:
            item = self.list_widget.takeItem(row)
            self.list_widget.insertItem(row - 1, item)
            self.list_widget.setCurrentRow(row - 1)

    def mover_para_baixo(self):
        row = self.list_widget.currentRow()
        if row < self.list_widget.count() - 1 and row >= 0:
            item = self.list_widget.takeItem(row)
            self.list_widget.insertItem(row + 1, item)
            self.list_widget.setCurrentRow(row + 1)

    def obter_ordem(self):
        return [self.list_widget.item(i).text() for i in range(self.list_widget.count())]


class DialogAvancarEtapa(QDialog):
    """
    Formulário que utiliza os EditorWidgets nativos configurados na camada do projeto
    (Mapa de Valores, Relação de Valor, Edição de Texto, etc.) para os campos:
    etapa, aos_cuidados e responsavel_prefeitura.
    """
    def __init__(self, layer, feature, lista_etapas_ordenadas, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Avançar Etapa do Processo")
        self.resize(440, 200)

        self.layer = layer
        self.feature = feature
        self.wrappers = {}

        layout = QVBoxLayout(self)
        form = QFormLayout()

        campos_alvo = [
            ("etapa", "Nova Etapa:"),
            ("aos_cuidados", "Aos Cuidados:"),
            ("responsavel_prefeitura", "Responsável Prefeitura:")
        ]

        registry = QgsGui.editorWidgetRegistry()
        fields = self.layer.fields()

        for field_name, label_texto in campos_alvo:
            idx = fields.indexFromName(field_name)
            if idx < 0:
                continue

            # Cria o wrapper do widget exatamente como configurado nas propriedades da camada
            wrapper = registry.create(self.layer, idx, None, self)
            if not wrapper:
                continue

            widget = wrapper.widget()
            wrapper.setFeature(self.feature)

            # Define o valor inicial (para 'etapa', calcula a próxima etapa da sequência)
            valor_atual = self.feature[field_name]
            if field_name == "etapa":
                valor_inicial = self._calcular_proxima_etapa(
                    valor_atual, lista_etapas_ordenadas, idx
                )
            else:
                valor_inicial = valor_atual

            wrapper.setValue(valor_inicial)

            self.wrappers[field_name] = wrapper
            form.addRow(label_texto, widget)

        layout.addLayout(form)

        # Botões de Ação
        lay_acoes = QHBoxLayout()
        lay_acoes.addStretch()

        btn_salvar = QPushButton("💾 Confirmar")
        btn_salvar.clicked.connect(self.accept)
        btn_cancelar = QPushButton("Cancelar")
        btn_cancelar.clicked.connect(self.reject)

        lay_acoes.addWidget(btn_salvar)
        lay_acoes.addWidget(btn_cancelar)
        layout.addLayout(lay_acoes)

    def _calcular_proxima_etapa(self, valor_atual, lista_etapas_ordenadas, field_idx):
        """
        Determina a próxima etapa respeitando ordem_etapas.txt e preservando
        a capitalização/chave original esperada pelo Mapa de Valores da camada.
        """
        etapa_atual_str = str(valor_atual).strip() if valor_atual is not None else ""
        etapa_atual_upper = etapa_atual_str.upper()

        proxima_upper = etapa_atual_upper
        if etapa_atual_upper in lista_etapas_ordenadas:
            pos = lista_etapas_ordenadas.index(etapa_atual_upper)
            if pos + 1 < len(lista_etapas_ordenadas):
                proxima_upper = lista_etapas_ordenadas[pos + 1]
        elif lista_etapas_ordenadas:
            proxima_upper = lista_etapas_ordenadas[0]

        if not proxima_upper:
            return valor_atual

        # Verifica se o campo usa ValueMap para retornar a chave exata configurada no projeto
        setup = self.layer.editorWidgetSetup(field_idx)
        if setup.type() == "ValueMap":
            config_map = setup.config().get("map", [])
            # No QGIS 3+, config["map"] é uma lista de dicts: [{"Descrição": "valor_real"}, ...]
            if isinstance(config_map, list):
                for item in config_map:
                    if isinstance(item, dict):
                        for _, val_real in item.items():
                            if val_real is not None and str(val_real).strip().upper() == proxima_upper:
                                return val_real
            elif isinstance(config_map, dict):
                for _, val_real in config_map.items():
                    if val_real is not None and str(val_real).strip().upper() == proxima_upper:
                        return val_real

        # Se não for ValueMap, tenta preservar a capitalização existente na camada
        for feat in self.layer.getFeatures():
            v = feat[field_idx]
            if v is not None and str(v).strip().upper() == proxima_upper:
                return v

        return proxima_upper

    def obter_valores(self):
        valores = {}
        for field_name, wrapper in self.wrappers.items():
            val = wrapper.value()
            if isinstance(val, str):
                val = val.strip() if val.strip() else None
            valores[field_name] = val
        return valores


class GestaoReurbDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Gestão de Processos REURB")
        self.resize(1250, 680)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinMaxButtonsHint)

        self.layer = None
        layers = QgsProject.instance().mapLayersByName("PROCESSOS_REURB")
        if layers:
            self.layer = layers[0]

        if not self.layer:
            QMessageBox.warning(
                self, "Camada não encontrada",
                "A camada 'PROCESSOS_REURB' não está carregada no projeto atual."
            )
            return

        self.field_names = [field.name() for field in self.layer.fields()]
        self.filter_inputs = []
        self.col_checkboxes = {}
        self.gerenciador_vinculos = GerenciadorVinculosReurb(self, self.layer)

        self.setup_ui()
        self.carregar_dados()
        self.carregar_preferencias()

        if self.layer:
            self.layer.editingStarted.connect(self.atualizar_estado_btn_edicao)
            self.layer.editingStopped.connect(self.atualizar_estado_btn_edicao)

    def _obter_texto_exibicao_campo(self, field_name, val):
        """Retorna o texto formatado conforme o widget do projeto (ex: descrição do Mapa de Valores)."""
        if val is None:
            return ""
        if isinstance(val, bool):
            return "Sim" if val else "Não"

        idx = self.layer.fields().indexFromName(field_name)
        if idx >= 0:
            setup = self.layer.editorWidgetSetup(idx)
            if setup.type() == "ValueMap":
                config_map = setup.config().get("map", [])
                if isinstance(config_map, list):
                    for item in config_map:
                        if isinstance(item, dict):
                            for desc, real_val in item.items():
                                if str(real_val) == str(val):
                                    return str(desc)
                elif isinstance(config_map, dict):
                    for desc, real_val in config_map.items():
                        if str(real_val) == str(val):
                            return str(desc)

        return str(val)

    def atualizar_geometria_elemento(self, feat_id):
        if not self.layer:
            return
        if atualizar_geometria_processo_por_vinculos(self.layer, feat_id, self):
            self.atualizar_estado_btn_edicao()
            self.zoom_elemento(feat_id)

    def setup_ui(self):
        layout = QVBoxLayout(self)

        # --- BARRA SUPERIOR ---
        top_bar = QHBoxLayout()

        self.lbl_titulo = QLabel(f"<b>Processos REURB</b> ({self.layer.featureCount()} registros)")
        top_bar.addWidget(self.lbl_titulo)

        top_bar.addStretch()

        self.btn_toggle_edit = QPushButton("✏️ Alternar Edição")
        self.btn_toggle_edit.setCheckable(True)
        self.btn_toggle_edit.clicked.connect(self.alternar_edicao_camada)
        top_bar.addWidget(self.btn_toggle_edit)

        btn_vinculos = QPushButton("🔗 Vínculos REURB")
        btn_vinculos.setMenu(self.gerenciador_vinculos.criar_menu())
        top_bar.addWidget(btn_vinculos)

        btn_colunas = QPushButton("👁️ Visibilidade das Colunas")
        btn_colunas.setMenu(self.criar_menu_colunas())
        top_bar.addWidget(btn_colunas)

        btn_refresh = QPushButton("🔄 Atualizar Dados")
        btn_refresh.clicked.connect(self.carregar_dados)
        top_bar.addWidget(btn_refresh)

        layout.addLayout(top_bar)
        self.atualizar_estado_btn_edicao()

        # --- FILTROS DE ETAPA E AOS CUIDADOS ---
        lay_filtros_superiores = QHBoxLayout()

        # 1. Filtro por Etapa Dinâmico com Configuração por Engrenagem
        self.grp_etapas = QGroupBox()
        
        lay_grp_etapas_main = QVBoxLayout(self.grp_etapas)
        lay_grp_etapas_main.setContentsMargins(6, 2, 6, 4)

        lay_header_etapas = QHBoxLayout()
        lbl_titulo_etapas = QLabel("<b>Filtrar por Etapa</b>")
        
        btn_config_etapas = QPushButton("⚙️")
        btn_config_etapas.setToolTip("Configurar ordem de exibição das etapas")
        btn_config_etapas.setFixedWidth(28)
        btn_config_etapas.setFixedHeight(22)
        btn_config_etapas.clicked.connect(self.abrir_configuracao_ordem_etapas)

        lay_header_etapas.addWidget(lbl_titulo_etapas)
        lay_header_etapas.addWidget(btn_config_etapas)
        lay_header_etapas.addStretch()

        lay_grp_etapas_main.addLayout(lay_header_etapas)

        self.lay_etapas = QHBoxLayout()
        self.lay_etapas.setContentsMargins(0, 0, 0, 0)
        lay_grp_etapas_main.addLayout(self.lay_etapas)

        self.btn_group_etapas = QButtonGroup(self)

        lay_filtros_superiores.addWidget(self.grp_etapas)

        # 2. Filtro por 'Aos Cuidados'
        grp_cuidados = QGroupBox("Aos Cuidados")
        lay_cuidados = QHBoxLayout(grp_cuidados)
        lay_cuidados.setContentsMargins(6, 4, 6, 4)

        self.btn_group_cuidados = QButtonGroup(self)

        rb_c_todos = QRadioButton("Todos")
        rb_c_todos.setChecked(True)
        rb_c_todos.setProperty("valor", "TODOS")
        self.btn_group_cuidados.addButton(rb_c_todos)
        lay_cuidados.addWidget(rb_c_todos)

        rb_c_empresa = QRadioButton("Empresa")
        rb_c_empresa.setProperty("valor", "empresa")
        self.btn_group_cuidados.addButton(rb_c_empresa)
        lay_cuidados.addWidget(rb_c_empresa)

        rb_c_pref = QRadioButton("Prefeitura")
        rb_c_pref.setProperty("valor", "prefeitura")
        self.btn_group_cuidados.addButton(rb_c_pref)
        lay_cuidados.addWidget(rb_c_pref)

        lay_filtros_superiores.addWidget(grp_cuidados)

        layout.addLayout(lay_filtros_superiores)

        self.btn_group_etapas.buttonClicked.connect(self.aplicar_filtros)
        self.btn_group_cuidados.buttonClicked.connect(self.aplicar_filtros)

        # --- TABELA DE FILTROS POR TEXTO (TOPO) ---
        colunas_totais = len(self.field_names) + 1
        self.table_filter = QTableWidget()
        self.table_filter.setRowCount(1)
        self.table_filter.setColumnCount(colunas_totais)
        self.table_filter.setFixedHeight(35)
        self.table_filter.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table_filter.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table_filter.horizontalHeader().setVisible(False)
        self.table_filter.verticalHeader().setVisible(False)

        self.table_filter.setCellWidget(0, 0, QLabel(""))

        for col, field_name in enumerate(self.field_names):
            line_edit = QLineEdit()
            line_edit.setPlaceholderText(f"Filtrar {field_name}...")
            line_edit.setClearButtonEnabled(True)
            line_edit.textChanged.connect(self.aplicar_filtros)
            self.table_filter.setCellWidget(0, col + 1, line_edit)
            self.filter_inputs.append(line_edit)

        layout.addWidget(self.table_filter)

        # --- TABELA PRINCIPAL DE DADOS ---
        self.table = QTableWidget()
        self.table.setColumnCount(colunas_totais)
        headers = ["Ações"] + self.field_names
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True)

        self.table.horizontalScrollBar().valueChanged.connect(
            self.table_filter.horizontalScrollBar().setValue
        )

        self.table.itemDoubleClicked.connect(self.ao_dar_duplo_clique)
        self.table.itemSelectionChanged.connect(self.ao_selecionar_linha)

        layout.addWidget(self.table)

    def ler_ordem_etapas_txt(self):
        if os.path.exists(ORDEM_ETAPAS_PATH):
            try:
                with open(ORDEM_ETAPAS_PATH, "r", encoding="utf-8") as f:
                    linhas = [linha.strip().upper() for linha in f.readlines() if linha.strip()]
                    return linhas
            except Exception as e:
                print(f"Erro ao ler ordem_etapas.txt: {e}")
        return []

    def salvar_ordem_etapas_txt(self, ordem_lista):
        try:
            with open(ORDEM_ETAPAS_PATH, "w", encoding="utf-8") as f:
                for item in ordem_lista:
                    f.write(f"{item}\n")
        except Exception as e:
            QMessageBox.warning(self, "Erro ao Salvar", f"Não foi possível salvar a ordem das etapas:\n{e}")

    def _obter_todas_etapas_conhecidas(self, features=None):
        """Coleta etapas tanto das feições quanto de eventual Mapa de Valores configurado no campo."""
        etapas = set()
        idx_etapa = self.field_names.index("etapa") if "etapa" in self.field_names else -1
        if idx_etapa < 0:
            return etapas

        if features is None and self.layer:
            features = list(self.layer.getFeatures())

        for feat in (features or []):
            val = feat["etapa"]
            if val is not None and str(val).strip():
                etapas.add(str(val).strip().upper())

        # Também inclui opções configuradas no Mapa de Valores do projeto, mesmo sem feições ainda
        setup = self.layer.editorWidgetSetup(idx_etapa)
        if setup.type() == "ValueMap":
            config_map = setup.config().get("map", [])
            if isinstance(config_map, list):
                for item in config_map:
                    if isinstance(item, dict):
                        for _, val_real in item.items():
                            if val_real is not None and str(val_real).strip():
                                etapas.add(str(val_real).strip().upper())
            elif isinstance(config_map, dict):
                for _, val_real in config_map.items():
                    if val_real is not None and str(val_real).strip():
                        etapas.add(str(val_real).strip().upper())

        return etapas

    def abrir_configuracao_ordem_etapas(self):
        etapas_existentes = self._obter_todas_etapas_conhecidas()
        ordem_atual = self.ler_ordem_etapas_txt()

        dlg = DialogOrdenacaoEtapas(etapas_existentes, ordem_atual, self)
        if dlg.exec_() == QDialog.Accepted:
            nova_ordem = dlg.obter_ordem()
            self.salvar_ordem_etapas_txt(nova_ordem)
            self.carregar_dados()

    def atualizar_filtros_etapa_dinamicos(self, features):
        etapa_selecionada = "TODAS"
        btn_atual = self.btn_group_etapas.checkedButton()
        if btn_atual:
            etapa_selecionada = btn_atual.property("valor_etapa")

        for btn in self.btn_group_etapas.buttons():
            self.btn_group_etapas.removeButton(btn)
            btn.deleteLater()

        while self.lay_etapas.count():
            item = self.lay_etapas.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        rb_todas = QRadioButton("Todas")
        rb_todas.setProperty("valor_etapa", "TODAS")
        self.btn_group_etapas.addButton(rb_todas)
        self.lay_etapas.addWidget(rb_todas)

        idx_etapa = self.field_names.index("etapa") if "etapa" in self.field_names else -1
        etapas_unicas = {}

        if idx_etapa >= 0:
            for feat in features:
                val = feat["etapa"]
                if val is not None and str(val).strip():
                    val_code = str(val).strip().upper()
                    if val_code not in etapas_unicas:
                        etapas_unicas[val_code] = self._obter_texto_exibicao_campo("etapa", val)

        ordem_txt = self.ler_ordem_etapas_txt()

        def funcao_ordem(item_tuple):
            etapa_upper = item_tuple[0]
            if etapa_upper in ordem_txt:
                return (0, ordem_txt.index(etapa_upper))
            return (1, etapa_upper)

        etapas_ordenadas = sorted(list(etapas_unicas.items()), key=funcao_ordem)

        rb_para_selecionar = rb_todas
        for val_code, label_exibicao in etapas_ordenadas:
            texto_btn = label_exibicao.title() if label_exibicao.isupper() else label_exibicao
            rb = QRadioButton(texto_btn)
            rb.setProperty("valor_etapa", val_code)
            self.btn_group_etapas.addButton(rb)
            self.lay_etapas.addWidget(rb)

            if val_code == etapa_selecionada:
                rb_para_selecionar = rb

        rb_para_selecionar.setChecked(True)

    def alternar_edicao_camada(self):
        if not self.layer:
            return

        if self.layer.isEditable():
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Question)
            box.setWindowTitle("Encerrar Edição")
            box.setText("Deseja salvar as alterações feitas na camada PROCESSOS_REURB?")
            
            btn_salvar = box.addButton("💾 Salvar", QMessageBox.AcceptRole)
            btn_descartar = box.addButton("🗑️ Descartar Alterações", QMessageBox.DestructiveRole)
            btn_cancelar = box.addButton("Cancelar", QMessageBox.RejectRole)

            box.exec_()

            if box.clickedButton() == btn_salvar:
                if self.layer.commitChanges():
                    QMessageBox.information(self, "Edição Concluída", "Alterações salvas com sucesso!")
                    self.carregar_dados()
                else:
                    QMessageBox.warning(self, "Erro ao Salvar", f"Não foi possível salvar as alterações:\n{self.layer.commitErrors()}")
            elif box.clickedButton() == btn_descartar:
                self.layer.rollBack()
                QMessageBox.information(self, "Edição Cancelada", "As alterações foram descartadas.")
                self.carregar_dados()
            else:
                return
        else:
            self.layer.startEditing()

        self.atualizar_estado_btn_edicao()

    def atualizar_estado_btn_edicao(self):
        if not self.layer:
            return

        is_editing = self.layer.isEditable()
        self.btn_toggle_edit.setChecked(is_editing)

        if is_editing:
            self.btn_toggle_edit.setText("💾 Concluir / Salvar Edição")
            self.btn_toggle_edit.setStyleSheet("QPushButton { background-color: #ffc107; color: #000; font-weight: bold; }")
            self.btn_toggle_edit.setToolTip("A camada está em modo de edição. Clique para salvar ou descartar as alterações.")
        else:
            self.btn_toggle_edit.setText("✏️ Habilitar Edição")
            self.btn_toggle_edit.setStyleSheet("")
            self.btn_toggle_edit.setToolTip("Clique para colocar a camada em modo de edição.")

    def criar_menu_colunas(self):
        menu = QMenu(self)
        for col, field_name in enumerate(self.field_names):
            chk = QCheckBox(field_name, menu)
            chk.setChecked(True)
            chk.toggled.connect(lambda checked, c=col+1, fn=field_name: self.alternar_coluna(c, fn, checked))

            action = QWidgetAction(menu)
            action.setDefaultWidget(chk)
            menu.addAction(action)
            self.col_checkboxes[field_name] = (col + 1, chk)

        menu.addSeparator()
        act_salvar = menu.addAction("💾 Salvar Preferências")
        act_salvar.triggered.connect(self.salvar_preferencias_msg)

        return menu

    def alternar_coluna(self, col, field_name, visible):
        self.table.setColumnHidden(col, not visible)
        self.table_filter.setColumnHidden(col, not visible)
        self.salvar_preferencias()

    def salvar_preferencias(self):
        try:
            prefs = {field_name: chk.isChecked() for field_name, (_, chk) in self.col_checkboxes.items()}
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(prefs, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Erro ao salvar preferências: {e}")

    def salvar_preferencias_msg(self):
        self.salvar_preferencias()
        QMessageBox.information(self, "Preferências Salvas", "Visibilidade das colunas salva com sucesso!")

    def carregar_preferencias(self):
        if not os.path.exists(CONFIG_PATH):
            return
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                prefs = json.load(f)

            for field_name, visible in prefs.items():
                if field_name in self.col_checkboxes:
                    col, chk = self.col_checkboxes[field_name]
                    chk.blockSignals(True)
                    chk.setChecked(visible)
                    chk.blockSignals(False)
                    self.table.setColumnHidden(col, not visible)
                    self.table_filter.setColumnHidden(col, not visible)
        except Exception as e:
            print(f"Erro ao carregar preferências: {e}")

    def criar_botoes_acao(self, feature_id):
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(4)

        btn_zoom = QPushButton("🔍")
        btn_zoom.setToolTip("Zoom/Localizar no mapa")
        btn_zoom.setFixedWidth(28)
        btn_zoom.clicked.connect(lambda: self.zoom_elemento(feature_id))

        btn_edit = QPushButton("✏️")
        btn_edit.setToolTip("Editar formulário de atributos")
        btn_edit.setFixedWidth(28)
        btn_edit.clicked.connect(lambda: self.editar_elemento(feature_id))

        btn_geom = QPushButton("📐")
        btn_geom.setToolTip("Atualizar geometria do processo com a união dos lotes vinculados")
        btn_geom.setFixedWidth(28)
        btn_geom.clicked.connect(lambda checked, fid=feature_id: self.atualizar_geometria_elemento(fid))

        btn_avancar = QPushButton("⏭️")
        btn_avancar.setToolTip("Avançar etapa do processo")
        btn_avancar.setFixedWidth(28)
        btn_avancar.clicked.connect(lambda checked, fid=feature_id: self.abrir_dialogo_avancar_etapa(fid))

        layout.addWidget(btn_zoom)
        layout.addWidget(btn_edit)
        layout.addWidget(btn_geom)
        layout.addWidget(btn_avancar)

        # --- VERIFICAÇÃO E RENDERIZAÇÃO DE ANÁLISES TÉCNICAS VINCULADAS ---
        if self.layer:
            feat = self.layer.getFeature(feature_id)
            if feat.isValid():
                idx_etapa = self.field_names.index("etapa") if "etapa" in self.field_names else -1
                etapa_feat = str(feat["etapa"]).strip().upper() if idx_etapa >= 0 and feat["etapa"] is not None else ""

                todas_analises = carregar_config_analises()
                
                analises_compativeis = []
                for a in todas_analises:
                    if a.get("camada", "").upper() == "PROCESSOS_REURB":
                        etapa_cfg = a.get("etapa", "").strip().upper()
                        if not etapa_cfg or etapa_cfg == etapa_feat:
                            analises_compativeis.append(a)

                if len(analises_compativeis) == 1:
                    cfg_unica = analises_compativeis[0]
                    btn_parecer = QPushButton("📄")
                    btn_parecer.setToolTip(f"Executar Análise: {cfg_unica['titulo']}")
                    btn_parecer.setFixedWidth(28)
                    btn_parecer.clicked.connect(lambda checked, c=cfg_unica, fid=feature_id: self.executar_analise_por_id(c, fid))
                    layout.addWidget(btn_parecer)

                elif len(analises_compativeis) > 1:
                    btn_parecer = QToolButton()
                    btn_parecer.setText("📄")
                    btn_parecer.setToolTip("Selecionar Análise Técnica...")
                    btn_parecer.setFixedWidth(28)
                    btn_parecer.setPopupMode(QToolButton.InstantPopup)
                    
                    menu_analises = QMenu(btn_parecer)
                    for cfg in analises_compativeis:
                        act = menu_analises.addAction(cfg["titulo"])
                        act.triggered.connect(lambda checked, c=cfg, fid=feature_id: self.executar_analise_por_id(c, fid))
                    
                    btn_parecer.setMenu(menu_analises)
                    layout.addWidget(btn_parecer)

        layout.addStretch()
        return widget

    def abrir_dialogo_avancar_etapa(self, feat_id):
        if not self.layer:
            return

        feat = self.layer.getFeature(feat_id)
        if not feat.isValid():
            return

        # Monta a lista ordenada de etapas (ordem_etapas.txt + etapas da camada/ValueMap)
        etapas_conhecidas = self._obter_todas_etapas_conhecidas()
        ordem_txt = self.ler_ordem_etapas_txt()
        lista_etapas_ordenadas = list(ordem_txt)
        for e in sorted(etapas_conhecidas):
            if e not in lista_etapas_ordenadas:
                lista_etapas_ordenadas.append(e)

        dlg = DialogAvancarEtapa(
            layer=self.layer,
            feature=feat,
            lista_etapas_ordenadas=lista_etapas_ordenadas,
            parent=self
        )

        if dlg.exec_() == QDialog.Accepted:
            dados = dlg.obter_valores()
            ja_estava_editando = self.layer.isEditable()

            if not ja_estava_editando:
                self.layer.startEditing()

            for field_name, novo_valor in dados.items():
                field_idx = self.layer.fields().indexFromName(field_name)
                if field_idx >= 0:
                    self.layer.changeAttributeValue(feat_id, field_idx, novo_valor)

            if not ja_estava_editando:
                if not self.layer.commitChanges():
                    QMessageBox.warning(
                        self, "Erro ao Salvar",
                        f"Não foi possível salvar a alteração:\n{self.layer.commitErrors()}"
                    )
                    self.layer.rollBack()

            self.atualizar_estado_btn_edicao()
            self.carregar_dados()

    def executar_analise_por_id(self, config_analise, feat_id):
        """Seleciona a feição no mapa/camada e executa a análise correspondente."""
        if self.layer:
            self.layer.selectByIds([feat_id])
            executar_analise_urbana(config_analise)
            self.carregar_dados()

    def zoom_elemento(self, feat_id):
        if self.layer:
            self.layer.selectByIds([feat_id])
            box = self.layer.boundingBoxOfSelected()
            if not box.isEmpty():
                iface.mapCanvas().setExtent(box)
                iface.mapCanvas().refresh()

    def editar_elemento(self, feat_id):
        if self.layer:
            feat = self.layer.getFeature(feat_id)
            if feat.isValid():
                iface.openFeatureForm(self.layer, feat)

    def carregar_dados(self):
        if not self.layer:
            return

        self.table.setRowCount(0)
        features = list(self.layer.getFeatures())

        self.atualizar_filtros_etapa_dinamicos(features)

        self.table.setRowCount(len(features))

        for row, feat in enumerate(features):
            self.table.setCellWidget(row, 0, self.criar_botoes_acao(feat.id()))

            for col, field_name in enumerate(self.field_names):
                val = feat[field_name]
                text = self._obter_texto_exibicao_campo(field_name, val)

                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, feat.id())
                item.setData(Qt.UserRole + 1, val)
                self.table.setItem(row, col + 1, item)

        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(0, 155)
        self.table_filter.setColumnWidth(0, 155)

        for col in range(len(self.field_names)):
            width = max(self.table.columnWidth(col + 1), 110)
            self.table.setColumnWidth(col + 1, width)
            self.table_filter.setColumnWidth(col + 1, width)

        self.lbl_titulo.setText(f"<b>Processos REURB</b> ({len(features)} registros)")
        self.aplicar_filtros()

    def aplicar_filtros(self):
        btn_etapa = self.btn_group_etapas.checkedButton()
        val_etapa_filtro = btn_etapa.property("valor_etapa") if btn_etapa else "TODAS"

        btn_cuidado = self.btn_group_cuidados.checkedButton()
        filtro_cuidado = btn_cuidado.property("valor") if btn_cuidado else "TODOS"

        visiveis = 0
        idx_etapa_col = self.field_names.index("etapa") if "etapa" in self.field_names else -1
        idx_cuidado_col = self.field_names.index("aos_cuidados") if "aos_cuidados" in self.field_names else -1

        for row in range(self.table.rowCount()):
            row_visible = True

            if val_etapa_filtro != "TODAS" and idx_etapa_col >= 0:
                item_etapa = self.table.item(row, idx_etapa_col + 1)
                raw_val = item_etapa.data(Qt.UserRole + 1) if item_etapa else None
                codigo_etapa = str(raw_val).strip().upper() if raw_val is not None else ""

                if codigo_etapa != val_etapa_filtro:
                    row_visible = False

            if row_visible and filtro_cuidado != "TODOS" and idx_cuidado_col >= 0:
                item_cuidado = self.table.item(row, idx_cuidado_col + 1)
                texto_cuidado = item_cuidado.text().strip().lower() if item_cuidado else ""
                raw_cuidado = str(item_cuidado.data(Qt.UserRole + 1)).strip().lower() if item_cuidado and item_cuidado.data(Qt.UserRole + 1) is not None else ""
                if filtro_cuidado.lower() not in texto_cuidado and filtro_cuidado.lower() not in raw_cuidado:
                    row_visible = False

            if row_visible:
                for col, input_widget in enumerate(self.filter_inputs):
                    filter_text = input_widget.text().strip().lower()
                    if filter_text:
                        item = self.table.item(row, col + 1)
                        cell_text = item.text().lower() if item else ""
                        if filter_text not in cell_text:
                            row_visible = False
                            break

            self.table.setRowHidden(row, not row_visible)
            if row_visible:
                visiveis += 1

        self.lbl_titulo.setText(f"<b>Processos REURB</b> ({visiveis} de {self.table.rowCount()} exibidos)")

    def ao_dar_duplo_clique(self, item):
        if item.column() > 0:
            feat_id = item.data(Qt.UserRole)
            if feat_id is not None:
                self.zoom_elemento(feat_id)

    def ao_selecionar_linha(self):
        selected_rows = self.table.selectionModel().selectedRows()
        if selected_rows and self.layer:
            feat_ids = [self.table.item(r.row(), 1).data(Qt.UserRole) for r in selected_rows if self.table.item(r.row(), 1)]
            if feat_ids:
                self.layer.selectByIds(feat_ids)

    def closeEvent(self, event):
        gerenciador = getattr(self, "gerenciador_vinculos", None)
        if gerenciador:
            gerenciador.cancelar_digitizacao_pendente()
        super().closeEvent(event)

def run():
    dialog = GestaoReurbDialog(iface.mainWindow())
    dialog.show()