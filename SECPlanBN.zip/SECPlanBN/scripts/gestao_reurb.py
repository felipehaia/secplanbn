import os
import json
from qgis.core import QgsProject, QgsFeature
from qgis.utils import iface
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QLineEdit, QLabel, QPushButton, QMenu, QWidgetAction,
    QCheckBox, QMessageBox, QRadioButton, QButtonGroup, QGroupBox
)

# Caminho do arquivo txt para salvar as preferências no mesmo diretório do script
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "preferencias_colunas.txt")

class GestaoReurbDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Gestão de Processos REURB")
        self.resize(1200, 650)

        # Busca a camada PROCESSOS_REURB no projeto QGIS
        self.layer = None
        layers = QgsProject.instance().mapLayersByName("PROCESSOS_REURB")
        if layers:
            self.layer = layers[0]

        if not self.layer:
            QMessageBox.warning(
                self, "Camada não encontrada",
                "A camada 'PROCESSOS_REURB' não está carregada no projeto atual."
            )
            return

        self.field_names = [field.name() for field in self.layer.fields()]
        self.filter_inputs = []
        self.col_checkboxes = {}

        # Lista ORDENADA das etapas booleanas sequenciais do fluxo REURB
        self.fluxo_etapas = [
            ("vistoriado", "Vistoriado"),
            ("viabilidade", "Viabilidade"),
            ("projeto", "Projeto"),
            ("edital", "Edital"),
            ("crf", "CRF"),
            ("retorno_cartorio", "Retorno Cartório")
        ]

        self.setup_ui()
        self.carregar_dados()
        self.carregar_preferencias()

    def setup_ui(self):
        layout = QVBoxLayout(self)

        # --- BARRA SUPERIOR ---
        top_bar = QHBoxLayout()

        self.lbl_titulo = QLabel(f"<b>Processos REURB</b> ({self.layer.featureCount()} registros)")
        top_bar.addWidget(self.lbl_titulo)

        top_bar.addStretch()

        btn_colunas = QPushButton("👁️ Visibilidade das Colunas")
        btn_colunas.setMenu(self.criar_menu_colunas())
        top_bar.addWidget(btn_colunas)

        btn_refresh = QPushButton("🔄 Atualizar Dados")
        btn_refresh.clicked.connect(self.carregar_dados)
        top_bar.addWidget(btn_refresh)

        layout.addLayout(top_bar)

        # --- SELEÇÃO DE ETAPA CUMULATIVA ---
        grp_etapas = QGroupBox("Filtrar por Etapa Atingida (Etapa selecionada + anteriores devem ser TRUE)")
        lay_etapas = QHBoxLayout(grp_etapas)
        lay_etapas.setContentsMargins(8, 5, 8, 5)
        lay_etapas.setSpacing(12)

        self.btn_group_etapas = QButtonGroup(self)

        # Opção Padrão: Mostrar Todos
        rb_todos = QRadioButton("Todas as Etapas")
        rb_todos.setChecked(True)
        rb_todos.setProperty("etapa_idx", -1)
        self.btn_group_etapas.addButton(rb_todos)
        lay_etapas.addWidget(rb_todos)

        # Cria botões ordenados para cada etapa do fluxo
        for idx, (field_name, label) in enumerate(self.fluxo_etapas):
            if field_name in self.field_names:
                rb = QRadioButton(label)
                rb.setProperty("etapa_idx", idx)
                self.btn_group_etapas.addButton(rb)
                lay_etapas.addWidget(rb)

        lay_etapas.addStretch()
        layout.addWidget(grp_etapas)

        # Conecta a troca de opção para refiltrar
        self.btn_group_etapas.buttonClicked.connect(self.aplicar_filtros)

        # --- TABELA DE FILTROS POR TEXTO (TOPO DAS COLUNAS) ---
        self.table_filter = QTableWidget()
        self.table_filter.setRowCount(1)
        self.table_filter.setColumnCount(len(self.field_names))
        self.table_filter.setFixedHeight(35)
        self.table_filter.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table_filter.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table_filter.horizontalHeader().setVisible(False)
        self.table_filter.verticalHeader().setVisible(False)

        for col, field_name in enumerate(self.field_names):
            line_edit = QLineEdit()
            line_edit.setPlaceholderText(f"Filtrar {field_name}...")
            line_edit.setClearButtonEnabled(True)
            line_edit.textChanged.connect(self.aplicar_filtros)
            self.table_filter.setCellWidget(0, col, line_edit)
            self.filter_inputs.append(line_edit)

        layout.addWidget(self.table_filter)

        # --- TABELA PRINCIPAL DE DADOS ---
        self.table = QTableWidget()
        self.table.setColumnCount(len(self.field_names))
        self.table.setHorizontalHeaderLabels(self.field_names)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True)

        self.table.horizontalScrollBar().valueChanged.connect(
            self.table_filter.horizontalScrollBar().setValue
        )

        self.table.itemDoubleClicked.connect(self.ao_dar_duplo_clique)
        self.table.itemSelectionChanged.connect(self.ao_selecionar_linha)

        layout.addWidget(self.table)

    def criar_menu_colunas(self):
        """Cria o menu suspenso para Ocultar / Mostrar colunas."""
        menu = QMenu(self)
        for col, field_name in enumerate(self.field_names):
            chk = QCheckBox(field_name, menu)
            chk.setChecked(True)
            chk.toggled.connect(lambda checked, c=col, fn=field_name: self.alternar_coluna(c, fn, checked))

            action = QWidgetAction(menu)
            action.setDefaultWidget(chk)
            menu.addAction(action)
            self.col_checkboxes[field_name] = (col, chk)

        menu.addSeparator()
        
        # Botão explícito para salvar preferências no TXT
        act_salvar = menu.addAction("💾 Salvar Preferências")
        act_salvar.triggered.connect(self.salvar_preferencias_msg)

        return menu

    def alternar_coluna(self, col, field_name, visible):
        """Oculta/exibe a coluna e salva as preferências automaticamente."""
        self.table.setColumnHidden(col, not visible)
        self.table_filter.setColumnHidden(col, not visible)
        self.salvar_preferencias()

    def salvar_preferencias(self):
        """Salva a visibilidade de cada coluna em preferencias_colunas.txt."""
        try:
            prefs = {}
            for field_name, (col, chk) in self.col_checkboxes.items():
                prefs[field_name] = chk.isChecked()

            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(prefs, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Erro ao salvar preferências: {e}")

    def salvar_preferencias_msg(self):
        """Salva e envia mensagem ao usuário."""
        self.salvar_preferencias()
        QMessageBox.information(self, "Preferências Salvas", "As preferências de visibilidade das colunas foram salvas com sucesso!")

    def carregar_preferencias(self):
        """Lê o arquivo preferencias_colunas.txt e aplica na interface."""
        if not os.path.exists(CONFIG_PATH):
            return

        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                prefs = json.load(f)

            for field_name, visible in prefs.items():
                if field_name in self.col_checkboxes:
                    col, chk = self.col_checkboxes[field_name]
                    # Bloqueia sinais temporariamente para não acionar evento em loop
                    chk.blockSignals(True)
                    chk.setChecked(visible)
                    chk.blockSignals(False)

                    self.table.setColumnHidden(col, not visible)
                    self.table_filter.setColumnHidden(col, not visible)
        except Exception as e:
            print(f"Erro ao carregar preferências: {e}")

    def carregar_dados(self):
        if not self.layer:
            return

        self.table.setRowCount(0)
        features = list(self.layer.getFeatures())
        self.table.setRowCount(len(features))

        for row, feat in enumerate(features):
            for col, field_name in enumerate(self.field_names):
                val = feat[field_name]
                text = str(val) if val is not None else ""

                if isinstance(val, bool):
                    text = "Sim" if val else "Não"

                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, feat.id())
                item.setData(Qt.UserRole + 1, val)
                self.table.setItem(row, col, item)

        self.table.resizeColumnsToContents()
        for col in range(len(self.field_names)):
            width = max(self.table.columnWidth(col), 110)
            self.table.setColumnWidth(col, width)
            self.table_filter.setColumnWidth(col, width)

        self.lbl_titulo.setText(f"<b>Processos REURB</b> ({len(features)} registros)")
        self.aplicar_filtros()

    def aplicar_filtros(self):
        """Filtra a tabela exigindo que a etapa atual E TODAS as anteriores sejam True."""
        selected_button = self.btn_group_etapas.checkedButton()
        etapa_idx = selected_button.property("etapa_idx") if selected_button else -1

        visiveis = 0
        for row in range(self.table.rowCount()):
            row_visible = True

            # 1. Validação Cumulativa das Etapas
            if etapa_idx >= 0:
                for i in range(etapa_idx + 1):
                    field_name, _ = self.fluxo_etapas[i]
                    if field_name in self.field_names:
                        col_idx = self.field_names.index(field_name)
                        item = self.table.item(row, col_idx)
                        val_bruto = item.data(Qt.UserRole + 1) if item else None

                        is_true = val_bruto in [True, "true", "True", "Sim", "1", 1]
                        if not is_true:
                            row_visible = False
                            break

            # 2. Filtros de Texto no Topo de Cada Coluna
            if row_visible:
                for col, input_widget in enumerate(self.filter_inputs):
                    filter_text = input_widget.text().strip().lower()
                    if filter_text:
                        item = self.table.item(row, col)
                        cell_text = item.text().lower() if item else ""
                        if filter_text not in cell_text:
                            row_visible = False
                            break

            self.table.setRowHidden(row, not row_visible)
            if row_visible:
                visiveis += 1

        self.lbl_titulo.setText(f"<b>Processos REURB</b> ({visiveis} de {self.table.rowCount()} exibidos)")

    def ao_dar_duplo_clique(self, item):
        feat_id = item.data(Qt.UserRole)
        if feat_id is not None and self.layer:
            self.layer.selectByIds([feat_id])
            box = self.layer.boundingBoxOfSelected()
            if not box.isEmpty():
                iface.mapCanvas().setExtent(box)
                iface.mapCanvas().refresh()

    def ao_selecionar_linha(self):
        selected_rows = self.table.selectionModel().selectedRows()
        if selected_rows and self.layer:
            feat_ids = [self.table.item(r.row(), 0).data(Qt.UserRole) for r in selected_rows]
            self.layer.selectByIds(feat_ids)

def run():
    dialog = GestaoReurbDialog(iface.mainWindow())
    dialog.show()