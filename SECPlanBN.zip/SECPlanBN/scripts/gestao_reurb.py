import os
import json
from qgis.core import QgsProject, QgsFeature
from qgis.utils import iface
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QLineEdit, QLabel, QPushButton, QMenu, QWidgetAction,
    QCheckBox, QMessageBox, QRadioButton, QButtonGroup, QGroupBox,
    QWidget
)

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "preferencias_colunas.txt")

class GestaoReurbDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Gestão de Processos REURB")
        self.resize(1250, 680)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinMaxButtonsHint)
        # Busca a camada PROCESSOS_REURB no projeto QGIS
        self.layer = None
        layers = QgsProject.instance().mapLayersByName("PROCESSOS_REURB")
        if layers:
            self.layer = layers[0]

        if not self.layer:
            QMessageBox.warning(
                self, "Camada não encontrada",
                "A camada 'PROCESSOS_REURB' não está carregada no projeto atual."
            )
            return

        self.field_names = [field.name() for field in self.layer.fields()]
        self.filter_inputs = []
        self.col_checkboxes = {}

        self.setup_ui()
        self.carregar_dados()
        self.carregar_preferencias()

        # Conecta sinal para atualizar o visual do botão se a edição for alterada via QGIS
        if self.layer:
            self.layer.editingStarted.connect(self.atualizar_estado_btn_edicao)
            self.layer.editingStopped.connect(self.atualizar_estado_btn_edicao)

    def setup_ui(self):
        layout = QVBoxLayout(self)

        # --- BARRA SUPERIOR ---
        top_bar = QHBoxLayout()

        self.lbl_titulo = QLabel(f"<b>Processos REURB</b> ({self.layer.featureCount()} registros)")
        top_bar.addWidget(self.lbl_titulo)

        top_bar.addStretch()

        # Botão Alternar Edição da Camada
        self.btn_toggle_edit = QPushButton("✏️ Alternar Edição")
        self.btn_toggle_edit.setCheckable(True)
        self.btn_toggle_edit.clicked.connect(self.alternar_edicao_camada)
        top_bar.addWidget(self.btn_toggle_edit)

        # Botão para Ocultar/Mostrar Colunas
        btn_colunas = QPushButton("👁️ Visibilidade das Colunas")
        btn_colunas.setMenu(self.criar_menu_colunas())
        top_bar.addWidget(btn_colunas)

        # Botão Atualizar Dados
        btn_refresh = QPushButton("🔄 Atualizar Dados")
        btn_refresh.clicked.connect(self.carregar_dados)
        top_bar.addWidget(btn_refresh)

        layout.addLayout(top_bar)
        self.atualizar_estado_btn_edicao()

        # --- FILTROS DE ETAPA E AOS CUIDADOS ---
        lay_filtros_superiores = QHBoxLayout()

        # 1. Filtro por Etapa (Exato)
        grp_etapas = QGroupBox("Filtrar por Etapa")
        lay_etapas = QHBoxLayout(grp_etapas)
        lay_etapas.setContentsMargins(6, 4, 6, 4)

        self.btn_group_etapas = QButtonGroup(self)

        rb_todas = QRadioButton("Todas")
        rb_todas.setChecked(True)
        rb_todas.setProperty("valor_etapa", "TODAS")
        self.btn_group_etapas.addButton(rb_todas)
        lay_etapas.addWidget(rb_todas)

        # Mapeamento exato dos valores gravados no banco
        etapas_labels = [
            ("Vistoria", "VISTORIA"),
            ("Viabilidade", "VIABILIDADE"),
            ("Projeto", "PROJETO"),
            ("Edital", "EDITAL"),
            ("CRF", "CRF"),
            ("Retorno Cartório", "RETORNO CARTÓRIO"),
            ("Indeferido", "INDEFERIDO")
        ]

        for label, val_code in etapas_labels:
            rb = QRadioButton(label)
            rb.setProperty("valor_etapa", val_code)
            self.btn_group_etapas.addButton(rb)
            lay_etapas.addWidget(rb)

        lay_filtros_superiores.addWidget(grp_etapas)

        # 2. Filtro por 'Aos Cuidados'
        grp_cuidados = QGroupBox("Aos Cuidados")
        lay_cuidados = QHBoxLayout(grp_cuidados)
        lay_cuidados.setContentsMargins(6, 4, 6, 4)

        self.btn_group_cuidados = QButtonGroup(self)

        rb_c_todos = QRadioButton("Todos")
        rb_c_todos.setChecked(True)
        rb_c_todos.setProperty("valor", "TODOS")
        self.btn_group_cuidados.addButton(rb_c_todos)
        lay_cuidados.addWidget(rb_c_todos)

        rb_c_empresa = QRadioButton("Empresa")
        rb_c_empresa.setProperty("valor", "empresa")
        self.btn_group_cuidados.addButton(rb_c_empresa)
        lay_cuidados.addWidget(rb_c_empresa)

        rb_c_pref = QRadioButton("Prefeitura")
        rb_c_pref.setProperty("valor", "prefeitura")
        self.btn_group_cuidados.addButton(rb_c_pref)
        lay_cuidados.addWidget(rb_c_pref)

        lay_filtros_superiores.addWidget(grp_cuidados)

        layout.addLayout(lay_filtros_superiores)

        # Conecta eventos dos radio buttons aos filtros
        self.btn_group_etapas.buttonClicked.connect(self.aplicar_filtros)
        self.btn_group_cuidados.buttonClicked.connect(self.aplicar_filtros)

        # --- TABELA DE FILTROS POR TEXTO (TOPO) ---
        colunas_totais = len(self.field_names) + 1  # +1 para a coluna de Ações
        self.table_filter = QTableWidget()
        self.table_filter.setRowCount(1)
        self.table_filter.setColumnCount(colunas_totais)
        self.table_filter.setFixedHeight(35)
        self.table_filter.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table_filter.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table_filter.horizontalHeader().setVisible(False)
        self.table_filter.verticalHeader().setVisible(False)

        # Célula vazia na primeira coluna (Ações)
        self.table_filter.setCellWidget(0, 0, QLabel(""))

        for col, field_name in enumerate(self.field_names):
            line_edit = QLineEdit()
            line_edit.setPlaceholderText(f"Filtrar {field_name}...")
            line_edit.setClearButtonEnabled(True)
            line_edit.textChanged.connect(self.aplicar_filtros)
            self.table_filter.setCellWidget(0, col + 1, line_edit)
            self.filter_inputs.append(line_edit)

        layout.addWidget(self.table_filter)

        # --- TABELA PRINCIPAL DE DADOS ---
        self.table = QTableWidget()
        self.table.setColumnCount(colunas_totais)
        headers = ["Ações"] + self.field_names
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True)

        self.table.horizontalScrollBar().valueChanged.connect(
            self.table_filter.horizontalScrollBar().setValue
        )

        self.table.itemDoubleClicked.connect(self.ao_dar_duplo_clique)
        self.table.itemSelectionChanged.connect(self.ao_selecionar_linha)

        layout.addWidget(self.table)

    def alternar_edicao_camada(self):
        """Habilita ou pergunta se deseja Salvar/Descartar a edição da camada PROCESSOS_REURB."""
        if not self.layer:
            return

        if self.layer.isEditable():
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Question)
            box.setWindowTitle("Encerrar Edição")
            box.setText("Deseja salvar as alterações feitas na camada PROCESSOS_REURB?")
            
            btn_salvar = box.addButton("💾 Salvar", QMessageBox.AcceptRole)
            btn_descartar = box.addButton("🗑️ Descartar Alterações", QMessageBox.DestructiveRole)
            btn_cancelar = box.addButton("Cancelar", QMessageBox.RejectRole)

            box.exec_()

            if box.clickedButton() == btn_salvar:
                if self.layer.commitChanges():
                    QMessageBox.information(self, "Edição Concluída", "Alterações salvas com sucesso!")
                    self.carregar_dados()
                else:
                    QMessageBox.warning(self, "Erro ao Salvar", f"Não foi possível salvar as alterações:\n{self.layer.commitErrors()}")
            elif box.clickedButton() == btn_descartar:
                self.layer.rollBack()
                QMessageBox.information(self, "Edição Cancelada", "As alterações foram descartadas.")
                self.carregar_dados()
            else:
                return
        else:
            self.layer.startEditing()

        self.atualizar_estado_btn_edicao()

    def atualizar_estado_btn_edicao(self):
        """Atualiza a aparência e o texto do botão de edição conforme o estado da camada."""
        if not self.layer:
            return

        is_editing = self.layer.isEditable()
        self.btn_toggle_edit.setChecked(is_editing)

        if is_editing:
            self.btn_toggle_edit.setText("💾 Concluir / Salvar Edição")
            self.btn_toggle_edit.setStyleSheet("QPushButton { background-color: #ffc107; color: #000; font-weight: bold; }")
            self.btn_toggle_edit.setToolTip("A camada está em modo de edição. Clique para salvar ou descartar as alterações.")
        else:
            self.btn_toggle_edit.setText("✏️ Habilitar Edição")
            self.btn_toggle_edit.setStyleSheet("")
            self.btn_toggle_edit.setToolTip("Clique para colocar a camada em modo de edição.")

    def criar_menu_colunas(self):
        menu = QMenu(self)
        for col, field_name in enumerate(self.field_names):
            chk = QCheckBox(field_name, menu)
            chk.setChecked(True)
            chk.toggled.connect(lambda checked, c=col+1, fn=field_name: self.alternar_coluna(c, fn, checked))

            action = QWidgetAction(menu)
            action.setDefaultWidget(chk)
            menu.addAction(action)
            self.col_checkboxes[field_name] = (col + 1, chk)

        menu.addSeparator()
        act_salvar = menu.addAction("💾 Salvar Preferências")
        act_salvar.triggered.connect(self.salvar_preferencias_msg)

        return menu

    def alternar_coluna(self, col, field_name, visible):
        self.table.setColumnHidden(col, not visible)
        self.table_filter.setColumnHidden(col, not visible)
        self.salvar_preferencias()

    def salvar_preferencias(self):
        try:
            prefs = {field_name: chk.isChecked() for field_name, (_, chk) in self.col_checkboxes.items()}
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(prefs, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Erro ao salvar preferências: {e}")

    def salvar_preferencias_msg(self):
        self.salvar_preferencias()
        QMessageBox.information(self, "Preferências Salvas", "Visibilidade das colunas salva com sucesso!")

    def carregar_preferencias(self):
        if not os.path.exists(CONFIG_PATH):
            return
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                prefs = json.load(f)

            for field_name, visible in prefs.items():
                if field_name in self.col_checkboxes:
                    col, chk = self.col_checkboxes[field_name]
                    chk.blockSignals(True)
                    chk.setChecked(visible)
                    chk.blockSignals(False)
                    self.table.setColumnHidden(col, not visible)
                    self.table_filter.setColumnHidden(col, not visible)
        except Exception as e:
            print(f"Erro ao carregar preferências: {e}")

    def criar_botoes_acao(self, feature_id):
        """Cria os botões de Zoom e Edição para cada linha."""
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(4)

        btn_zoom = QPushButton("🔍")
        btn_zoom.setToolTip("Zoom/Localizar no mapa")
        btn_zoom.setFixedWidth(28)
        btn_zoom.clicked.connect(lambda: self.zoom_elemento(feature_id))

        btn_edit = QPushButton("✏️")
        btn_edit.setToolTip("Editar formulário de atributos")
        btn_edit.setFixedWidth(28)
        btn_edit.clicked.connect(lambda: self.editar_elemento(feature_id))

        layout.addWidget(btn_zoom)
        layout.addWidget(btn_edit)
        layout.addStretch()
        return widget

    def zoom_elemento(self, feat_id):
        if self.layer:
            self.layer.selectByIds([feat_id])
            box = self.layer.boundingBoxOfSelected()
            if not box.isEmpty():
                iface.mapCanvas().setExtent(box)
                iface.mapCanvas().refresh()

    def editar_elemento(self, feat_id):
        if self.layer:
            feat = self.layer.getFeature(feat_id)
            if feat.isValid():
                iface.openFeatureForm(self.layer, feat)

    def carregar_dados(self):
        if not self.layer:
            return

        self.table.setRowCount(0)
        features = list(self.layer.getFeatures())
        self.table.setRowCount(len(features))

        for row, feat in enumerate(features):
            self.table.setCellWidget(row, 0, self.criar_botoes_acao(feat.id()))

            for col, field_name in enumerate(self.field_names):
                val = feat[field_name]
                text = str(val) if val is not None else ""

                if isinstance(val, bool):
                    text = "Sim" if val else "Não"

                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, feat.id())
                item.setData(Qt.UserRole + 1, val)
                self.table.setItem(row, col + 1, item)

        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(0, 70)
        self.table_filter.setColumnWidth(0, 70)

        for col in range(len(self.field_names)):
            width = max(self.table.columnWidth(col + 1), 110)
            self.table.setColumnWidth(col + 1, width)
            self.table_filter.setColumnWidth(col + 1, width)

        self.lbl_titulo.setText(f"<b>Processos REURB</b> ({len(features)} registros)")
        self.aplicar_filtros()

    def aplicar_filtros(self):
        """Filtra a tabela exigindo correspondência exata do campo 'etapa' e 'aos_cuidados'."""
        btn_etapa = self.btn_group_etapas.checkedButton()
        val_etapa_filtro = btn_etapa.property("valor_etapa") if btn_etapa else "TODAS"

        btn_cuidado = self.btn_group_cuidados.checkedButton()
        filtro_cuidado = btn_cuidado.property("valor") if btn_cuidado else "TODOS"

        visiveis = 0
        idx_etapa_col = self.field_names.index("etapa") if "etapa" in self.field_names else -1
        idx_cuidado_col = self.field_names.index("aos_cuidados") if "aos_cuidados" in self.field_names else -1

        for row in range(self.table.rowCount()):
            row_visible = True

            # 1. Filtro Exato pelo Campo 'etapa'
            if val_etapa_filtro != "TODAS" and idx_etapa_col >= 0:
                item_etapa = self.table.item(row, idx_etapa_col + 1)
                texto_etapa = item_etapa.text().strip().upper() if item_etapa else ""

                if texto_etapa != val_etapa_filtro:
                    row_visible = False

            # 2. Filtro pelo Campo 'aos_cuidados'
            if row_visible and filtro_cuidado != "TODOS" and idx_cuidado_col >= 0:
                item_cuidado = self.table.item(row, idx_cuidado_col + 1)
                texto_cuidado = item_cuidado.text().strip().lower() if item_cuidado else ""
                if filtro_cuidado.lower() not in texto_cuidado:
                    row_visible = False

            # 3. Filtros de Texto das Colunas (Topo)
            if row_visible:
                for col, input_widget in enumerate(self.filter_inputs):
                    filter_text = input_widget.text().strip().lower()
                    if filter_text:
                        item = self.table.item(row, col + 1)
                        cell_text = item.text().lower() if item else ""
                        if filter_text not in cell_text:
                            row_visible = False
                            break

            self.table.setRowHidden(row, not row_visible)
            if row_visible:
                visiveis += 1

        self.lbl_titulo.setText(f"<b>Processos REURB</b> ({visiveis} de {self.table.rowCount()} exibidos)")

    def ao_dar_duplo_clique(self, item):
        if item.column() > 0:
            feat_id = item.data(Qt.UserRole)
            if feat_id is not None:
                self.zoom_elemento(feat_id)

    def ao_selecionar_linha(self):
        selected_rows = self.table.selectionModel().selectedRows()
        if selected_rows and self.layer:
            feat_ids = [self.table.item(r.row(), 1).data(Qt.UserRole) for r in selected_rows if self.table.item(r.row(), 1)]
            if feat_ids:
                self.layer.selectByIds(feat_ids)

def run():
    dialog = GestaoReurbDialog(iface.mainWindow())
    dialog.show()