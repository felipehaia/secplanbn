# scripts/buscas.py

import os
from qgis.core import QgsProject, QgsMapLayerType
from qgis.utils import iface
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QCompleter, 
    QDialogButtonBox, QComboBox, QListWidget, QListWidgetItem, QPushButton, 
    QFormLayout, QMessageBox, QWidget
)
from PyQt5.QtCore import Qt

# Caminho do arquivo onde as buscas ficam armazenadas
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config_buscas.txt")


def carregar_config_buscas():
    """Lê o arquivo TXT e retorna uma lista de dicionários com as buscas salvas."""
    buscas = []
    if not os.path.exists(CONFIG_PATH):
        # Cria buscas padrão caso o arquivo não exista
        buscas_padrao = [
            "Rua|RUASOFICIAIS|nome",
            "Lote|LOTES-BASE-PLANEJAMENTO|cadastro,id_betha"
        ]
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(buscas_padrao))

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and "|" in line:
                partes = line.split("|")
                if len(partes) >= 3:
                    titulo = partes[0].strip()
                    camada = partes[1].strip()
                    campos = [c.strip() for c in partes[2].split(",") if c.strip()]
                    buscas.append({
                        "titulo": titulo,
                        "camada": camada,
                        "campos": campos
                    })
    return buscas


def salvar_config_buscas(buscas):
    """Salva a lista de buscas no arquivo TXT."""
    linhas = []
    for b in buscas:
        campos_str = ",".join(b["campos"])
        linhas.append(f"{b['titulo']}|{b['camada']}|{campos_str}")
    
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(linhas))


def _executar_busca_generica(busca_dict):
    """Executa a busca com autocompletar baseando-se nos dados do dicionário."""
    nome_camada = busca_dict["camada"]
    campos_busca = busca_dict["campos"]
    titulo_janela = f"Buscar - {busca_dict['titulo']}"

    camadas = QgsProject.instance().mapLayersByName(nome_camada)

    if not camadas:
        iface.messageBar().pushCritical("Erro", f"A camada '{nome_camada}' não foi encontrada no projeto atual.")
        return

    layer = camadas[0]

    if layer.type() != QgsMapLayerType.VectorLayer:
        iface.messageBar().pushWarning("Aviso", f"A camada '{nome_camada}' não é vetorial e não possui campos pesquisáveis.")
        return

    # Coleta sugestões únicas dos campos configurados
    sugestoes = set()
    for campo in campos_busca:
        idx = layer.fields().indexOf(campo)
        if idx != -1:
            valores = layer.uniqueValues(idx)
            for val in valores:
                if val is not None and str(val).strip():
                    sugestoes.add(str(val).strip())

    sugestoes_ordenadas = sorted(list(sugestoes))

    dialog = QDialog(iface.mainWindow())
    dialog.setWindowTitle(titulo_janela)
    dialog.resize(400, 120)

    layout = QVBoxLayout()
    layout.addWidget(QLabel(f"Digite o termo de busca para '{busca_dict['titulo']}':"))

    input_texto = QLineEdit()
    completer = QCompleter(sugestoes_ordenadas)
    completer.setCaseSensitivity(Qt.CaseInsensitive)
    completer.setFilterMode(Qt.MatchContains)
    input_texto.setCompleter(completer)

    layout.addWidget(input_texto)

    botoes = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    botoes.accepted.connect(dialog.accept)
    botoes.rejected.connect(dialog.reject)
    layout.addWidget(botoes)

    dialog.setLayout(layout)

    if dialog.exec_() == QDialog.Accepted:
        texto_busca = input_texto.text().strip()
        if texto_busca:
            condicoes = [f'"{campo}" ILIKE \'%{texto_busca}%\'' for campo in campos_busca if layer.fields().indexOf(campo) != -1]
            if not condicoes:
                iface.messageBar().pushWarning("Aviso", "Nenhum dos campos configurados foi encontrado na camada.")
                return

            expressao = " OR ".join(condicoes)
            layer.selectByExpression(expressao)

            count = layer.selectedFeatureCount()
            if count > 0:
                iface.setActiveLayer(layer)
                iface.actionZoomToSelected().trigger()
                iface.messageBar().pushSuccess("Busca", f"{count} registro(s) encontrado(s) e selecionado(s).")
            else:
                iface.messageBar().pushWarning("Busca", f"Nenhum registro encontrado para '{texto_busca}'.")


class GerenciadorBuscasDialog(QDialog):
    """Janela para Adicionar/Remover buscas salvas no TXT."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Gerenciador de Buscas da Ribbon")
        self.resize(500, 420)
        self.buscas = carregar_config_buscas()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Lista de Buscas Existentes
        layout.addWidget(QLabel("<b>Buscas Cadastradas:</b>"))
        self.list_widget = QListWidget()
        self.atualizar_lista()
        layout.addWidget(self.list_widget)

        btn_remover = QPushButton("❌ Remover Busca Selecionada")
        btn_remover.clicked.connect(self.remover_busca)
        layout.addWidget(btn_remover)

        layout.addWidget(QLabel("<hr><b>Adicionar Nova Busca:</b>"))

        form_layout = QFormLayout()

        # Input Rótulo/Nome
        self.txt_nome = QLineEdit()
        self.txt_nome.setPlaceholderText("Ex: Buscar Loteamento")
        form_layout.addRow("Nome do Botão:", self.txt_nome)

        # Instanciação dos ComboBoxes antes de popular
        self.combo_camadas = QComboBox()
        self.combo_campos = QComboBox()

        form_layout.addRow("Selecione a Camada:", self.combo_camadas)
        form_layout.addRow("Selecione o Campo Principal:", self.combo_campos)

        self.txt_campos_adicionais = QLineEdit()
        self.txt_campos_adicionais.setPlaceholderText("Ex: id_betha, outro_campo (opcional, separados por vírgula)")
        form_layout.addRow("Outros Campos (Opcional):", self.txt_campos_adicionais)

        layout.addLayout(form_layout)

        # Popula as opções filtrando apenas por camadas vetoriais
        self.popula_camadas()
        self.combo_camadas.currentIndexChanged.connect(self.popula_campos)

        btn_add = QPushButton("➕ Adicionar Nova Busca")
        btn_add.clicked.connect(self.adicionar_busca)
        layout.addWidget(btn_add)

        botoes = QDialogButtonBox(QDialogButtonBox.Close)
        botoes.rejected.connect(self.accept)
        layout.addWidget(botoes)

    def atualizar_lista(self):
        self.list_widget.clear()
        for b in self.buscas:
            item_str = f"{b['titulo']}  ---> Camada: [{b['camada']}] | Campos: {', '.join(b['campos'])}"
            self.list_widget.addItem(item_str)

    def popula_camadas(self):
        self.combo_camadas.clear()
        # Filtra estritamente apenas camadas VETORIAIS do projeto
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayerType.VectorLayer:
                self.combo_camadas.addItem(layer.name())
        self.popula_campos()

    def popula_campos(self):
        self.combo_campos.clear()
        nome_camada = self.combo_camadas.currentText()
        if nome_camada:
            camadas = QgsProject.instance().mapLayersByName(nome_camada)
            if camadas and camadas[0].type() == QgsMapLayerType.VectorLayer:
                layer = camadas[0]
                if hasattr(layer, 'fields'):
                    for field in layer.fields():
                        self.combo_campos.addItem(field.name())

    def adicionar_busca(self):
        titulo = self.txt_nome.text().strip()
        camada = self.combo_camadas.currentText()
        campo_principal = self.combo_campos.currentText()
        outros_campos = self.txt_campos_adicionais.text().strip()

        if not titulo:
            QMessageBox.warning(self, "Aviso", "Informe um nome para a busca!")
            return

        if not camada or not campo_principal:
            QMessageBox.warning(self, "Aviso", "Selecione uma camada e um campo válido!")
            return

        campos = [campo_principal]
        if outros_campos:
            for c in outros_campos.split(","):
                if c.strip() and c.strip() not in campos:
                    campos.append(c.strip())

        self.buscas.append({
            "titulo": titulo,
            "camada": camada,
            "campos": campos
        })

        salvar_config_buscas(self.buscas)
        self.atualizar_lista()
        self.txt_nome.clear()
        self.txt_campos_adicionais.clear()
        QMessageBox.information(self, "Sucesso", "Busca cadastrada e salva no TXT com sucesso!")

    def remover_busca(self):
        row = self.list_widget.currentRow()
        if row >= 0:
            del self.buscas[row]
            salvar_config_buscas(self.buscas)
            self.atualizar_lista()


def abrir_gerenciador_buscas():
    """Abre a janela de configuração de buscas."""
    dlg = GerenciadorBuscasDialog(iface.mainWindow())
    dlg.exec_()