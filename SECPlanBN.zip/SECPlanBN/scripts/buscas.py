# scripts/buscas.py

from qgis.core import QgsProject
from qgis.utils import iface
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QCompleter, QDialogButtonBox, QMessageBox
from PyQt5.QtCore import Qt


def _executar_busca_com_autocompletar(nome_camada, campos_busca, titulo_janela, label_texto):
    """Função genérica para criar janela de busca com sugestões de autocompletar."""
    camadas = QgsProject.instance().mapLayersByName(nome_camada)

    if not camadas:
        iface.messageBar().pushCritical("Erro", f"A camada '{nome_camada}' não foi encontrada no projeto.")
        return

    layer = camadas[0]

    # Coleta sugestões únicas de todos os campos listados
    sugestoes = set()
    for campo in campos_busca:
        idx = layer.fields().indexOf(campo)
        if idx != -1:
            valores = layer.uniqueValues(idx)
            for val in valores:
                if val is not None and str(val).strip():
                    sugestoes.add(str(val).strip())

    sugestoes_ordenadas = sorted(list(sugestoes))

    # Criação do diálogo
    dialog = QDialog(iface.mainWindow())
    dialog.setWindowTitle(titulo_janela)
    dialog.resize(400, 120)

    layout = QVBoxLayout()
    layout.addWidget(QLabel(label_texto))

    input_texto = QLineEdit()

    # Configuração do Autocompletar
    completer = QCompleter(sugestoes_ordenadas)
    completer.setCaseSensitivity(Qt.CaseInsensitive)
    completer.setFilterMode(Qt.MatchContains)
    input_texto.setCompleter(completer)

    layout.addWidget(input_texto)

    botoes = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    botoes.accepted.connect(dialog.accept)
    botoes.rejected.connect(dialog.reject)
    layout.addWidget(botoes)

    dialog.setLayout(layout)

    if dialog.exec_() == QDialog.Accepted:
        texto_busca = input_texto.text().strip()
        if texto_busca:
            # Monta expressão condicional para verificar todos os campos informados
            condicoes = [f'"{campo}" ILIKE \'%{texto_busca}%\'' for campo in campos_busca]
            expressao = " OR ".join(condicoes)

            layer.selectByExpression(expressao)

            count = layer.selectedFeatureCount()
            if count > 0:
                iface.setActiveLayer(layer)
                iface.actionZoomToSelected().trigger()
                iface.messageBar().pushSuccess("Busca", f"{count} registro(s) encontrado(s) e selecionado(s).")
            else:
                iface.messageBar().pushWarning("Busca", f"Nenhum registro encontrado para '{texto_busca}'.")


def buscar_rua():
    """Busca por ruas na camada RUASOFICIAIS no campo 'nome'."""
    _executar_busca_com_autocompletar(
        nome_camada="RUASOFICIAIS",
        campos_busca=["nome"],
        titulo_janela="Buscar Rua",
        label_texto="Digite o nome da rua (com autocompletar):"
    )


def buscar_lote():
    """Busca por lotes na camada LOTES-BASE-PLANEJAMENTO nos campos 'cadastro' ou 'id_betha'."""
    _executar_busca_com_autocompletar(
        nome_camada="LOTES-BASE-PLANEJAMENTO",
        campos_busca=["cadastro", "id_betha"],
        titulo_janela="Buscar Lote",
        label_texto="Digite o Cadastro ou ID Betha do lote:"
    )