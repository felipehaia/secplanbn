from qgis.core import *
from qgis.gui import QgsMapToolCapture, QgsRubberBand
from PyQt5.QtWidgets import *
from PyQt5.QtXml import QDomDocument
from PyQt5.QtCore import Qt, QCoreApplication, QEventLoop, QObject, QEvent
from PyQt5.QtGui import QKeyEvent, QColor
import os
import re
import locale
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_BREAK
from qgis.utils import iface

# Configuração de Localização
try:
    locale.setlocale(locale.LC_TIME, 'pt_BR.utf-8')
except:
    try:
        locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil')
    except:
        pass

def sanitizar_nome(texto):
    if not texto:
        return "Nao_Identificado"
    texto = texto.replace('/', '-').replace('\\', '-')
    texto = re.sub(r'[<>:"|?*]', '-', texto)
    return " ".join(texto.split())

class KeyFilter(QObject):
    """Filtro de eventos de teclado para capturar Enter/Return e Esc"""
    def __init__(self, loop, parent=None):
        super().__init__(parent)
        self.loop = loop
        self.confirmed = False

    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress:
            key_event = QKeyEvent(event)
            if key_event.key() in (Qt.Key_Return, Qt.Key_Enter):
                self.confirmed = True
                self.loop.quit()
                return True
            elif key_event.key() == Qt.Key_Escape:
                self.confirmed = False
                self.loop.quit()
                return True
        return super().eventFilter(obj, event)

class FerramentaDesenharArea(QgsMapToolCapture):
    """Ferramenta interativa para capturar um polígono desenhado pelo usuário no canvas"""
    def __init__(self, canvas, loop):
        super().__init__(canvas, iface.cadDockWidget(), QgsMapToolCapture.CapturePolygon)
        self.canvas = canvas
        self.loop = loop
        self.geometria_resultado = None
        self.confirmed = False

    def cadCanvasReleaseEvent(self, event):
        if event.button() == Qt.RightButton:
            pts = self.points()
            if len(pts) >= 3:
                self.geometria_resultado = QgsGeometry.fromPolygonXY([pts])
                self.confirmed = True
            self.loop.quit()
        else:
            super().cadCanvasReleaseEvent(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.confirmed = False
            self.loop.quit()
        else:
            super().keyPressEvent(event)

def run():
    # --- CONFIGURAÇÕES DE NOMES ---
    layer_origem_nome = 'IDENTIFICAÇÃO-PARCELAMENTOS'
    layer_ruas_nome = 'RUASOFICIAIS'
    layer_destino_nome = 'ÁREA DE ESTUDO'
    estilos = ["PAVIMENTAÇÃO", "DRENAGEM", "REDE_DE_AGUA", 
               "REDE_ESGOTO", "ENERGIA", "ILUMINAÇÃO", "COLETA_LIXO"]

    project = QgsProject.instance()
    
    camadas_origem = project.mapLayersByName(layer_origem_nome)
    camadas_destino = project.mapLayersByName(layer_destino_nome)
    camadas_ruas = project.mapLayersByName(layer_ruas_nome)
    
    if not camadas_origem or not camadas_destino or not camadas_ruas:
        QMessageBox.critical(None, "Erro", "Uma ou mais camadas necessárias não foram encontradas no projeto.")
        return

    layer_origem = camadas_origem[0]
    layer_destino = camadas_destino[0]
    layer_ruas = camadas_ruas[0]

    # --- ETAPA 1: SELEÇÃO DO PARCELAMENTO (IMÓVEL) ---
    selected_features = layer_origem.selectedFeatures()

    if not selected_features:
        iface.setActiveLayer(layer_origem)
        iface.actionSelect().trigger()

        loop_origem = QEventLoop()
        key_filter_origem = KeyFilter(loop_origem)
        
        iface.mainWindow().installEventFilter(key_filter_origem)
        iface.mapCanvas().installEventFilter(key_filter_origem)

        msg_bar = iface.messageBar()
        item_origem = msg_bar.createMessage(
            "Seleção de Imóvel", 
            "Clique no imóvel desejado na camada IDENTIFICAÇÃO-PARCELAMENTOS. Pressione [ESC] para cancelar."
        )
        msg_bar.pushWidget(item_origem)

        def on_selection_origem():
            if layer_origem.selectedFeatureCount() > 0:
                key_filter_origem.confirmed = True
                loop_origem.quit()

        layer_origem.selectionChanged.connect(on_selection_origem)
        loop_origem.exec_()

        try:
            layer_origem.selectionChanged.disconnect(on_selection_origem)
        except:
            pass
        iface.mainWindow().removeEventFilter(key_filter_origem)
        iface.mapCanvas().removeEventFilter(key_filter_origem)
        msg_bar.clearWidgets()

        if not key_filter_origem.confirmed or layer_origem.selectedFeatureCount() == 0:
            return

        selected_features = layer_origem.selectedFeatures()

    # --- ETAPA 2: DEFINIÇÃO DA ÁREA DE ESTUDO (INTEGRAL OU PARCIAL) ---
    msg_box = QMessageBox()
    msg_box.setWindowTitle("Tipo de Recorte da Área de Estudo")
    msg_box.setText("Como deseja definir a área de estudo para os croquis do relatório?")
    btn_integral = msg_box.addButton("Todo o Parcelamento (Integral)", QMessageBox.AcceptRole)
    btn_parcial = msg_box.addButton("Desenhar Área Parcial no Mapa", QMessageBox.ActionRole)
    btn_cancelar = msg_box.addButton("Cancelar", QMessageBox.RejectRole)
    
    msg_box.exec_()
    clicado = msg_box.clickedButton()

    if clicado == btn_cancelar:
        return

    geometria_estudo_custom = None

    if clicado == btn_parcial:
        loop_desenho = QEventLoop()
        tool_desenho = FerramentaDesenharArea(iface.mapCanvas(), loop_desenho)
        tool_anterior = iface.mapCanvas().mapTool()
        iface.mapCanvas().setMapTool(tool_desenho)

        msg_bar = iface.messageBar()
        item_desenho = msg_bar.createMessage(
            "Desenhar Área Parcial", 
            "Clique no mapa para marcar os vértices do polígono. [Clique Direito] para finalizar ou [ESC] para cancelar."
        )
        msg_bar.pushWidget(item_desenho)

        loop_desenho.exec_()

        iface.mapCanvas().setMapTool(tool_anterior)
        msg_bar.clearWidgets()

        if not tool_desenho.confirmed or tool_desenho.geometria_resultado is None:
            QMessageBox.warning(None, "Aviso", "Desenho da área parcial cancelado.")
            return

        geometria_estudo_custom = tool_desenho.geometria_resultado

    # --- ETAPA 3: SELEÇÃO DAS VIAS (MÚLTIPLOS ELEMENTOS) ---
    iface.setActiveLayer(layer_ruas)
    iface.actionSelect().trigger()

    loop_ruas = QEventLoop()
    key_filter_ruas = KeyFilter(loop_ruas)
    
    iface.mainWindow().installEventFilter(key_filter_ruas)
    iface.mapCanvas().installEventFilter(key_filter_ruas)

    msg_bar = iface.messageBar()
    item_ruas = msg_bar.createMessage(
        "Seleção de Vias", 
        "Selecione na tela as vias desejadas. Pressione [ENTER] para confirmar ou [ESC] para cancelar."
    )
    
    btn_confirmar = QPushButton("Concluir Seleção")
    btn_confirmar.clicked.connect(lambda: set_and_quit_ruas(True))
    item_ruas.layout().addWidget(btn_confirmar)

    def set_and_quit_ruas(status):
        key_filter_ruas.confirmed = status
        loop_ruas.quit()

    msg_bar.pushWidget(item_ruas)
    loop_ruas.exec_()

    iface.mainWindow().removeEventFilter(key_filter_ruas)
    iface.mapCanvas().removeEventFilter(key_filter_ruas)
    msg_bar.clearWidgets()

    if not key_filter_ruas.confirmed:
        return

    ruas_selecionadas = layer_ruas.selectedFeatures()
    if not ruas_selecionadas:
        QMessageBox.warning(None, "Aviso", "Nenhuma via foi selecionada. Operação cancelada.")
        return

    # --- CONFIGURAÇÃO DE PASTAS ---
    script_dir = os.path.dirname(os.path.abspath(__file__))
    raiz_dir = os.path.dirname(script_dir)
    template_word = os.path.normpath(os.path.join(script_dir, "modelos", "modelo_infra.docx"))
    path_to_qpt = os.path.normpath(os.path.join(raiz_dir, "layouts", "infraestrutura.qpt"))

    output_folder = QFileDialog.getExistingDirectory(None, "1. Pasta para salvar os arquivos")
    if not output_folder: return
    
    photos_folder = None
    resp = QMessageBox.question(None, "Fotos", "Deseja adicionar as fotos no relatório?", QMessageBox.Yes | QMessageBox.No)
    if resp == QMessageBox.Yes:
        photos_folder = QFileDialog.getExistingDirectory(None, "2. Selecione a pasta com as fotos das ruas")

    progressMessageBar = iface.messageBar().createMessage("Gerando Pareceres Técnicos...")
    progress = QProgressBar()
    progress.setMaximum(len(selected_features))
    progressMessageBar.layout().addWidget(progress)
    iface.messageBar().pushWidget(progressMessageBar)

    def get_attr_safe(feat, field_name):
        idx = feat.fields().indexOf(field_name)
        if idx != -1:
            val = feat.attributes()[idx]
            if val is not None and str(val).strip() != "" and str(val).lower() != 'null':
                return str(val).strip()
        return "Não identificado"

    for i, feature in enumerate(selected_features):
        progress.setValue(i)
        QCoreApplication.processEvents() 

        geom_estudo = geometria_estudo_custom if geometria_estudo_custom else feature.geometry()

        # --- CÓPIA PARA ÁREA DE ESTUDO ---
        layer_destino.startEditing()
        layer_destino.deleteFeatures([f.id() for f in layer_destino.getFeatures()])
        nova_feat = QgsFeature(layer_destino.fields())
        nova_feat.setGeometry(geom_estudo)
        layer_destino.addFeature(nova_feat)
        layer_destino.commitChanges()

        centroide = geom_estudo.centroid().asPoint()
        
        contexto = {
            "nome": get_attr_safe(feature, "nome"),
            "protocolo": get_attr_safe(feature, "protocolo"),
            "propri": get_attr_safe(feature, "propri"),
            "endereco": get_attr_safe(feature, "endereco"),
            "matricula": get_attr_safe(feature, "matricula"),
            "n_processo": get_attr_safe(feature, "n_processo"),
            "coord": f"X: {centroide.x():.2f}, Y: {centroide.y():.2f}",
            "data": datetime.now().strftime('%d de %B de %Y')
        }

        doc_word = Document(template_word)

        # 1. Geração de Croquis
        mapas_gerados = []
        layout = QgsPrintLayout(project)
        try:
            with open(path_to_qpt, 'r', encoding='utf-8') as f:
                doc_xml = QDomDocument()
                doc_xml.setContent(f.read())
                layout.readXml(doc_xml.documentElement(), doc_xml, QgsReadWriteContext())
            
            map_item = next((it for it in layout.items() if isinstance(it, QgsLayoutItemMap)), None)
            if map_item:
                ext = geom_estudo.boundingBox()
                ext.grow(80)
                map_item.zoomToExtent(ext)
                exporter = QgsLayoutExporter(layout)
                
                for est in estilos:
                    layer_ruas.styleManager().setCurrentStyle(est)
                    layer_ruas.triggerRepaint()
                    map_item.refresh()
                    img_path = os.path.join(output_folder, f"TEMP_{est}.png")
                    exporter.exportToImage(img_path, QgsLayoutExporter.ImageExportSettings())
                    mapas_gerados.append((img_path, est))
        except Exception as e:
            print(f"Erro ao gerar mapas: {e}")

        for p in doc_word.paragraphs:
            if "{{ croquis }}" in p.text:
                p.text = ""
                for idx, (img_path, est_name) in enumerate(mapas_gerados):
                    p.add_run().add_break(WD_BREAK.PAGE)
                    p.alignment = 1
                    tipo_infra = est_name.replace("_", " ").upper()
                    run_tit = p.add_run(f"ANÁLISE DE INFRAESTRUTURA: {tipo_infra}\n")
                    run_tit.bold = True
                    p.add_run().add_picture(img_path, width=Inches(5.0))
                    p.add_run("\n")

        # 2. Infraestrutura e Fotos
        for p in doc_word.paragraphs:
            if "{{ TABELA_INFRA }}" in p.text:
                p.text = ""
                ruas_com_fotos_ja_inseridas = [] 
                
                for f_rua in ruas_selecionadas:
                    nome_viva = (str(f_rua["nome"]) if f_rua["nome"] else "NÃO IDENTIFICADA").upper()
                    id_trecho = f_rua["id_0"]
                    largura = get_attr_safe(f_rua, "largura")

                    run_tit = p.add_run(f"VIA: {nome_viva} (Trecho Ref: {id_trecho})\n")
                    run_tit.bold = True
                    
                    pav = str(f_rua["pavimentacao"]).upper()
                    status_pav = f"A via possui pavimentação do tipo {pav}." if pav not in ["NÃO", "NÃO POSSUI", "NULL", ""] else "A via não possui pavimentação oficial."
                    def txt_infra(campo, pos, neg): return pos if str(f_rua[campo]).upper() == "SIM" else neg

                    desc = (f"  - {status_pav}\n"
                            f"  - {txt_infra('rede_agua', 'É provida de rede de abastecimento de água potável.', 'Inexistência de rede de abastecimento de água.')}\n"
                            f"  - {txt_infra('rede_drenagem', 'Possui sistema de drenagem pluvial implantado.', 'Inexistência de sistema de drenagem pluvial.')}\n"
                            f"  - {txt_infra('rede_esgoto', 'Contemplada com rede de esgotamento sanitário.', 'Inexistência de rede de esgoto sanitário.')}\n"
                            f"  - {txt_infra('rede_energia', 'Contemplada com rede de energia elétrica.', 'Inexistência de rede de energia elétrica.')}\n"
                            f"  - {txt_infra('iluminacao', 'Contemplada iluminação pública.', 'Inexistência de iluminação pública.')}\n"
                            f"  - Largura do trecho: {largura if largura != 'Não identificado' else 'Não informada'}\n")
                    p.add_run(desc + "\n")

                    if photos_folder and nome_viva not in ruas_com_fotos_ja_inseridas:
                        try:
                            fotos_rua = [f for f in os.listdir(photos_folder) if nome_viva.lower() in f.lower() and f.lower().endswith(('.jpg', '.png', '.jpeg'))]
                            for foto in fotos_rua:
                                p_f = doc_word.add_paragraph(); p_f.alignment = 1
                                p_f.add_run().add_picture(os.path.join(photos_folder, foto), width=Inches(4.5))
                                p_l = doc_word.add_paragraph(); p_l.alignment = 1
                                r_l = p_l.add_run(f"Registro fotográfico da Via: {nome_viva}"); r_l.italic = True; r_l.font.size = Pt(9)
                            ruas_com_fotos_ja_inseridas.append(nome_viva)
                        except: pass

        # 3. Tags Gerais
        for p in doc_word.paragraphs:
            for chave, valor in contexto.items():
                tag = f"{{{{ {chave} }}}}"
                if tag in p.text: p.text = p.text.replace(tag, str(valor))

        # --- SALVAMENTO ---
        nome_limpo = sanitizar_nome(contexto['nome'])
        protocolo_limpo = sanitizar_nome(contexto['protocolo'])
        nome_arquivo = f"PARECER_INFRA_{nome_limpo}_{protocolo_limpo}.docx"
        caminho_final = os.path.normpath(os.path.join(output_folder, nome_arquivo))

        try:
            doc_word.save(caminho_final)
        except Exception as e:
            QMessageBox.critical(None, "Erro", f"Erro ao salvar:\n{e}")

        # --- LIMPEZA DA CAMADA 'ÁREA DE ESTUDO' ---
        layer_destino.startEditing()
        layer_destino.deleteFeatures([f.id() for f in layer_destino.getFeatures()])
        layer_destino.commitChanges()
        layer_destino.triggerRepaint()

    # --- LIMPEZA DE SELEÇÕES NAS CAMADAS DO QGIS ---
    layer_origem.removeSelection()
    layer_ruas.removeSelection()

    progress.setValue(len(selected_features))
    for img_path, _ in mapas_gerados:
        try: os.remove(img_path)
        except: pass

    iface.messageBar().clearWidgets()
    QMessageBox.information(None, "Concluído", "Processo finalizado com sucesso!")
    os.startfile(output_folder)