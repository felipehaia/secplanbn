from qgis.core import *
from PyQt5.QtWidgets import *
from PyQt5.QtXml import QDomDocument
from PyQt5.QtCore import Qt, QCoreApplication
import os
import re
import locale
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_BREAK
from qgis.utils import iface

# Configuração de Localização
try:
    locale.setlocale(locale.LC_TIME, 'pt_BR.utf-8')
except:
    try:
        locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil')
    except:
        pass

def sanitizar_nome(texto):
    if not texto:
        return "Nao_Identificado"
    texto = texto.replace('/', '-').replace('\\', '-')
    texto = re.sub(r'[<>:"|?*]', '-', texto)
    return " ".join(texto.split())

def run():
    # --- CONFIGURAÇÕES DE NOMES ---
    layer_origem_nome = 'IDENTIFICAÇÃO-PARCELAMENTOS'
    layer_ruas_nome = 'RUASOFICIAIS'
    layer_destino_nome = 'ÁREA DE ESTUDO'
    estilos = ["PAVIMENTAÇÃO", "DRENAGEM", "REDE_DE_AGUA", 
               "REDE_ESGOTO", "ENERGIA", "ILUMINAÇÃO", "COLETA_LIXO"]

    project = QgsProject.instance()
    
    camadas_origem = project.mapLayersByName(layer_origem_nome)
    camadas_destino = project.mapLayersByName(layer_destino_nome)
    
    if not camadas_origem:
        QMessageBox.critical(None, "Erro", f"Camada '{layer_origem_nome}' não encontrada.")
        return
    if not camadas_destino:
        QMessageBox.critical(None, "Erro", f"Camada '{layer_destino_nome}' não encontrada.")
        return

    layer_origem = camadas_origem[0]
    layer_destino = camadas_destino[0]
    
    selected_features = layer_origem.selectedFeatures()
    if not selected_features:
        QMessageBox.warning(None, "Aviso", "Selecione o imóvel na camada IDENTIFICAÇÃO-PARCELAMENTOS.")
        return

    script_dir = os.path.dirname(os.path.abspath(__file__))
    raiz_dir = os.path.dirname(script_dir)
    template_word = os.path.normpath(os.path.join(script_dir, "modelos", "modelo_infra.docx"))
    path_to_qpt = os.path.normpath(os.path.join(raiz_dir, "layouts", "infraestrutura.qpt"))

    output_folder = QFileDialog.getExistingDirectory(None, "1. Pasta para salvar os arquivos")
    if not output_folder: return
    
    photos_folder = None
    resp = QMessageBox.question(None, "Fotos", "Deseja adicionar as fotos no relatório?", QMessageBox.Yes | QMessageBox.No)
    if resp == QMessageBox.Yes:
        photos_folder = QFileDialog.getExistingDirectory(None, "2. Selecione a pasta com as fotos das ruas")

    progressMessageBar = iface.messageBar().createMessage("Gerando Pareceres Técnicos...")
    progress = QProgressBar()
    progress.setMaximum(len(selected_features))
    progressMessageBar.layout().addWidget(progress)
    iface.messageBar().pushWidget(progressMessageBar)

    def get_attr_safe(feat, field_name):
        idx = feat.fields().indexOf(field_name)
        if idx != -1:
            val = feat.attributes()[idx]
            if val is not None and str(val).strip() != "" and str(val).lower() != 'null':
                return str(val).strip()
        return "Nao_identificado"

    for i, feature in enumerate(selected_features):
        progress.setValue(i)
        QCoreApplication.processEvents() 

        # --- CÓPIA PARA ÁREA DE ESTUDO ---
        layer_destino.startEditing()
        layer_destino.deleteFeatures([f.id() for f in layer_destino.getFeatures()])
        nova_feat = QgsFeature(layer_destino.fields())
        nova_feat.setGeometry(feature.geometry())
        layer_destino.addFeature(nova_feat)
        layer_destino.commitChanges()

        geom = feature.geometry()
        centroide = geom.centroid().asPoint()
        
        contexto = {
            "nome": get_attr_safe(feature, "nome"),
            "protocolo": get_attr_safe(feature, "protocolo"),
            "propri": get_attr_safe(feature, "propri"),
            "endereco": get_attr_safe(feature, "endereco"),
            "matricula": get_attr_safe(feature, "matricula"),
            "n_processo": get_attr_safe(feature, "n_processo"),
            "coord": f"X: {centroide.x():.2f}, Y: {centroide.y():.2f}",
            "data": datetime.now().strftime('%d de %B de %Y')
        }

        doc_word = Document(template_word)

        # 1. Geração de Croquis
        mapas_gerados = []
        layout = QgsPrintLayout(project)
        try:
            with open(path_to_qpt, 'r', encoding='utf-8') as f:
                doc_xml = QDomDocument()
                doc_xml.setContent(f.read())
                layout.readXml(doc_xml.documentElement(), doc_xml, QgsReadWriteContext())
            
            map_item = next((it for it in layout.items() if isinstance(it, QgsLayoutItemMap)), None)
            if map_item:
                ext = geom.boundingBox()
                ext.grow(80)
                map_item.zoomToExtent(ext)
                exporter = QgsLayoutExporter(layout)
                
                layer_ruas = project.mapLayersByName(layer_ruas_nome)[0]
                for est in estilos:
                    layer_ruas.styleManager().setCurrentStyle(est)
                    layer_ruas.triggerRepaint()
                    map_item.refresh()
                    img_path = os.path.join(output_folder, f"TEMP_{est}.png")
                    exporter.exportToImage(img_path, QgsLayoutExporter.ImageExportSettings())
                    mapas_gerados.append((img_path, est))
        except Exception as e:
            print(f"Erro ao gerar mapas: {e}")

        for p in doc_word.paragraphs:
            if "{{ croquis }}" in p.text:
                p.text = ""
                for idx, (img_path, est_name) in enumerate(mapas_gerados):
                    p.add_run().add_break(WD_BREAK.PAGE)
                    p.alignment = 1
                    tipo_infra = est_name.replace("_", " ").upper()
                    run_tit = p.add_run(f"ANÁLISE DE INFRAESTRUTURA: {tipo_infra}\n")
                    run_tit.bold = True
                    p.add_run().add_picture(img_path, width=Inches(5.0))
                    p.add_run("\n")

        # 2. Infraestrutura e Fotos (COM FILTRO DE 10 METROS)
        for p in doc_word.paragraphs:
            if "{{ TABELA_INFRA }}" in p.text:
                p.text = ""
                layer_ruas = project.mapLayersByName(layer_ruas_nome)[0]
                ruas_com_fotos_ja_inseridas = [] 
                
                for f_rua in layer_ruas.getFeatures():
                    geom_rua = f_rua.geometry()
                    
                    # Filtro 1: A feição inteira da rua deve ter pelo menos 10m
                    if geom_rua.length() < 10.0:
                        continue
                    
                    # Filtro 2: Verifica interseção física
                    if geom_rua.intersects(geom):
                        # Calcula a parte da rua que está DENTRO do polígono
                        intersecao = geom_rua.intersection(geom)
                        comprimento_interno = intersecao.length()
                        
                        # Filtro 3: A incidência dentro do polígono deve ser >= 10m
                        if comprimento_interno >= 10.0:
                            nome_viva = (str(f_rua["nome"]) if f_rua["nome"] else "NÃO IDENTIFICADA").upper()
                            id_trecho = f_rua["id_0"]
                            run_tit = p.add_run(f"VIA: {nome_viva} (Trecho Ref: {id_trecho})\n")
                            run_tit.bold = True
                            
                            pav = str(f_rua["pavimentacao"]).upper()
                            status_pav = f"A via possui pavimentação do tipo {pav}." if pav not in ["NÃO", "NÃO POSSUI", "NULL", ""] else "A via não possui pavimentação oficial."
                            def txt_infra(campo, pos, neg): return pos if str(f_rua[campo]).upper() == "SIM" else neg

                            desc = (f"  - {status_pav}\n"
                                    f"  - {txt_infra('rede_agua', 'É provida de rede de abastecimento de água potável.', 'Inexistência de rede de abastecimento de água.')}\n"
                                    f"  - {txt_infra('rede_drenagem', 'Possui sistema de drenagem pluvial implantado.', 'Inexistência de sistema de drenagem pluvial.')}\n"
                                    f"  - {txt_infra('rede_esgoto', 'Contemplada com rede de esgotamento sanitário.', 'Inexistência de rede de esgoto sanitário.')}\n"
                                    f"  - {txt_infra('rede_energia', 'Contemplada com rede de energia elétrica.', 'Inexistência de rede de energia elétrica.')}\n"
                                    f"  - {txt_infra('iluminacao', 'Contemplada iluminação pública.', 'Inexistência de iluminação pública.')}\n")
                            p.add_run(desc + "\n")

                            if photos_folder and nome_viva not in ruas_com_fotos_ja_inseridas:
                                try:
                                    fotos_rua = [f for f in os.listdir(photos_folder) if nome_viva.lower() in f.lower() and f.lower().endswith(('.jpg', '.png', '.jpeg'))]
                                    for foto in fotos_rua:
                                        p_f = doc_word.add_paragraph(); p_f.alignment = 1
                                        p_f.add_run().add_picture(os.path.join(photos_folder, foto), width=Inches(4.5))
                                        p_l = doc_word.add_paragraph(); p_l.alignment = 1
                                        r_l = p_l.add_run(f"Registro fotográfico da Via: {nome_viva}"); r_l.italic = True; r_l.font.size = Pt(9)
                                    ruas_com_fotos_ja_inseridas.append(nome_viva)
                                except: pass

        # 3. Tags Gerais
        for p in doc_word.paragraphs:
            for chave, valor in contexto.items():
                tag = f"{{{{ {chave} }}}}"
                if tag in p.text: p.text = p.text.replace(tag, str(valor))

        # --- SALVAMENTO ---
        nome_limpo = sanitizar_nome(contexto['nome'])
        protocolo_limpo = sanitizar_nome(contexto['protocolo'])
        nome_arquivo = f"PARECER_INFRA_{nome_limpo}_{protocolo_limpo}.docx"
        caminho_final_abs = os.path.abspath(os.path.join(output_folder, nome_arquivo))
        path_para_salvar = ("\\\\?\\UNC\\" + caminho_final_abs[2:]) if caminho_final_abs.startswith("\\\\") else ("\\\\?\\" + caminho_final_abs)

        try:
            os.makedirs(os.path.dirname(caminho_final_abs), exist_ok=True)
            doc_word.save(path_para_salvar)
        except Exception as e:
            QMessageBox.critical(None, "Erro", f"Erro ao salvar:\n{e}")

    progress.setValue(len(selected_features))
    for img_path, _ in mapas_gerados:
        try: os.remove(img_path)
        except: pass

    iface.messageBar().clearWidgets()
    QMessageBox.information(None, "Concluído", "Processo finalizado com sucesso!")
    os.startfile(output_folder)