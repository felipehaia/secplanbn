import re
import unicodedata
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsCoordinateTransform
)
from qgis.PyQt.QtCore import QVariant

# --- VARIÁVEIS DE ENTRADA ---
LOTES = 'LOTES-BASE-PLANEJAMENTO'
RUAS = 'gerador_numero'
RUAS_OFICIAIS = 'RUASOFICIAIS'
CAMPO_RUA_LOTE = 'endereco_betha'
CAMPO_NOME_RUA = 'NOME'
CAMPO_NUM_INICIAL = 'NUMERO_INICIAL'
OUTPUT = 'numeros_oficial_novo'

DISTANCIA_MAX_METROS = 35.0  # Limite de tolerância da testada até o eixo da rua

def remover_acentos(texto):
    """Remove caracteres acentuados mantendo o texto limpo."""
    if not texto or str(texto) == 'NULL':
        return ""
    nfkd = unicodedata.normalize('NFD', str(texto))
    return "".join([c for c in nfkd if not unicodedata.combining(c)])

def normalizar_nome_rua(texto):
    """
    Padroniza o nome da rua para comparação fuzzy.
    Remove prefixos (R., Rua, Av., Avenida, etc.) e caracteres especiais.
    """
    if not texto:
        return ""
    txt = remover_acentos(texto).upper().strip()
    txt = re.sub(r'^(RUA|R\.|AVENIDA|AV\.|RODOVIA|ROD\.|TRAVESSA|TRV\.|ALAMEDA|AL\.|SERVIDAO|SERV\.|PRACA|PRC\.)\s+', '', txt)
    txt = re.sub(r'^(RUA|R\.)\s+', '', txt)
    txt = re.sub(r'[^\w\s]', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return txt.lower()

def identificar_lado_da_rua(geom_rua, ponto_ref, dist_ao_longo_da_rua):
    """
    Retorna 'esquerda' ou 'direita' calculando o produto vetorial 2D 
    com proteção para finais de linha e geometrias nulas.
    """
    comprimento_total = geom_rua.length()
    
    if dist_ao_longo_da_rua + 0.1 > comprimento_total:
        geom_p0 = geom_rua.interpolate(max(0.0, dist_ao_longo_da_rua - 0.1))
        geom_p1 = geom_rua.interpolate(dist_ao_longo_da_rua)
    else:
        geom_p0 = geom_rua.interpolate(dist_ao_longo_da_rua)
        geom_p1 = geom_rua.interpolate(dist_ao_longo_da_rua + 0.1)

    if geom_p0.isEmpty() or geom_p1.isEmpty() or ponto_ref.isEmpty():
        return 'direita'

    p0 = geom_p0.asPoint()
    p1 = geom_p1.asPoint()
    p_lote = ponto_ref.asPoint()

    det = (p1.x() - p0.x()) * (p_lote.y() - p0.y()) - (p1.y() - p0.y()) * (p_lote.x() - p0.x())

    return 'esquerda' if det > 0 else 'direita'

# --- BUSCA E VALIDAÇÃO DAS CAMADAS ---
SRC_PROJETO = QgsProject.instance().crs()
lotes_layers = QgsProject.instance().mapLayersByName(LOTES)
ruas_layers = QgsProject.instance().mapLayersByName(RUAS)
ruas_oficiais_layers = QgsProject.instance().mapLayersByName(RUAS_OFICIAIS)

if not lotes_layers or not ruas_layers:
    raise ValueError(f"Certifique-se de que as camadas '{LOTES}' e '{RUAS}' estão abertas no projeto.")

lotes_layer = lotes_layers[0]
ruas_layer = ruas_layers[0]
ruas_oficiais_layer = ruas_oficiais_layers[0] if ruas_oficiais_layers else None

transform_lote = QgsCoordinateTransform(lotes_layer.crs(), SRC_PROJETO, QgsProject.instance())
transform_rua = QgsCoordinateTransform(ruas_layer.crs(), SRC_PROJETO, QgsProject.instance())

# --- INDEXAÇÃO DA CAMADA RUASOFICIAIS ---
dict_ruas_oficiais = {}
if ruas_oficiais_layer:
    for feat in ruas_oficiais_layer.getFeatures():
        nome_original = str(feat[CAMPO_NOME_RUA]).strip() if feat[CAMPO_NOME_RUA] not in [None, 'NULL'] else ""
        nome_norm = normalizar_nome_rua(nome_original)
        if nome_norm and nome_norm not in dict_ruas_oficiais:
            dict_ruas_oficiais[nome_norm] = nome_original

# --- INDEXAÇÃO DAS RUAS DE GERADOR ---
ruas_dict = {}
tem_campo_num_inicial = CAMPO_NUM_INICIAL in [f.name() for f in ruas_layer.fields()]

for feat in ruas_layer.getFeatures():
    nome_norm = normalizar_nome_rua(feat[CAMPO_NOME_RUA])
    if nome_norm:
        geom = feat.geometry()
        geom.transform(transform_rua)
        
        offset_num = 0
        if tem_campo_num_inicial and feat[CAMPO_NUM_INICIAL] not in [None, 'NULL', '']:
            try:
                offset_num = int(feat[CAMPO_NUM_INICIAL])
            except (ValueError, TypeError):
                offset_num = 0

        ruas_dict[nome_norm] = {
            'geometry': geom,
            'offset': offset_num
        }

# --- CRIAÇÃO DA CAMADA DE SAÍDA ---
output_layer = QgsVectorLayer(f"Point?crs={SRC_PROJETO.authid()}", OUTPUT, "memory")
dp = output_layer.dataProvider()

fields = QgsFields()
fields.append(QgsField("id_lote", QVariant.LongLong))
fields.append(QgsField(CAMPO_RUA_LOTE, QVariant.String))
fields.append(QgsField("rua", QVariant.String))  # Nome oficial cruzado da camada RUASOFICIAIS
fields.append(QgsField("imoveis_Numero", QVariant.Int))
fields.append(QgsField("lado_rua", QVariant.String))
fields.append(QgsField("dist_rua_m", QVariant.Double))
fields.append(QgsField("num_inicial_usado", QVariant.Int))
dp.addAttributes(fields)
output_layer.updateFields()

# --- PROCESSAMENTO ---
novos_pontos = []
fora_do_raio = 0

for lote in lotes_layer.getFeatures():
    nome_lote_original = str(lote[CAMPO_RUA_LOTE]).strip() if lote[CAMPO_RUA_LOTE] not in [None, 'NULL'] else ""
    nome_lote_norm = normalizar_nome_rua(nome_lote_original)

    if nome_lote_norm in ruas_dict:
        dados_rua = ruas_dict[nome_lote_norm]
        geom_rua = dados_rua['geometry']
        offset_rua = dados_rua['offset']
        
        geom_lote = lote.geometry()
        geom_lote.transform(transform_lote)

        # Distância da testada do lote ao eixo da via
        afastamento_borda = geom_rua.distance(geom_lote)

        if afastamento_borda <= DISTANCIA_MAX_METROS:
            # Ponto interno do lote
            ponto_ref = geom_lote.poleOfInaccessibility(0.1)[0]
            if ponto_ref.isEmpty():
                ponto_ref = geom_lote.centroid()

            # 1. Distância medida na linha
            distancia_rua = geom_rua.lineLocatePoint(ponto_ref)

            # 2. Offset / Calibração
            num_base = round(distancia_rua) + offset_rua

            # 3. Identifica lado da rua
            lado = identificar_lado_da_rua(geom_rua, ponto_ref, distancia_rua)

            # 4. Regra Par / Ímpar
            if lado == 'esquerda':
                numero_final = num_base if num_base % 2 != 0 else num_base + 1
            else:
                numero_final = num_base if num_base % 2 == 0 else num_base + 1

            # Cruzamento com a camada RUASOFICIAIS
            nome_oficial = dict_ruas_oficiais.get(nome_lote_norm, nome_lote_original)

            feat = QgsFeature()
            feat.setGeometry(ponto_ref)
            feat.setAttributes([
                lote.id(),
                lote[CAMPO_RUA_LOTE],
                nome_oficial,
                numero_final,
                lado,
                round(afastamento_borda, 2),
                offset_rua
            ])
            novos_pontos.append(feat)
        else:
            fora_do_raio += 1

# Insere os pontos na camada temporária
if novos_pontos:
    dp.addFeatures(novos_pontos)
    output_layer.updateExtents()
    QgsProject.instance().addMapLayer(output_layer)
    print(f"✅ SUCESSO! {len(novos_pontos)} pontos foram gerados na camada '{OUTPUT}'.")