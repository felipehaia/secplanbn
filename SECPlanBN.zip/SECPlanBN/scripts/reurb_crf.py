from qgis.core import *
from qgis.gui import QgisInterface
from qgis.utils import iface
from PyQt5.QtWidgets import *
from PyQt5.QtXml import QDomDocument
from PyQt5.QtCore import QVariant
import os
import re
from docx import Document
from datetime import datetime
import locale
import json

# Tentativa de importação da biblioteca para conversão em PDF
try:
    import win32com.client
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False

# ============================================================
# CONFIGURAÇÃO DE NOMES DAS CAMADAS (FÁCIL MANUTENÇÃO)
# ============================================================
NOME_CAMADA_LOTES = "lotes_reurb"
NOME_CAMADA_LEGITIMADOS = "legitimados_reurb"
NOME_CAMADA_NUCLEOS = "IDENTIFICAÇÃO-PARCELAMENTOS"

# Mapeamento dos nomes amigáveis para os respectivos arquivos de template
TEMPLATES_DISPONIVEIS = {
    "CRF sem área": "modelo_crf.docx",
    "CRF com área": "modelo_crf_02.docx",
    "Certificado de Conclusão": "convite_crf.docx",
    "Outros...": None
}

# ============================================================
# 1) CLASSE DE DIÁLOGO PARA ENTRADA DE DADOS (UX INTEGRADA)
# ============================================================
class ReurbInfoDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gerar CRF")
        self.setMinimumWidth(480)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        # 1. Secretário
        layout.addWidget(QLabel("Nome do Secretário:"))
        self.txt_secretario = QLineEdit()
        self.txt_secretario.setText("NOME DO SECRETÁRIO")
        layout.addWidget(self.txt_secretario)

        # 2. Seleção de Template
        layout.addWidget(QLabel("Modelo de Template:"))
        self.combo_template = QComboBox()
        self.combo_template.addItems(list(TEMPLATES_DISPONIVEIS.keys()))
        layout.addWidget(self.combo_template)

        # 2.1. Container para Template Personalizado (Outros...)
        self.widget_custom_template = QWidget()
        custom_layout = QHBoxLayout(self.widget_custom_template)
        custom_layout.setContentsMargins(0, 0, 0, 0)
        
        self.txt_custom_template = QLineEdit()
        self.txt_custom_template.setPlaceholderText("Selecione o arquivo .docx do template...")
        self.btn_browse_template = QPushButton("Buscar...")
        self.btn_browse_template.clicked.connect(self.selecionar_template_custom)
        
        custom_layout.addWidget(self.txt_custom_template)
        custom_layout.addWidget(self.btn_browse_template)
        
        layout.addWidget(self.widget_custom_template)
        self.widget_custom_template.setVisible(False)  # Oculto por padrão

        # 3. Formato de Exportação
        layout.addWidget(QLabel("Formato de Exportação:"))
        self.combo_formato = QComboBox()
        self.combo_formato.addItems(["Word (.docx)", "PDF (.pdf)"])
        layout.addWidget(self.combo_formato)

        # 4. Pasta de Saída
        layout.addWidget(QLabel("Pasta de Destino:"))
        output_layout = QHBoxLayout()
        self.txt_output_folder = QLineEdit()
        self.txt_output_folder.setPlaceholderText("Selecione a pasta onde os arquivos serão salvos...")
        self.btn_browse_output = QPushButton("Selecionar Pasta...")
        self.btn_browse_output.clicked.connect(self.selecionar_pasta_destino)
        
        output_layout.addWidget(self.txt_output_folder)
        output_layout.addWidget(self.btn_browse_output)
        layout.addLayout(output_layout)

        # Sinais
        self.combo_template.currentIndexChanged.connect(self.on_template_changed)

        # Botões da Janela
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, parent=self)
        buttons.accepted.connect(self.validar_e_aceitar)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def on_template_changed(self):
        """Exibe o campo de busca de template apenas quando 'Outros...' for selecionado"""
        is_outro = self.combo_template.currentText() == "Outros..."
        self.widget_custom_template.setVisible(is_outro)
        self.adjustSize()

    def selecionar_template_custom(self):
        caminho, _ = QFileDialog.getOpenFileName(
            self, 
            "Selecione o Template Word", 
            "", 
            "Documentos Word (*.docx)"
        )
        if caminho:
            self.txt_custom_template.setText(caminho)

    def selecionar_pasta_destino(self):
        pasta = QFileDialog.getExistingDirectory(self, "Selecione a Pasta de Destino")
        if pasta:
            self.txt_output_folder.setText(pasta)

    def validar_e_aceitar(self):
        """Valida os dados antes de fechar a janela com OK"""
        if self.combo_template.currentText() == "Outros...":
            custom_path = self.txt_custom_template.text().strip()
            if not custom_path or not os.path.exists(custom_path):
                QMessageBox.warning(self, "Aviso", "Por favor, selecione um arquivo de template válido (.docx).")
                return

        if not self.txt_output_folder.text().strip():
            QMessageBox.warning(self, "Aviso", "Por favor, selecione a pasta de destino dos arquivos.")
            return

        self.accept()

    def get_values(self):
        item_template = self.combo_template.currentText()
        if item_template == "Outros...":
            path_template = self.txt_custom_template.text().strip()
        else:
            nome_arquivo = TEMPLATES_DISPONIVEIS.get(item_template, "modelo_crf.docx")
            plugin_dir = os.path.dirname(__file__)
            path_template = os.path.join(plugin_dir, "modelos", nome_arquivo)

        return {
            "secretario": self.txt_secretario.text().strip(),
            "template_option": item_template,
            "template_path": path_template,
            "formato": self.combo_formato.currentText(),
            "output_folder": self.txt_output_folder.text().strip()
        }

# ============================================================
# 2) FUNÇÃO PRINCIPAL DE EXECUÇÃO
# ============================================================
def run():
    print("Iniciando Exportação REURB...")

    # --- VERIFICAÇÃO SILENCIOSA DE CAMADAS (Ao Clicar) ---
    project = QgsProject.instance()
    layer_lotes = project.mapLayersByName(NOME_CAMADA_LOTES)
    layer_legitimados = project.mapLayersByName(NOME_CAMADA_LEGITIMADOS)
    layer_nucleos = project.mapLayersByName(NOME_CAMADA_NUCLEOS)

    # Se clicar no botão sem as camadas estarem abertas, apenas avisa na barra amarela do QGIS
    if not layer_lotes or not layer_legitimados or not layer_nucleos:
        iface.messageBar().pushMessage(
            "Aviso REURB",
            f"Camadas REURB não encontradas. Abra o projeto com a camada '{NOME_CAMADA_LOTES}'.",
            level=Qgis.Warning,
            duration=5
        )
        return

    lyr_lote = layer_lotes[0]
    lyr_prop = layer_legitimados[0]
    lyr_nuc = layer_nucleos[0]

    # Verifica se há objetos selecionados na camada de lotes
    selected_lotes = lyr_lote.selectedFeatures()
    if not selected_lotes:
        iface.messageBar().pushMessage(
            "Aviso REURB",
            f"Selecione pelo menos um objeto na camada '{NOME_CAMADA_LOTES}' para exportar.",
            level=Qgis.Warning,
            duration=5
        )
        return

    # --- DIÁLOGO DE CONFIGURAÇÃO ---
    dlg = ReurbInfoDialog()
    if dlg.exec_() != QDialog.Accepted:
        print("Exportação cancelada pelo usuário.")
        return
        
    user_data = dlg.get_values()

    # Verificação de segurança para conversão em PDF
    if "PDF" in user_data["formato"] and not HAS_WIN32:
        QMessageBox.critical(None, "Erro", "Biblioteca 'pywin32' não encontrada. Instale-a para gerar PDFs.")
        return

    template_path = user_data["template_path"]
    output_folder = user_data["output_folder"]

    if not os.path.exists(template_path):
        QMessageBox.critical(None, "Erro", f"Template não localizado em:\n{template_path}")
        return

    if not os.path.exists(output_folder):
        QMessageBox.critical(None, "Erro", f"Pasta de destino não localizada em:\n{output_folder}")
        return

    # --- FUNÇÕES AUXILIARES ---
    def substituir_variaveis(texto, context):
        for chave, valor in context.items():
            texto = texto.replace(f"{{{{ {chave} }}}}", str(valor) if valor is not None else "")
        return texto

    def processar_paragrafos(paragraphs, context):
        for paragraph in paragraphs:
            texto_completo = "".join([r.text for r in paragraph.runs])
            if "{{" in texto_completo:
                novo_texto = substituir_variaveis(texto_completo, context)
                for run in paragraph.runs:
                    run.text = ""
                if paragraph.runs:
                    paragraph.runs[0].text = novo_texto

    def processar_tabelas(tables, context):
        for table in tables:
            for row in table.rows:
                for cell in row.cells:
                    processar_paragrafos(cell.paragraphs, context)
                    processar_tabelas(cell.tables, context)

    def limpar_nome_arquivo(texto):
        return re.sub(r'[\\/*?:"<>|]', "-", str(texto))

    try:
        locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil.1252')
    except:
        pass
    data_extenso = datetime.now().strftime('%d de %B de %Y')

    # ============================================================
    # 3) LOOP PELOS LOTES SELECIONADOS
    # ============================================================
    word_app = None
    if "PDF" in user_data["formato"]:
        word_app = win32com.client.Dispatch("Word.Application")
        word_app.Visible = False

    try:
        for lote in selected_lotes:
            id_lote = lote["id_lote"]
            
            # --- BUSCA E VARIÁVEIS DO NÚCLEO ---
            id_nuc_ref = lote["identificacao_parcelamento"]
            feat_nuc = next(lyr_nuc.getFeatures(f'"id_0" = {id_nuc_ref}'), None)
            
            # --- Limpeza da Descrição ---
            descricao_limpa = str(lote["descricao"]).replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
            descricao_limpa = ' '.join(descricao_limpa.split())
            if descricao_limpa:
                descricao_limpa = descricao_limpa[0].upper() + descricao_limpa[1:]
            
            # --- Busca e Processamento de Proprietários ---
            expressao = f'"id_lote_reurb" = \'{id_lote}\''
            request = QgsFeatureRequest().setFilterExpression(expressao)
            proprietarios_features = list(lyr_prop.getFeatures(request))
            
            nomes_lista = [p["nome"] for p in proprietarios_features if p["nome"]]
            proprietarios_join = ", ".join(nomes_lista)
            
            dados_lista = [p["dados_proprietario"] for p in proprietarios_features if p["dados_proprietario"]]
            proprietarios_completo_join = "; ".join(dados_lista)
            
            # --- Montagem do Contexto ---
            campo_raw = lote["cronograma"]
            try:
                cronograma_data = json.loads(campo_raw) if isinstance(campo_raw, str) else campo_raw
            except (json.JSONDecodeError, TypeError):
                cronograma_data = []
            
            if isinstance(cronograma_data, list):
                cronograma_formatado = "\n".join([f"• {item}" for item in cronograma_data])
            else:
                cronograma_formatado = str(cronograma_data)

            context = {
                "secretario": user_data["secretario"],
                "n_parecer": lote["n_parecer"] if "n_parecer" in lote.fields().names() else "---",
                "reurb_tipo": lote["reurb_tipo"],
                "endereco": lote["endereco"],
                "area_lote": lote["area_matricula"],
                "proprietarios": proprietarios_join,
                "proprietarios_completo": proprietarios_completo_join,
                "dados_imovel": descricao_limpa,
                "data_extenso": data_extenso,
                "tipo_legitimacao": lote["tipo_legitimacao"],
                "n_crf": str(lote["id_lote"]).zfill(4),
                "n_lote": str(lote["n_lote"]).zfill(3),
                "adequacoes": lote["adequacoes"],
                "responsavel": lote["responsavel"],
                "cadastro": lote["cadastro"],
                "id_betha": lote["id_betha"],
                "cronograma": cronograma_formatado 
            }

            if feat_nuc:
                context["nucleo_nome"] = feat_nuc["nome"]
                context["nucleo_matricula"] = feat_nuc["matricula"]
                context["nucleo_protocolo"] = feat_nuc["protocolo"]
                context["nucleo_endereco"] = feat_nuc["endereco"]
                context["nucleo_parcelador"] = feat_nuc["propri"]
            else:
                context["nucleo_nome"] = "Não localizado"
                context["nucleo_matricula"] = "---"
                context["nucleo_protocolo"] = "---"
                context["nucleo_endereco"] = "---"
                context["nucleo_parcelador"] = "---"

            # --- GERAÇÃO DO DOCX ---
            doc = Document(template_path)
            processar_paragrafos(doc.paragraphs, context)
            processar_tabelas(doc.tables, context)

            tipo_doc = {
                "CRF sem área": "CRF",
                "CRF com área": "CRF",
                "Certificado de Conclusão": "CERTIFICADO"
            }
            tipo_doc_sel = tipo_doc.get(user_data["template_option"], "DOC")
            nome_base = limpar_nome_arquivo(f"{tipo_doc_sel}_{str(lote['id_lote']).zfill(4)}_{context['nucleo_nome']}-Lote_{str(lote['n_lote']).zfill(3)}")
            path_docx = os.path.normpath(os.path.join(output_folder, f"{nome_base}.docx"))
            doc.save(path_docx)

            # --- CONVERSÃO FINAL PARA PDF (SE SOLICITADO) ---
            if word_app:
                try:
                    path_pdf = os.path.normpath(os.path.join(output_folder, f"{nome_base}.pdf"))
                    doc_temp = word_app.Documents.Open(path_docx)
                    doc_temp.SaveAs(path_pdf, FileFormat=17)  # 17 = PDF
                    doc_temp.Close()
                    os.remove(path_docx)  # Remove o Word, mantém apenas o PDF
                    print(f"Exportado PDF: {path_pdf}")
                except Exception as e:
                    print(f"Erro ao converter PDF: {e}")
            else:
                print(f"Exportado Word: {path_docx}")

        QMessageBox.information(None, "Sucesso", f"Processo concluído!\nArquivos salvos em: {output_folder}")

    finally:
        if word_app:
            word_app.Quit()

run()