from qgis.core import *
from qgis.gui import QgisInterface
from qgis.utils import iface
from PyQt5.QtWidgets import *
from PyQt5.QtXml import QDomDocument
from PyQt5.QtCore import QVariant
import os
import re
import subprocess
from docx import Document
from datetime import datetime
import locale
import json

# ============================================================
# CONFIGURAÇÃO DE NOMES DAS CAMADAS (FÁCIL MANUTENÇÃO)
# ============================================================
NOME_CAMADA_LOTES = "lotes_reurb"
NOME_CAMADA_LEGITIMADOS = "legitimados_reurb"
NOME_CAMADA_NUCLEOS = "PROCESSOS_REURB"

# Mapeamento dos nomes amigáveis para os respectivos arquivos de template
TEMPLATES_DISPONIVEIS = {
    "CRF sem área": "modelo_crf.docx",
    "CRF com área": "modelo_crf_02.docx",
    "CRF Área Pública": "modelo_crf_publica.docx",
    "Certificado de Conclusão": "convite_crf.docx",
    "Outros...": None
}

# ============================================================
# 1) CLASSE DE DIÁLOGO PARA ENTRADA DE DADOS (UX INTEGRADA)
# ============================================================
class ReurbInfoDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gerar CRF")
        self.setMinimumWidth(480)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        # 1. Secretário
        layout.addWidget(QLabel("Nome do Secretário:"))
        self.txt_secretario = QLineEdit()
        self.txt_secretario.setText("NOME DO SECRETÁRIO")
        layout.addWidget(self.txt_secretario)

        # 2. Seleção de Template
        layout.addWidget(QLabel("Modelo de Template:"))
        self.combo_template = QComboBox()
        self.combo_template.addItems(list(TEMPLATES_DISPONIVEIS.keys()))
        layout.addWidget(self.combo_template)

        # 2.1. Container para Template Personalizado (Outros...)
        self.widget_custom_template = QWidget()
        custom_layout = QHBoxLayout(self.widget_custom_template)
        custom_layout.setContentsMargins(0, 0, 0, 0)
        
        self.txt_custom_template = QLineEdit()
        self.txt_custom_template.setPlaceholderText("Selecione o arquivo .docx do template...")
        self.btn_browse_template = QPushButton("Buscar...")
        self.btn_browse_template.clicked.connect(self.selecionar_template_custom)
        
        custom_layout.addWidget(self.txt_custom_template)
        custom_layout.addWidget(self.btn_browse_template)
        
        layout.addWidget(self.widget_custom_template)
        self.widget_custom_template.setVisible(False)  # Oculto por padrão

        # 3. Formato de Exportação
        layout.addWidget(QLabel("Formato de Exportação:"))
        self.combo_formato = QComboBox()
        self.combo_formato.addItems(["Word (.docx)", "PDF (.pdf)"])
        layout.addWidget(self.combo_formato)

        # 4. Pasta de Saída
        layout.addWidget(QLabel("Pasta de Destino:"))
        output_layout = QHBoxLayout()
        self.txt_output_folder = QLineEdit()
        self.txt_output_folder.setPlaceholderText("Selecione a pasta onde os arquivos serão salvos...")
        self.btn_browse_output = QPushButton("Selecionar Pasta...")
        self.btn_browse_output.clicked.connect(self.selecionar_pasta_destino)
        
        output_layout.addWidget(self.txt_output_folder)
        output_layout.addWidget(self.btn_browse_output)
        layout.addLayout(output_layout)

        # Sinais
        self.combo_template.currentIndexChanged.connect(self.on_template_changed)

        # Botões da Janela
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, parent=self)
        buttons.accepted.connect(self.validar_e_aceitar)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def on_template_changed(self):
        """Exibe o campo de busca de template apenas quando 'Outros...' for selecionado"""
        is_outro = self.combo_template.currentText() == "Outros..."
        self.widget_custom_template.setVisible(is_outro)
        self.adjustSize()

    def selecionar_template_custom(self):
        caminho, _ = QFileDialog.getOpenFileName(
            self, 
            "Selecione o Template Word", 
            "", 
            "Documentos Word (*.docx)"
        )
        if caminho:
            self.txt_custom_template.setText(caminho)

    def selecionar_pasta_destino(self):
        pasta = QFileDialog.getExistingDirectory(self, "Selecione a Pasta de Destino")
        if pasta:
            self.txt_output_folder.setText(pasta)

    def validar_e_aceitar(self):
        """Valida os dados antes de fechar a janela com OK"""
        if self.combo_template.currentText() == "Outros...":
            custom_path = self.txt_custom_template.text().strip()
            if not custom_path or not os.path.exists(custom_path):
                QMessageBox.warning(self, "Aviso", "Por favor, selecione um arquivo de template válido (.docx).")
                return

        if not self.txt_output_folder.text().strip():
            QMessageBox.warning(self, "Aviso", "Por favor, selecione a pasta de destino dos arquivos.")
            return

        self.accept()

    def get_values(self):
        item_template = self.combo_template.currentText()
        if item_template == "Outros...":
            path_template = self.txt_custom_template.text().strip()
        else:
            nome_arquivo = TEMPLATES_DISPONIVEIS.get(item_template, "modelo_crf.docx")
            plugin_dir = os.path.dirname(__file__)
            path_template = os.path.join(plugin_dir, "modelos", nome_arquivo)

        return {
            "secretario": self.txt_secretario.text().strip(),
            "template_option": item_template,
            "template_path": path_template,
            "formato": self.combo_formato.currentText(),
            "output_folder": self.txt_output_folder.text().strip()
        }

# ============================================================
# 2) FUNÇÃO DE CONVERSÃO COM ESTRATÉGIA MISTA (WORD -> LIBREOFFICE)
# ============================================================
def converter_para_pdf(path_docx, path_pdf, output_folder):
    """
    Estratégia Híbrida:
    1. Tenta via MS Word (win32com)
    2. Tenta via docx2pdf
    3. Se ambos falharem ou o Word não existir, faz fallback para LibreOffice
    """
    # --- 1. TENTATIVA VIA MS WORD (win32com) ---
    try:
        import win32com.client
        import pythoncom
        pythoncom.CoInitialize()
        word_app = win32com.client.Dispatch("Word.Application")
        word_app.Visible = False
        doc_temp = word_app.Documents.Open(path_docx)
        doc_temp.SaveAs(path_pdf, FileFormat=17)  # 17 = PDF
        doc_temp.Close()
        word_app.Quit()
        pythoncom.CoUninitialize()
        if os.path.exists(path_pdf):
            print("[REURB Log] PDF gerado via MS Word COM com sucesso.")
            return True
    except Exception as e_word:
        print(f"[REURB Log] MS Word falhou ({e_word}). Tentando docx2pdf...")

    # --- 2. TENTATIVA VIA docx2pdf ---
    try:
        from docx2pdf import convert
        convert(path_docx, path_pdf)
        if os.path.exists(path_pdf):
            print("[REURB Log] PDF gerado via docx2pdf com sucesso.")
            return True
    except Exception as e_docx2pdf:
        print(f"[REURB Log] docx2pdf falhou ({e_docx2pdf}). Tentando LibreOffice...")

    # --- 3. FALLBACK VIA LIBREOFFICE (soffice) ---
    caminhos_soffice = [
        "soffice",
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"
    ]

    for caminho in caminhos_soffice:
        try:
            cmd = [
                caminho,
                '--headless',
                '--convert-to', 'pdf',
                '--outdir', output_folder,
                path_docx
            ]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=45)
            if res.returncode == 0 and os.path.exists(path_pdf):
                print(f"[REURB Log] PDF gerado via LibreOffice com sucesso ({caminho}).")
                return True
        except Exception:
            continue

    print("[REURB Log] Todas as tentativas de conversão (Word e LibreOffice) falharam.")
    return False

# ============================================================
# 3) FUNÇÃO PRINCIPAL DE EXECUÇÃO
# ============================================================
def run():
    print("Iniciando Exportação REURB...")

    # --- VERIFICAÇÃO SILENCIOSA DE CAMADAS ---
    project = QgsProject.instance()
    layer_lotes = project.mapLayersByName(NOME_CAMADA_LOTES)
    layer_legitimados = project.mapLayersByName(NOME_CAMADA_LEGITIMADOS)
    layer_nucleos = project.mapLayersByName(NOME_CAMADA_NUCLEOS)

    if not layer_lotes or not layer_legitimados or not layer_nucleos:
        iface.messageBar().pushMessage(
            "Aviso REURB",
            f"Camadas REURB não encontradas. Abra o projeto com a camada '{NOME_CAMADA_LOTES}'.",
            level=Qgis.Warning,
            duration=5
        )
        return

    lyr_lote = layer_lotes[0]
    lyr_prop = layer_legitimados[0]
    lyr_nuc = layer_nucleos[0]

    selected_lotes = lyr_lote.selectedFeatures()
    if not selected_lotes:
        iface.messageBar().pushMessage(
            "Aviso REURB",
            f"Selecione pelo menos um objeto na camada '{NOME_CAMADA_LOTES}' para exportar.",
            level=Qgis.Warning,
            duration=5
        )
        return

    # --- DIÁLOGO DE CONFIGURAÇÃO ---
    dlg = ReurbInfoDialog()
    if dlg.exec_() != QDialog.Accepted:
        print("Exportação cancelada pelo usuário.")
        return
        
    user_data = dlg.get_values()
    gerar_pdf = "PDF" in user_data["formato"]

    template_path = user_data["template_path"]
    output_folder = user_data["output_folder"]

    if not os.path.exists(template_path):
        QMessageBox.critical(None, "Erro", f"Template não localizado em:\n{template_path}")
        return

    if not os.path.exists(output_folder):
        QMessageBox.critical(None, "Erro", f"Pasta de destino não localizada em:\n{output_folder}")
        return

    # --- FUNÇÕES AUXILIARES ---
    def substituir_variaveis(texto, context):
        for chave, valor in context.items():
            texto = texto.replace(f"{{{{ {chave} }}}}", str(valor) if valor is not None else "")
        return texto

    def processar_paragrafos(paragraphs, context):
        for paragraph in paragraphs:
            texto_completo = "".join([r.text for r in paragraph.runs])
            if "{{" in texto_completo:
                novo_texto = substituir_variaveis(texto_completo, context)
                for run in paragraph.runs:
                    run.text = ""
                if paragraph.runs:
                    paragraph.runs[0].text = novo_texto

    def processar_tabelas(tables, context):
        for table in tables:
            for row in table.rows:
                for cell in row.cells:
                    processar_paragrafos(cell.paragraphs, context)
                    processar_tabelas(cell.tables, context)

    def limpar_nome_arquivo(texto):
        return re.sub(r'[\\/*?:"<>|]', "-", str(texto))

    try:
        locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil.1252')
    except:
        pass
    data_extenso = datetime.now().strftime('%d de %B de %Y')

    # ============================================================
    # 4) LOOP PELOS LOTES SELECIONADOS
    # ============================================================
    erros_conversao = 0

    for lote in selected_lotes:
        id_lote_val = lote["id_lote"]
        n_crf_val = lote["n_crf"]
        
        # --- BUSCA E VARIÁVEIS DO NÚCLEO ---
        id_nuc_ref = lote["processo_reurb"]
        feat_nuc = next(lyr_nuc.getFeatures(f'"id" = {id_nuc_ref}'), None)
        
        # --- Limpeza da Descrição ---
        descricao_limpa = str(lote["descricao"]).replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        descricao_limpa = ' '.join(descricao_limpa.split())
        if descricao_limpa:
            descricao_limpa = descricao_limpa[0].upper() + descricao_limpa[1:]
        
        # --- BUSCA DE PROPRIETÁRIOS ---
        condicoes = []
        for ref_val in [id_lote_val, n_crf_val]:
            if ref_val is not None:
                ref_str = str(ref_val).strip()
                if ref_str.isdigit():
                    condicoes.append(f'"id_lote_reurb" = {int(ref_str)}')
                    condicoes.append(f'"id_lote_reurb" = \'{ref_str}\'')
                    condicoes.append(f'"id_lote_reurb" = \'{ref_str.zfill(4)}\'')
                else:
                    condicoes.append(f'"id_lote_reurb" = \'{ref_str}\'')

        expressao = " OR ".join(list(set(condicoes)))
        request = QgsFeatureRequest().setFilterExpression(expressao)
        proprietarios_features = list(lyr_prop.getFeatures(request))
        
        nomes_lista = [str(p["nome"]) for p in proprietarios_features if p["nome"]]
        proprietarios_join = ", ".join(nomes_lista)
        
        dados_lista = [str(p["dados_proprietario"]) for p in proprietarios_features if p["dados_proprietario"]]
        proprietarios_completo_join = "; ".join(dados_lista)
        
        # --- Montagem do Contexto ---
        campo_raw = lote["cronograma"]
        try:
            cronograma_data = json.loads(campo_raw) if isinstance(campo_raw, str) else campo_raw
        except (json.JSONDecodeError, TypeError):
            cronograma_data = []
        
        if isinstance(cronograma_data, list):
            cronograma_formatado = "\n".join([f"• {item}" for item in cronograma_data])
        else:
            cronograma_formatado = str(cronograma_data)

        context = {
            "secretario": user_data["secretario"],
            "n_parecer": lote["n_parecer"] if "n_parecer" in lote.fields().names() else "---",
            "reurb_tipo": lote["reurb_tipo"],
            "endereco": lote["endereco"],
            "area_lote": lote["area_matricula"],
            "proprietarios": proprietarios_join,
            "proprietarios_completo": proprietarios_completo_join,
            "dados_imovel": descricao_limpa,
            "data_extenso": data_extenso,
            "tipo_legitimacao": lote["tipo_legitimacao"],
            "n_crf": str(lote["n_crf"]).zfill(4),
            "n_lote": str(lote["n_lote"]).zfill(3),
            "adequacoes": lote["adequacoes"],
            "responsavel": lote["responsavel"],
            "cadastro": lote["cadastro"],
            "id_betha": lote["id_betha"],
            "cronograma": cronograma_formatado 
        }

        if feat_nuc:
            context["nucleo_nome"] = feat_nuc["nome"]
            context["nucleo_matricula"] = feat_nuc["matricula"]
            context["nucleo_protocolo"] = feat_nuc["protocolo"]
            context["nucleo_endereco"] = feat_nuc["endereco"]
            context["nucleo_parcelador"] = feat_nuc["propri"]
        else:
            context["nucleo_nome"] = "Não localizado"
            context["nucleo_matricula"] = "---"
            context["nucleo_protocolo"] = "---"
            context["nucleo_endereco"] = "---"
            context["nucleo_parcelador"] = "---"

        # --- GERAÇÃO DO DOCX ---
        doc = Document(template_path)
        processar_paragrafos(doc.paragraphs, context)
        processar_tabelas(doc.tables, context)

        tipo_doc = {
            "CRF sem área": "CRF",
            "CRF com área": "CRF",
            "CRF Área Pública": "CRF",
            "Certificado de Conclusão": "CERTIFICADO"
        }
        tipo_doc_sel = tipo_doc.get(user_data["template_option"], "DOC")
        nome_base = limpar_nome_arquivo(f"{tipo_doc_sel}_{str(lote['n_crf']).zfill(4)}_{context['nucleo_nome']}-Lote_{str(lote['n_lote']).zfill(3)}")
        path_docx = os.path.normpath(os.path.join(output_folder, f"{nome_base}.docx"))
        path_pdf = os.path.normpath(os.path.join(output_folder, f"{nome_base}.pdf"))
        doc.save(path_docx)

        # --- CONVERSÃO FINAL PARA PDF ---
        if gerar_pdf:
            sucesso = converter_para_pdf(path_docx, path_pdf, output_folder)
            if sucesso:
                os.remove(path_docx)  # Apaga o .docx e mantém apenas o .pdf
                print(f"Exportado PDF com sucesso: {path_pdf}")
            else:
                erros_conversao += 1
                print(f"Falha ao converter para PDF: {path_docx}")
        else:
            print(f"Exportado Word com sucesso: {path_docx}")

    if erros_conversao > 0:
        QMessageBox.warning(
            None, 
            "Aviso de Conversão", 
            f"Processo concluído com avisos.\n{erros_conversao} arquivo(s) não puderam ser convertidos para PDF e foram mantidos em .docx.\n\nCertifique-se de que pelo menos o MS Word ou o LibreOffice esteja instalado na máquina."
        )
    else:
        QMessageBox.information(None, "Sucesso", f"Processo concluído com sucesso!\nArquivos salvos em: {output_folder}")

run()