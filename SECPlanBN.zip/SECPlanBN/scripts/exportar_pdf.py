from qgis.core import *
from PyQt5.QtWidgets import *
from PyQt5.QtXml import QDomDocument
import os
from qgis.utils import iface

def run():
    from qgis.core import (
        QgsProject,
        QgsLayoutExporter,
        QgsLayoutItemMap,
        QgsReadWriteContext,
        QgsPrintLayout,
        edit,
        QgsFeature
    )
    
    # --- AJUSTE DE CAMINHO ---
    current_dir = os.path.dirname(__file__)
    path_to_qpt = os.path.join(current_dir, 'layouts', 'layout.qpt')
    
    # Tenta subir um nível se não achar na pasta scripts
    if not os.path.exists(path_to_qpt):
        path_to_qpt = os.path.join(os.path.dirname(current_dir), 'layouts', 'layout.qpt')

    if not os.path.exists(path_to_qpt):
        QMessageBox.critical(None, "Erro de Arquivo", f"Layout não encontrado em:\n{path_to_qpt}")
        return

    # --- INTERFACE INICIAL ---
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Question)
    msg.setWindowTitle("Exportação de PDFs")
    msg.setText("Selecione a qualidade da exportação:")
    btn_alta = msg.addButton("Alta", QMessageBox.ActionRole)
    btn_media = msg.addButton("Média", QMessageBox.ActionRole)
    btn_baixa = msg.addButton("Baixa", QMessageBox.ActionRole)
    msg.exec_()
    
    qualidade = "baixa"
    if msg.clickedButton() == btn_alta: qualidade = "alta"
    elif msg.clickedButton() == btn_media: qualidade = "media"
    
    output_folder = QFileDialog.getExistingDirectory(None, "Selecione a pasta de exportação", '', QFileDialog.ShowDirsOnly)
    if not output_folder:
        return

    # --- CONFIGURAÇÕES ---
    layer_destino_nome = 'ÁREA DE ESTUDO'
    margem = 100 
    project = QgsProject.instance()
    layer_origem = iface.activeLayer()
    
    if layer_origem is None:
        QMessageBox.warning(None, "Erro", "Selecione uma camada ativa.")
        return
    
    layer_destino_list = project.mapLayersByName(layer_destino_nome)
    if not layer_destino_list:
        QMessageBox.warning(None, "Erro", f"Camada '{layer_destino_nome}' não encontrada.")
        return
    layer_destino = layer_destino_list[0]
    
    selected_features = layer_origem.selectedFeatures()
    if not selected_features:
        QMessageBox.warning(None, "Erro", "Selecione ao menos um objeto no mapa.")
        return

    # --- CARREGAR LAYOUT (CORRIGIDO) ---
    layout = QgsPrintLayout(project)
    # Importante: para templates QPT, usamos readXml sobre o elemento raiz do documento
    try:
        with open(path_to_qpt, 'r', encoding='utf-8') as f:
            content = f.read()
        
        doc = QDomDocument()
        doc.setContent(content)
        
        # O QPT é um XML onde o elemento raiz é <layout>
        layout.readXml(doc.documentElement(), doc, QgsReadWriteContext())
    except Exception as e:
        QMessageBox.critical(None, "Erro", f"Falha ao carregar QPT: {str(e)}")
        return
    
    # Identifica o item de mapa
    map_item = next((i for i in layout.items() if isinstance(i, QgsLayoutItemMap)), None)
    if map_item is None:
        QMessageBox.warning(None, "Erro", "Não há um item de mapa no layout QPT.")
        return

    # Salva dimensões originais do template
    original_size = map_item.sizeWithUnits()
    original_pos = map_item.positionWithUnits()

    exporter = QgsLayoutExporter(layout)
    pdf_settings = QgsLayoutExporter.PdfExportSettings()
    pdf_settings.dpi = 300 if qualidade == "alta" else (150 if qualidade == "media" else 72)

    progress = QProgressDialog("Exportando...", "Cancelar", 0, len(selected_features))
    progress.setWindowModality(True)
    
    for idx, feature in enumerate(selected_features, 1):
        if progress.wasCanceled(): break
    
        try: nome = feature["nome"]
        except: nome = f"Feature_{idx}"
    
        # Adiciona feição temporária
        new_feat = QgsFeature()
        new_feat.setGeometry(feature.geometry())
        with edit(layer_destino):
            res, out_feats = layer_destino.dataProvider().addFeatures([new_feat])
            temp_id = out_feats[0].id() if res else None

        # Fixa a Viewport para não esticar
        map_item.attemptResize(original_size)
        map_item.attemptMove(original_pos)
        
        # Enquadra o objeto
        extent = feature.geometry().boundingBox()
        extent.grow(margem)
        map_item.zoomToExtent(extent)
        map_item.setScale(map_item.scale() * 1.1)
        map_item.refresh()
    
        # Exporta
        fid_str = str(idx).zfill(4)
        nome_limpo = str(nome).replace('/', '_').replace('\\', '_')
        output_file = os.path.join(output_folder, f"{fid_str}-{nome_limpo}.pdf")
        exporter.exportToPdf(output_file, pdf_settings)
    
        # Limpa temporário
        if temp_id is not None:
            with edit(layer_destino):
                layer_destino.deleteFeature(temp_id)
    
        progress.setValue(idx)
    
    progress.close()
    print("Processo finalizado com sucesso.")