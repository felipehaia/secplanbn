# scripts/documentos.py

import os
import re
import locale
from datetime import datetime
from docx import Document
from docx.shared import Inches

from qgis.core import (
    QgsProject, QgsMapLayerType, QgsFeature, QgsRectangle, QgsLayoutExporter, edit
)
from qgis.utils import iface
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QComboBox,
    QListWidget, QPushButton, QFormLayout, QMessageBox, QFileDialog,
    QDialogButtonBox
)

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config_documentos.txt")


def carregar_config_documentos():
    """Lê o arquivo TXT de configuração de documentos."""
    documentos = []
    if not os.path.exists(CONFIG_PATH):
        return documentos

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and "|" in line:
                partes = line.split("|")
                if len(partes) >= 3:
                    documentos.append({
                        "titulo": partes[0].strip(),
                        "camada": partes[1].strip(),
                        "template_path": partes[2].strip()
                    })
    return documentos


def salvar_config_documentos(documentos):
    """Grava a lista de configurações de documentos no arquivo TXT."""
    linhas = []
    for d in documentos:
        linhas.append(f"{d['titulo']}|{d['camada']}|{d['template_path']}")
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(linhas))


def _limpar_nome_arquivo(texto):
    return re.sub(r'[\\/*?:"<>|]', "-", str(texto))


def _obter_data_por_extenso():
    try:
        locale.setlocale(locale.LC_TIME, 'pt_BR.utf8')
    except Exception:
        try:
            locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil.1252')
        except Exception:
            pass
    return datetime.now().strftime('%d de %B de %Y')


def _processar_paragrafos(paragraphs, context, imagem_croqui=None):
    """Substitui variáveis preservando a estrutura de runs e imagens do Word."""
    for paragraph in paragraphs:
        texto_completo = "".join([run.text for run in paragraph.runs])

        if "{{ croqui }}" in texto_completo or "{{croqui}}" in texto_completo:
            paragraph.clear()
            if imagem_croqui and os.path.exists(imagem_croqui):
                paragraph.add_run().add_picture(imagem_croqui, width=Inches(5))
            else:
                paragraph.add_run("Croqui não disponível")
        else:
            # Substitui diretamente nos runs existentes sem apagar elementos ancorados
            for run in paragraph.runs:
                if "{" in run.text:
                    for chave, valor in context.items():
                        tag = f"{{{{ {chave} }}}}"
                        if tag in run.text:
                            run.text = run.text.replace(tag, str(valor if valor is not None else ""))


def _processar_tabelas(tables, context, imagem_croqui=None):
    for table in tables:
        for row in table.rows:
            for cell in row.cells:
                _processar_paragrafos(cell.paragraphs, context, imagem_croqui)
                _processar_tabelas(cell.tables, context, imagem_croqui)


def _executar_geracao_documento(doc_config):
    """Executa a geração do documento/parecer para CADA objeto selecionado na camada especificada."""
    nome_camada = doc_config["camada"]
    template_path = doc_config["template_path"]
    titulo = doc_config["titulo"]

    if not os.path.exists(template_path):
        QMessageBox.warning(iface.mainWindow(), "Arquivo Ausente", f"O arquivo de modelo não foi encontrado:\n{template_path}")
        return

    camadas = QgsProject.instance().mapLayersByName(nome_camada)
    if not camadas:
        QMessageBox.warning(iface.mainWindow(), "Erro", f"A camada '{nome_camada}' não foi encontrada no projeto.")
        return

    layer = camadas[0]
    feicoes_selecionadas = list(layer.selectedFeatures())

    if not feicoes_selecionadas:
        QMessageBox.warning(iface.mainWindow(), "Seleção Necessária", f"Selecione ao menos um objeto na camada '{nome_camada}' para gerar o parecer.")
        return

    output_folder = r"C:\temp\lotes_docx"
    os.makedirs(output_folder, exist_ok=True)

    data_extenso = _obter_data_por_extenso()
    gerados = 0

    for idx, feature in enumerate(feicoes_selecionadas, start=1):
        context = {
            "data_extenso": data_extenso,
            "ano": datetime.now().year
        }

        # 1. Popula variáveis usando 'nome_campo' e 'nomedacamada.nome_campo'
        for field in layer.fields():
            f_name = field.name()
            val = feature.attribute(f_name)
            str_val = str(val) if val is not None else ""
            context[f_name] = str_val
            context[f"{nome_camada}.{f_name}"] = str_val

        # 2. Tenta gerar o croqui se houver a camada ÁREA DE ESTUDO
        imagem_croqui = None
        area_estudo_list = QgsProject.instance().mapLayersByName("ÁREA DE ESTUDO")
        if area_estudo_list and feature.geometry():
            area_de_estudo_layer = area_estudo_list[0]
            novo_obj = QgsFeature()
            novo_obj.setGeometry(feature.geometry())
            with edit(area_de_estudo_layer):
                area_de_estudo_layer.addFeature(novo_obj)

            imagem_croqui = os.path.join(output_folder, f"temp_croqui_{idx}.png")
            layout = QgsProject.instance().layoutManager().layoutByName('VIABILIDADE CONSTRUÇÃO')
            if layout:
                map_item = layout.itemById('Mapa 1')
                if map_item:
                    extent = feature.geometry().boundingBox()
                    extent.grow(100)
                    map_item.setExtent(extent)
                    map_item.refresh()
                    exporter = QgsLayoutExporter(layout)
                    exporter.exportToImage(imagem_croqui, QgsLayoutExporter.ImageExportSettings())

        # 3. Processa o arquivo Word (.docx)
        doc = Document(template_path)

        # Processa apenas o corpo principal e tabelas
        _processar_paragrafos(doc.paragraphs, context, imagem_croqui)
        _processar_tabelas(doc.tables, context, imagem_croqui)

        # Processa cabeçalho e rodapé APENAS se contiverem variáveis {{ }}
        for section in doc.sections:
            header_text = "".join([p.text for p in section.header.paragraphs])
            if "{{" in header_text:
                _processar_paragrafos(section.header.paragraphs, context, imagem_croqui)
                _processar_tabelas(section.header.tables, context, imagem_croqui)

            footer_text = "".join([p.text for p in section.footer.paragraphs])
            if "{{" in footer_text:
                _processar_paragrafos(section.footer.paragraphs, context, imagem_croqui)
                _processar_tabelas(section.footer.tables, context, imagem_croqui)

        protocolo_ou_id = context.get("protocolo", context.get("id", str(feature.id())))
        nome_arquivo = _limpar_nome_arquivo(f"{titulo}_{protocolo_ou_id}_{idx}")
        output_path = os.path.join(output_folder, f"{nome_arquivo}.docx")
        doc.save(output_path)
        gerados += 1

        if gerados == 1:
            os.startfile(output_path)

    QMessageBox.information(iface.mainWindow(), "Sucesso", f"{gerados} parecer(es) gerado(s) com sucesso na pasta:\n{output_folder}")


class GerenciadorDocumentosDialog(QDialog):
    """Interface para cadastrar e editar modelos de documentos/pareceres."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configurar Pareceres e Documentos")
        self.resize(500, 450)
        self.documentos = carregar_config_documentos()
        self.indice_em_edicao = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("<b>Modelos de Documentos Cadastrados:</b>"))
        self.list_widget = QListWidget()
        self.atualizar_lista()
        self.list_widget.currentRowChanged.connect(self.ao_selecionar_item)
        layout.addWidget(self.list_widget)

        btn_layout = QHBoxLayout()
        self.btn_editar = QPushButton("✏️ Editar Selecionado")
        self.btn_editar.setEnabled(False)
        self.btn_editar.clicked.connect(self.carregar_para_edicao)
        btn_layout.addWidget(self.btn_editar)

        btn_remover = QPushButton("❌ Remover Selecionado")
        btn_remover.clicked.connect(self.remover_documento)
        btn_layout.addWidget(btn_remover)
        layout.addLayout(btn_layout)

        layout.addWidget(QLabel("<hr><b>Formulário do Modelo:</b>"))
        form_layout = QFormLayout()

        self.txt_nome = QLineEdit()
        self.txt_nome.setPlaceholderText("Ex: Parecer Técnico de Loteamento")
        form_layout.addRow("Título do Documento:", self.txt_nome)

        self.combo_camadas = QComboBox()
        form_layout.addRow("Selecione a Camada:", self.combo_camadas)

        file_layout = QHBoxLayout()
        self.txt_path = QLineEdit()
        self.txt_path.setReadOnly(True)
        btn_browse = QPushButton("Buscar .docx...")
        btn_browse.clicked.connect(self.selecionar_arquivo_docx)
        file_layout.addWidget(self.txt_path)
        file_layout.addWidget(btn_browse)
        form_layout.addRow("Modelo Word (.docx):", file_layout)

        layout.addLayout(form_layout)
        self.popula_camadas()

        botoes_salvar_layout = QHBoxLayout()
        self.btn_salvar = QPushButton("💾 Salvar Modelo")
        self.btn_salvar.clicked.connect(self.salvar_documento)
        botoes_salvar_layout.addWidget(self.btn_salvar)

        self.btn_cancelar_edicao = QPushButton("Cancelar Edição")
        self.btn_cancelar_edicao.setVisible(False)
        self.btn_cancelar_edicao.clicked.connect(self.limpar_formulario)
        botoes_salvar_layout.addWidget(self.btn_cancelar_edicao)

        layout.addLayout(botoes_salvar_layout)

        botoes_fechar = QDialogButtonBox(QDialogButtonBox.Close)
        botoes_fechar.rejected.connect(self.accept)
        layout.addWidget(botoes_fechar)

    def popula_camadas(self):
        self.combo_camadas.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayerType.VectorLayer:
                self.combo_camadas.addItem(layer.name())

    def selecionar_arquivo_docx(self):
        caminho, _ = QFileDialog.getOpenFileName(
            self, "Selecione o Modelo Word", "", "Arquivo Word (*.docx)"
        )
        if caminho:
            self.txt_path.setText(caminho)

    def atualizar_lista(self):
        self.list_widget.clear()
        for d in self.documentos:
            self.list_widget.addItem(f"{d['titulo']} ---> Camada: {d['camada']}")

    def ao_selecionar_item(self, row):
        self.btn_editar.setEnabled(row >= 0)

    def carregar_para_edicao(self):
        row = self.list_widget.currentRow()
        if row < 0:
            return
        self.indice_em_edicao = row
        d = self.documentos[row]

        self.txt_nome.setText(d["titulo"])
        index_camada = self.combo_camadas.findText(d["camada"])
        if index_camada >= 0:
            self.combo_camadas.setCurrentIndex(index_camada)
        self.txt_path.setText(d["template_path"])

        self.btn_salvar.setText("💾 Atualizar Modelo")
        self.btn_cancelar_edicao.setVisible(True)

    def limpar_formulario(self):
        self.indice_em_edicao = None
        self.txt_nome.clear()
        self.txt_path.clear()
        self.btn_salvar.setText("💾 Salvar Modelo")
        self.btn_cancelar_edicao.setVisible(False)
        self.list_widget.clearSelection()

    def salvar_documento(self):
        titulo = self.txt_nome.text().strip()
        camada = self.combo_camadas.currentText()
        template_path = self.txt_path.text().strip()

        if not titulo or not camada or not template_path:
            QMessageBox.warning(self, "Aviso", "Preencha todos os campos do formulário!")
            return

        dados = {
            "titulo": titulo,
            "camada": camada,
            "template_path": template_path
        }

        if self.indice_em_edicao is not None:
            self.documentos[self.indice_em_edicao] = dados
            msg = "Modelo atualizado com sucesso!"
        else:
            self.documentos.append(dados)
            msg = "Novo modelo cadastrado com sucesso!"

        salvar_config_documentos(self.documentos)
        self.atualizar_lista()
        self.limpar_formulario()
        QMessageBox.information(self, "Sucesso", msg)

    def remover_documento(self):
        row = self.list_widget.currentRow()
        if row >= 0:
            del self.documentos[row]
            salvar_config_documentos(self.documentos)
            self.atualizar_lista()
            self.limpar_formulario()


def abrir_gerenciador_documentos():
    """Abre a janela de configuração de pareceres/documentos."""
    dlg = GerenciadorDocumentosDialog(iface.mainWindow())
    dlg.exec_()