# scripts/documentos.py

import copy
import os
import re
import locale
import subprocess
from datetime import datetime
from docx import Document
from docx.shared import Inches

from qgis.core import (
    QgsProject, QgsMapLayerType, QgsFeature, QgsRectangle, QgsLayoutExporter, edit
)
from qgis.utils import iface
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QComboBox,
    QListWidget, QPushButton, QFormLayout, QMessageBox, QFileDialog,
    QDialogButtonBox, QTextEdit, QCheckBox, QListWidgetItem
)
from PyQt5.QtCore import Qt

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config_documentos.txt")
PASTA_MODELOS_DOC = os.path.join(os.path.dirname(__file__), "modelos_doc")
os.makedirs(PASTA_MODELOS_DOC, exist_ok=True)


def carregar_config_documentos():
    """Lê o arquivo TXT de configuração de documentos com suporte aos campos de exibição."""
    documentos = []
    if not os.path.exists(CONFIG_PATH):
        return documentos

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and "|" in line:
                partes = line.split("|")
                if len(partes) >= 3:
                    doc = {
                        "titulo": partes[0].strip(),
                        "camada": partes[1].strip(),
                        "template_path": partes[2].strip(),
                        "por_relacao": partes[3].strip() == "True" if len(partes) > 3 else False,
                        "rel_split": partes[4].strip() if len(partes) > 4 else "",
                        "campo_label_pai": partes[5].strip() if len(partes) > 5 else "",
                        "campo_label_filho": partes[6].strip() if len(partes) > 6 else ""
                    }
                    documentos.append(doc)
    return documentos


def salvar_config_documentos(documentos):
    """Grava a lista de configurações de documentos no arquivo TXT."""
    linhas = []
    for d in documentos:
        por_relacao = str(d.get("por_relacao", False))
        rel_split = str(d.get("rel_split", ""))
        c_pai = str(d.get("campo_label_pai", ""))
        c_filho = str(d.get("campo_label_filho", ""))
        linhas.append(f"{d['titulo']}|{d['camada']}|{d['template_path']}|{por_relacao}|{rel_split}|{c_pai}|{c_filho}")
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(linhas))


def _limpar_nome_arquivo(texto):
    return re.sub(r'[\\/*?:"<>|]', "-", str(texto))


def _obter_data_por_extenso():
    try:
        locale.setlocale(locale.LC_TIME, 'pt_BR.utf8')
    except Exception:
        try:
            locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil.1252')
        except Exception:
            pass
    return datetime.now().strftime('%d de %B de %Y')


def _consolidar_runs_paragrafo(paragraph):
    """Junta os fragmentos de runs do Word no primeiro run para evitar falhas do Regex."""
    if not paragraph.runs or "{{" not in paragraph.text:
        return

    full_text = paragraph.text
    first_run = paragraph.runs[0]
    first_run.text = full_text

    for run in paragraph.runs[1:]:
        run.text = ""


# ==============================================================================
# GERADOR AUTOMÁTICO DE MODELO WORD (.DOCX)
# ==============================================================================

def gerar_template_word_documento_base(titulo_documento, nome_camada_principal=None):
    """Gera um modelo .docx base estruturado detalhando dinamicamente as relações da camada."""
    nome_limpo = re.sub(r'[\\/*?:"<>|]', "_", titulo_documento).lower().replace(" ", "_")
    nome_arquivo = f"modelo_documento_{nome_limpo}.docx"
    caminho_destino = os.path.join(PASTA_MODELOS_DOC, nome_arquivo)

    doc = Document()

    p_titulo = doc.add_paragraph()
    run_t = p_titulo.add_run(f"{titulo_documento.upper()}")
    run_t.bold = True
    p_titulo.alignment = 1

    doc.add_paragraph("Data de Emissão: {{data_extenso}}")
    doc.add_paragraph("=" * 60)

    doc.add_paragraph("\n1. IDENTIFICAÇÃO E DADOS PRINCIPAIS")
    doc.add_paragraph("Certificamos as informações referentes ao registro ID #{{id}}.")

    doc.add_paragraph("\n2. CONTEÚDO DO DOCUMENTO / PARECER")
    doc.add_paragraph("Insira aqui o texto descritivo do parecer ou documento...")

    doc.add_paragraph("\n" + "=" * 60)

    p_ass = doc.add_paragraph()
    p_ass.add_run("\n\n___________________________________________\n")
    p_ass.add_run("Responsável Técnico\n").bold = True

    doc.add_page_break()
    doc.add_heading("GUIA DE VARIÁVEIS DA CAMADA E RELAÇÕES", level=2)

    tabela = doc.add_table(rows=1, cols=2)
    hdr_cells = tabela.rows[0].cells
    hdr_cells[0].text = "Sintaxe / Tag"
    hdr_cells[1].text = "Origem dos Dados"

    variaveis_guia = [
        ("{{data_extenso}}", "Data atual por extenso"),
        ("{{ano}}", "Ano atual"),
        ("{{nome_campo}}", "Atributo do PAI (Camada principal selecionada)"),
    ]

    if nome_camada_principal:
        camadas = QgsProject.instance().mapLayersByName(nome_camada_principal)
        if camadas:
            layer = camadas[0]
            rel_manager = QgsProject.instance().relationManager()

            # Vô (FKs)
            relacoes_vo = [r for r in rel_manager.relations().values() if r.referencingLayerId() == layer.id()]
            for r in relacoes_vo:
                p_layer = r.referencedLayer()
                p_nome = p_layer.name() if p_layer else "PaiSuper"
                variaveis_guia.append((f"{{{{{r.name()}.campo}}}}", f"Atributo VÔ (via Relação {r.name()})"))
                variaveis_guia.append((f"{{{{{p_nome}.campo}}}}", f"Atributo VÔ (via Camada {p_nome})"))

            # Filho (1:N / N:M)
            relacoes_filhos = [r for r in rel_manager.relations().values() if r.referencedLayerId() == layer.id()]
            for r in relacoes_filhos:
                nome_r = r.name()
                variaveis_guia.append((f"{{{{{nome_r}.campo}}}}", f"Atributo FILHO em tabela repetitiva"))
                variaveis_guia.append((f"{{{{{nome_r}.campo_LISTA}}}}", f"Lista de atributos FILHO separados por vírgula"))
                variaveis_guia.append((f"{{{{#{nome_r}}}}} ... {{{{{nome_r}}}}}", f"Bloco repetitivo em parágrafo"))

    for var, desc in variaveis_guia:
        row_cells = tabela.add_row().cells
        row_cells[0].text = var
        row_cells[1].text = desc

    doc.save(caminho_destino)
    return caminho_destino


def _extrair_dados_hierarquia_3_niveis(layer, feat_pai):
    """
    Busca atributos nos 3 Níveis com suporte completo a tabelas pivô N:M:
    1. Vô (Camada pai referenciada por FK)
    2. Pai (Camada selecionada)
    3. Filho (Camadas filhas 1:N ou N:M através de tabelas de ligação)
    """
    contexto = {}
    rel_data_dict = {}
    rel_manager = QgsProject.instance().relationManager()

    # --- 1. DADOS DO PAI (Camada Atual) ---
    for field in layer.fields():
        val = feat_pai.attribute(field.name())
        val_str = str(val) if val is not None else ""
        contexto[field.name()] = val_str
        contexto[f"{layer.name()}.{field.name()}"] = val_str

    # --- 2. DADOS DO VÔ (Relações onde a camada atual possui FK / N:1) ---
    relacoes_vo = [r for r in rel_manager.relations().values() if r.referencingLayerId() == layer.id()]
    for rel in relacoes_vo:
        nome_rel = rel.name()
        parent_layer = rel.referencedLayer()
        if parent_layer:
            parent_feat = rel.getReferencedFeature(feat_pai)
            if parent_feat.isValid():
                for field in parent_feat.fields():
                    val = parent_feat.attribute(field.name())
                    val_str = str(val) if val is not None else ""
                    contexto[f"{nome_rel}.{field.name()}"] = val_str
                    contexto[f"{parent_layer.name()}.{field.name()}"] = val_str

    # --- 3. DADOS DOS FILHOS / N:M ---
    relacoes_filhos = [r for r in rel_manager.relations().values() if r.referencedLayerId() == layer.id()]
    for rel in relacoes_filhos:
        nome_rel = rel.name()
        pivo_layer = rel.referencingLayer()
        pivo_features = list(rel.getRelatedFeatures(feat_pai))

        outras_rels_pivo = [
            r for r in rel_manager.relations().values() 
            if r.referencingLayerId() == pivo_layer.id() and r.id() != rel.id()
        ]

        if outras_rels_pivo:
            segunda_rel = outras_rels_pivo[0]
            rel_features_finais = []
            for feat_pivo in pivo_features:
                feat_dest = segunda_rel.getReferencedFeature(feat_pivo)
                if feat_dest.isValid():
                    rel_features_finais.append(feat_dest)

            rel_data_dict[nome_rel] = rel_features_finais

            if rel_features_finais:
                primeira_feat = rel_features_finais[0]
                for field in primeira_feat.fields():
                    rf_name = field.name()
                    r_val = primeira_feat.attribute(rf_name)
                    contexto[f"{nome_rel}.{rf_name}"] = str(r_val) if r_val is not None else ""

                for field in primeira_feat.fields():
                    rf_name = field.name()
                    valores_lista = [str(rf.attribute(rf_name)).strip() for rf in rel_features_finais if rf.attribute(rf_name) is not None]
                    contexto[f"{nome_rel}.{rf_name}_LISTA"] = ", ".join(valores_lista)
        else:
            rel_data_dict[nome_rel] = pivo_features

            if pivo_features:
                primeira_feat = pivo_features[0]
                for field in primeira_feat.fields():
                    rf_name = field.name()
                    r_val = primeira_feat.attribute(rf_name)
                    contexto[f"{nome_rel}.{rf_name}"] = str(r_val) if r_val is not None else ""

                for field in primeira_feat.fields():
                    rf_name = field.name()
                    valores_lista = [str(rf.attribute(rf_name)).strip() for rf in pivo_features if rf.attribute(rf_name) is not None]
                    contexto[f"{nome_rel}.{rf_name}_LISTA"] = ", ".join(valores_lista)

    return contexto, rel_data_dict


def _processar_loops_em_paragrafos(doc, rel_data_dict):
    """Processa blocos de repetição {{#RELACAO}} texto {{/RELACAO}} em parágrafos."""
    for p in doc.paragraphs:
        _consolidar_runs_paragrafo(p)

    for rel_nome, feicoes_rel in rel_data_dict.items():
        tag_inicio_pattern = r"\{\{\s*#\s*" + re.escape(rel_nome) + r"\s*\}\}"
        tag_fim_pattern = r"\{\{\s*/\s*" + re.escape(rel_nome) + r"\s*\}\}"
        
        inicio_idx = -1
        i = 0
        while i < len(doc.paragraphs):
            p_text = doc.paragraphs[i].text
            if re.search(tag_inicio_pattern, p_text):
                inicio_idx = i
            
            if inicio_idx != -1 and re.search(tag_fim_pattern, p_text):
                fim_idx = i
                
                if inicio_idx == fim_idx:
                    match = re.search(f"{tag_inicio_pattern}(.*?){tag_fim_pattern}", p_text, re.DOTALL)
                    if match:
                        template_trechos = [match.group(1)]
                        trechos_gerados = []
                        if feicoes_rel:
                            for feat in feicoes_rel:
                                trecho_item = template_trechos[0]
                                for field in feat.fields():
                                    f_name = field.name()
                                    val = feat.attribute(f_name)
                                    val_str = str(val) if val is not None else ""
                                    pat1 = r"\{\{\s*" + re.escape(f_name) + r"\s*\}\}"
                                    pat2 = r"\{\{\s*" + re.escape(f"{rel_nome}.{f_name}") + r"\s*\}\}"
                                    trecho_item = re.sub(pat1, val_str, trecho_item)
                                    trecho_item = re.sub(pat2, val_str, trecho_item)
                                trechos_gerados.append(trecho_item)
                            substituicao = "".join(trechos_gerados)
                        else:
                            substituicao = ""
                            
                        novo_p_text = re.sub(f"{tag_inicio_pattern}.*?{tag_fim_pattern}", substituicao, p_text, flags=re.DOTALL)
                        doc.paragraphs[inicio_idx].text = novo_p_text
                else:
                    template_paras = [p.text for p in doc.paragraphs[inicio_idx+1:fim_idx]]
                    for p_remove in reversed(range(inicio_idx+1, fim_idx+1)):
                        p_element = doc.paragraphs[p_remove]._element
                        p_element.getparent().remove(p_element)
                    
                    p_ancora = doc.paragraphs[inicio_idx]
                    texto_antes_tag = re.sub(f"{tag_inicio_pattern}.*", "", p_ancora.text)
                    p_ancora.text = texto_antes_tag
                    
                    if feicoes_rel:
                        para_insercao = p_ancora
                        for feat in feicoes_rel:
                            for t_para in template_paras:
                                linha_preenchida = t_para
                                for field in feat.fields():
                                    f_name = field.name()
                                    val = feat.attribute(f_name)
                                    val_str = str(val) if val is not None else ""
                                    pat1 = r"\{\{\s*" + re.escape(f_name) + r"\s*\}\}"
                                    pat2 = r"\{\{\s*" + re.escape(f"{rel_nome}.{f_name}") + r"\s*\}\}"
                                    linha_preenchida = re.sub(pat1, val_str, linha_preenchida)
                                    linha_preenchida = re.sub(pat2, val_str, linha_preenchida)
                                
                                novo_p = doc.add_paragraph(linha_preenchida)
                                para_insercao._element.addnext(novo_p._element)
                                para_insercao = novo_p
                
                inicio_idx = -1
                i = -1 
            i += 1


def _processar_paragrafos(paragraphs, context, imagem_croqui=None):
    """Substitui variáveis simples nos parágrafos consolidados."""
    for paragraph in paragraphs:
        _consolidar_runs_paragrafo(paragraph)
        texto_completo = paragraph.text

        if "{{ croqui }}" in texto_completo or "{{croqui}}" in texto_completo:
            paragraph.clear()
            if imagem_croqui and os.path.exists(imagem_croqui):
                paragraph.add_run().add_picture(imagem_croqui, width=Inches(5))
            else:
                paragraph.add_run("Croqui não disponível")
        elif "{{" in texto_completo:
            novo_texto = texto_completo
            for chave, valor in context.items():
                val_str = str(valor) if valor is not None else ""
                pat = r"\{\{\s*" + re.escape(chave) + r"\s*\}\}"
                novo_texto = re.sub(pat, val_str, novo_texto)
            
            paragraph.clear()
            paragraph.add_run(novo_texto)


def _processar_tabelas_multiplas(tables, context, rel_data_dict, imagem_croqui=None):
    """Processa tabelas replicando linhas para relações 1:N e N:M."""
    for table in tables:
        rows = list(table.rows)
        for row in rows:
            row_text = "".join([cell.text for cell in row.cells])
            
            rel_encontrada = None
            for nome_rel in rel_data_dict.keys():
                if f"{{{{ {nome_rel}." in row_text or f"{{{{{nome_rel}." in row_text or f"{{{{#{nome_rel}" in row_text:
                    rel_encontrada = nome_rel
                    break

            if rel_encontrada:
                itens_rel = rel_data_dict[rel_encontrada]
                tr_elem = row._tr

                if itens_rel:
                    for feat_rel in reversed(itens_rel):
                        new_tr = copy.deepcopy(tr_elem)
                        tr_elem.addnext(new_tr)
                        
                        from docx.table import _Row
                        new_row = _Row(new_tr, table)

                        local_ctx = dict(context)
                        for field in feat_rel.fields():
                            rf_name = field.name()
                            r_val = feat_rel.attribute(rf_name)
                            r_str = str(r_val) if r_val is not None else ""
                            local_ctx[f"{rel_encontrada}.{rf_name}"] = r_str
                            local_ctx[rf_name] = r_str

                        for cell in new_row.cells:
                            _processar_paragrafos(cell.paragraphs, local_ctx, imagem_croqui)

                    parent = tr_elem.getparent()
                    parent.remove(tr_elem)
                else:
                    empty_ctx = dict(context)
                    for cell in row.cells:
                        for run in [r for p in cell.paragraphs for r in p.runs]:
                            run.text = re.sub(r"\{\{\s*" + re.escape(rel_encontrada) + r"\.[^}]+\s*\}\}", "", run.text)
                        _processar_paragrafos(cell.paragraphs, empty_ctx, imagem_croqui)
            else:
                for cell in row.cells:
                    _processar_paragrafos(cell.paragraphs, context, imagem_croqui)
                    _processar_tabelas_multiplas(cell.tables, context, rel_data_dict, imagem_croqui)


class DialogoSelecaoExportacaoMultipla(QDialog):
    """Janela para escolher quais objetos filhos gerar e o formato de saída (DOCX ou PDF)."""
    
    def __init__(self, lista_opcoes, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Exportação de Múltiplos Arquivos")
        self.resize(580, 420)
        self.lista_opcoes = lista_opcoes
        self.itens_selecionados = []
        self.formato_escolhido = "DOCX"
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("<b>Selecione os registros vinculados que deseja exportar:</b>"))
        
        self.list_widget = QListWidget()
        for opcao in self.lista_opcoes:
            item = QListWidgetItem(opcao['display'])
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked)
            item.setData(Qt.UserRole, opcao) 
            self.list_widget.addItem(item)
            
        layout.addWidget(self.list_widget)

        btn_layout_sel = QHBoxLayout()
        btn_sel_tudo = QPushButton("Marcar Todos")
        btn_sel_tudo.clicked.connect(lambda: self.alterar_selecao(Qt.Checked))
        btn_des_tudo = QPushButton("Desmarcar Todos")
        btn_des_tudo.clicked.connect(lambda: self.alterar_selecao(Qt.Unchecked))
        
        btn_layout_sel.addWidget(btn_sel_tudo)
        btn_layout_sel.addWidget(btn_des_tudo)
        btn_layout_sel.addStretch()
        layout.addLayout(btn_layout_sel)

        form_layout = QHBoxLayout()
        form_layout.addWidget(QLabel("<b>Formato de Saída:</b>"))
        self.combo_formato = QComboBox()
        self.combo_formato.addItems(["Word (.docx)", "PDF (.pdf)"])
        form_layout.addWidget(self.combo_formato)
        form_layout.addStretch()
        layout.addLayout(form_layout)

        botoes = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        botoes.accepted.connect(self.aceitar)
        botoes.rejected.connect(self.reject)
        layout.addWidget(botoes)

    def alterar_selecao(self, estado):
        for i in range(self.list_widget.count()):
            self.list_widget.item(i).setCheckState(estado)

    def aceitar(self):
        self.itens_selecionados = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.checkState() == Qt.Checked:
                self.itens_selecionados.append(item.data(Qt.UserRole))
        
        if not self.itens_selecionados:
            QMessageBox.warning(self, "Aviso", "Selecione pelo menos um item para exportar.")
            return

        fmt = self.combo_formato.currentText()
        self.formato_escolhido = "PDF" if "PDF" in fmt else "DOCX"
        self.accept()


def _executar_geracao_documento(doc_config):
    """Executa a geração dos documentos com suporte a Word/LibreOffice para PDF e N:M."""
    nome_camada = doc_config["camada"]
    template_path = doc_config["template_path"]
    titulo = doc_config["titulo"]
    por_relacao = doc_config.get("por_relacao", False)
    rel_split = doc_config.get("rel_split", "")
    campo_label_pai = doc_config.get("campo_label_pai", "")
    campo_label_filho = doc_config.get("campo_label_filho", "")

    if not os.path.exists(template_path):
        QMessageBox.warning(iface.mainWindow(), "Arquivo Ausente", f"O arquivo de modelo não foi encontrado:\n{template_path}")
        return

    camadas = QgsProject.instance().mapLayersByName(nome_camada)
    if not camadas:
        QMessageBox.warning(iface.mainWindow(), "Erro", f"A camada '{nome_camada}' não foi encontrada no projeto.")
        return

    layer = camadas[0]
    feicoes_selecionadas = list(layer.selectedFeatures())

    if not feicoes_selecionadas:
        QMessageBox.warning(iface.mainWindow(), "Seleção Necessária", f"Selecione ao menos um objeto na camada '{nome_camada}'.")
        return

    data_extenso = _obter_data_por_extenso()
    rel_manager = QgsProject.instance().relationManager()
    relacoes_camada = [rel for rel in rel_manager.relations().values() if rel.referencedLayerId() == layer.id()]

    lista_exportacao = []
    formato_saida = "DOCX"
    
    if por_relacao and rel_split:
        rel_obj = next((r for r in relacoes_camada if r.name() == rel_split), None)
        if not rel_obj:
            QMessageBox.warning(iface.mainWindow(), "Erro de Relação", f"A relação '{rel_split}' não foi encontrada nas Propriedades do Projeto.")
            return

        pivo_layer = rel_obj.referencingLayer()
        outras_rels_pivo = [
            r for r in rel_manager.relations().values() 
            if r.referencingLayerId() == pivo_layer.id() and r.id() != rel_obj.id()
        ]
        
        is_nm = len(outras_rels_pivo) > 0
        segunda_rel = outras_rels_pivo[0] if is_nm else None

        lista_opcoes_dialog = []
        for feat in feicoes_selecionadas:
            if campo_label_pai and campo_label_pai in [f.name() for f in feat.fields()]:
                val_p = feat.attribute(campo_label_pai)
                txt_pai = f"{val_p}" if val_p is not None else f"ID: {feat.id()}"
            else:
                txt_pai = f"ID: {feat.id()}"

            pivo_features = list(rel_obj.getRelatedFeatures(feat))
            
            for idx_rel, child_raw in enumerate(pivo_features, start=1):
                if is_nm:
                    child_feat = segunda_rel.getReferencedFeature(child_raw)
                else:
                    child_feat = child_raw

                if child_feat and child_feat.isValid():
                    if campo_label_filho and campo_label_filho in [f.name() for f in child_feat.fields()]:
                        val_c = child_feat.attribute(campo_label_filho)
                        txt_filho = f"{campo_label_filho}: {val_c}" if val_c is not None else f"ID: {child_feat.id()}"
                    else:
                        txt_filho = f"ID: {child_feat.id()}"

                    display_name = f"{txt_pai} ➔ [{txt_filho}]"
                    
                    lista_opcoes_dialog.append({
                        'parent_feat': feat,
                        'child_feat': child_feat,
                        'idx_rel': idx_rel,
                        'display': display_name
                    })
                
        if not lista_opcoes_dialog:
            QMessageBox.information(iface.mainWindow(), "Sem Vínculos", f"Os registros selecionados na camada principal não possuem nenhum vínculo em '{rel_split}'.")
            return
            
        dlg = DialogoSelecaoExportacaoMultipla(lista_opcoes_dialog, iface.mainWindow())
        if dlg.exec_() != QDialog.Accepted:
            return
            
        lista_exportacao = dlg.itens_selecionados
        formato_saida = dlg.formato_escolhido
    else:
        for idx, feat in enumerate(feicoes_selecionadas, start=1):
            lista_exportacao.append({
                'parent_feat': feat,
                'idx_rel': idx
            })

    pasta_destino = QFileDialog.getExistingDirectory(iface.mainWindow(), "Selecione a Pasta para Salvar os Documentos")
    if not pasta_destino:
        return

    ms_word = None
    libreoffice_path = None

    if formato_saida == "PDF":
        try:
            import win32com.client
            ms_word = win32com.client.DispatchEx("Word.Application")
            ms_word.Visible = False
        except Exception:
            ms_word = None
            caminhos_lo = [
                r"C:\Program Files\LibreOffice\program\soffice.exe",
                r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"
            ]
            for path in caminhos_lo:
                if os.path.exists(path):
                    libreoffice_path = path
                    break

            if not libreoffice_path:
                QMessageBox.warning(
                    iface.mainWindow(), 
                    "Aviso de Conversão", 
                    "Nem o Microsoft Word nem o LibreOffice foram encontrados no sistema para converter em PDF.\n\nOs arquivos serão salvos em formato Word (.docx)."
                )
                formato_saida = "DOCX"

    gerados = 0
    primeiro_arquivo = None

    def _processar_e_salvar_doc(feature, ctx_dict, rel_dict, sulfixo_nome):
        imagem_croqui = None
        area_estudo_list = QgsProject.instance().mapLayersByName("ÁREA DE ESTUDO")
        if area_estudo_list and feature.geometry():
            area_de_estudo_layer = area_estudo_list[0]
            novo_obj = QgsFeature()
            novo_obj.setGeometry(feature.geometry())
            with edit(area_de_estudo_layer):
                area_de_estudo_layer.addFeature(novo_obj)

            imagem_croqui = os.path.join(pasta_destino, f"temp_croqui_{sulfixo_nome}.png")
            layout = QgsProject.instance().layoutManager().layoutByName('VIABILIDADE CONSTRUÇÃO')
            if layout:
                map_item = layout.itemById('Mapa 1')
                if map_item:
                    extent = feature.geometry().boundingBox()
                    extent.grow(100)
                    map_item.setExtent(extent)
                    map_item.refresh()
                    exporter = QgsLayoutExporter(layout)
                    exporter.exportToImage(imagem_croqui, QgsLayoutExporter.ImageExportSettings())

        doc = Document(template_path)
        _processar_loops_em_paragrafos(doc, rel_dict)
        _processar_paragrafos(doc.paragraphs, ctx_dict, imagem_croqui)
        _processar_tabelas_multiplas(doc.tables, ctx_dict, rel_dict, imagem_croqui)

        for section in doc.sections:
            header_text = "".join([p.text for p in section.header.paragraphs])
            if "{{" in header_text:
                _processar_paragrafos(section.header.paragraphs, ctx_dict, imagem_croqui)
                _processar_tabelas_multiplas(section.header.tables, ctx_dict, rel_dict, imagem_croqui)

            footer_text = "".join([p.text for p in section.footer.paragraphs])
            if "{{" in footer_text:
                _processar_paragrafos(section.footer.paragraphs, ctx_dict, imagem_croqui)
                _processar_tabelas_multiplas(section.footer.tables, ctx_dict, rel_dict, imagem_croqui)

        protocolo_ou_id = ctx_dict.get("protocolo", ctx_dict.get("id", str(feature.id())))
        nome_arquivo = _limpar_nome_arquivo(f"{titulo}_{protocolo_ou_id}_{sulfixo_nome}")
        
        output_path = os.path.join(pasta_destino, f"{nome_arquivo}.docx")
        doc.save(output_path)
        
        if formato_saida == "PDF":
            pdf_path = output_path.replace(".docx", ".pdf")
            sucesso_pdf = False

            if ms_word:
                try:
                    caminho_word_in = os.path.abspath(output_path).replace("/", "\\")
                    caminho_word_out = os.path.abspath(pdf_path).replace("/", "\\")
                    doc_word = ms_word.Documents.Open(caminho_word_in)
                    doc_word.SaveAs(caminho_word_out, FileFormat=17)
                    doc_word.Close()
                    sucesso_pdf = True
                except Exception:
                    sucesso_pdf = False

            if not sucesso_pdf and libreoffice_path:
                try:
                    cmd = [
                        libreoffice_path,
                        "--headless",
                        "--convert-to", "pdf",
                        "--outdir", pasta_destino,
                        output_path
                    ]
                    subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
                    sucesso_pdf = os.path.exists(pdf_path)
                except Exception:
                    sucesso_pdf = False

            if sucesso_pdf and os.path.exists(pdf_path):
                try:
                    os.remove(output_path)
                except Exception:
                    pass
                output_path = pdf_path
                
        return output_path

    for item in lista_exportacao:
        feat = item['parent_feat']
        idx = item['idx_rel']

        context_base, rel_data_dict = _extrair_dados_hierarquia_3_niveis(layer, feat)
        context_base["data_extenso"] = data_extenso
        context_base["ano"] = datetime.now().year

        if por_relacao and rel_split:
            child_feat = item['child_feat']
            ctx = dict(context_base)
            
            for field in child_feat.fields():
                rf_name = field.name()
                r_val = child_feat.attribute(rf_name)
                ctx[f"{rel_split}.{rf_name}"] = str(r_val) if r_val is not None else ""

            out_path = _processar_e_salvar_doc(feat, ctx, rel_data_dict, f"{feat.id()}_{idx}")
            gerados += 1
            if gerados == 1: primeiro_arquivo = out_path
            
        else:
            ctx = dict(context_base)
            out_path = _processar_e_salvar_doc(feat, ctx, rel_data_dict, str(idx))
            gerados += 1
            if gerados == 1: primeiro_arquivo = out_path

    if ms_word:
        try:
            ms_word.Quit()
        except Exception:
            pass

    if primeiro_arquivo:
        os.startfile(pasta_destino)

    QMessageBox.information(iface.mainWindow(), "Sucesso", f"{gerados} documento(s) gerado(s) com sucesso na pasta:\n{pasta_destino}")


class FormEdicaoDocumentoDialog(QDialog):
    """Janela secundária para Adicionar ou Editar um Modelo de Documento."""

    def __init__(self, doc_dados=None, parent=None):
        super().__init__(parent)
        self.doc_dados = doc_dados
        self.dados_resultado = None

        if self.doc_dados:
            self.setWindowTitle("Editar Modelo de Documento")
        else:
            self.setWindowTitle("Adicionar Novo Modelo de Documento")

        self.resize(680, 560)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        form_layout = QFormLayout()

        self.txt_nome = QLineEdit()
        self.txt_nome.textChanged.connect(self.atualizar_visibilidade_botoes)
        self.txt_nome.setPlaceholderText("Ex: Parecer Técnico de Loteamento")
        form_layout.addRow("Título do Documento:", self.txt_nome)

        self.combo_camadas = QComboBox()
        self.combo_camadas.currentIndexChanged.connect(self.popula_campos_pai_e_relacoes)
        form_layout.addRow("Selecione a Camada Principal (Pai):", self.combo_camadas)

        file_layout = QHBoxLayout()
        self.txt_path = QLineEdit()
        self.txt_path.setReadOnly(True)
        self.txt_path.textChanged.connect(self.atualizar_visibilidade_botoes)

        btn_browse = QPushButton("Buscar .docx...")
        btn_browse.clicked.connect(self.selecionar_arquivo_docx)

        self.btn_edit_doc = QPushButton("✏️")
        self.btn_edit_doc.setToolTip("Abrir/Editar Modelo Word")
        self.btn_edit_doc.clicked.connect(lambda: self._abrir_arquivo_externo(self.txt_path.text()))

        self.btn_clear_doc = QPushButton("🗑️")
        self.btn_clear_doc.setToolTip("Limpar Modelo Word")
        self.btn_clear_doc.clicked.connect(self.txt_path.clear)

        self.btn_gen_doc = QPushButton("📄 Gerar Modelo DOCX")
        self.btn_gen_doc.setStyleSheet("font-weight: bold; color: #2e7d32;")
        self.btn_gen_doc.clicked.connect(self.gerar_modelo_docx_direto)

        file_layout.addWidget(self.txt_path)
        file_layout.addWidget(btn_browse)
        file_layout.addWidget(self.btn_edit_doc)
        file_layout.addWidget(self.btn_clear_doc)
        file_layout.addWidget(self.btn_gen_doc)

        form_layout.addRow("Modelo Word (.docx):", file_layout)

        rel_split_layout = QHBoxLayout()
        self.chk_por_relacao = QCheckBox("Gerar um documento por registro relacionado (Filho)")
        self.chk_por_relacao.setEnabled(False)
        self.chk_por_relacao.stateChanged.connect(self.atualizar_estado_relacao)
        
        self.combo_rel_split = QComboBox()
        self.combo_rel_split.setEnabled(False)
        self.combo_rel_split.currentIndexChanged.connect(self.popula_campos_filho)
        
        rel_split_layout.addWidget(self.chk_por_relacao)
        rel_split_layout.addWidget(QLabel("Relação Mestre:"))
        rel_split_layout.addWidget(self.combo_rel_split)
        form_layout.addRow("", rel_split_layout)

        self.combo_label_pai = QComboBox()
        form_layout.addRow("Campo Identificador (Camada Pai):", self.combo_label_pai)

        self.combo_label_filho = QComboBox()
        self.combo_label_filho.setEnabled(False)
        form_layout.addRow("Campo Identificador (Camada Filho/N:M):", self.combo_label_filho)

        layout.addLayout(form_layout)

        layout.addWidget(QLabel("<b>Guia de Hierarquia (Vô ➔ Pai ➔ Filho/N:M) no Word:</b>"))
        self.txt_relacoes_info = QTextEdit()
        self.txt_relacoes_info.setReadOnly(True)
        self.txt_relacoes_info.setFixedHeight(160)
        self.txt_relacoes_info.setStyleSheet("background-color: #f8f9fa; font-size: 11px;")
        layout.addWidget(self.txt_relacoes_info)

        self.popula_camadas()

        if self.doc_dados:
            self.txt_nome.setText(self.doc_dados.get("titulo", ""))
            index_camada = self.combo_camadas.findText(self.doc_dados.get("camada", ""))
            if index_camada >= 0:
                self.combo_camadas.setCurrentIndex(index_camada)
            self.txt_path.setText(self.doc_dados.get("template_path", ""))
            
            if self.doc_dados.get("por_relacao"):
                self.chk_por_relacao.setChecked(True)
                idx_rel = self.combo_rel_split.findText(self.doc_dados.get("rel_split", ""))
                if idx_rel >= 0:
                    self.combo_rel_split.setCurrentIndex(idx_rel)

            idx_cp = self.combo_label_pai.findText(self.doc_dados.get("campo_label_pai", ""))
            if idx_cp >= 0:
                self.combo_label_pai.setCurrentIndex(idx_cp)

            idx_cf = self.combo_label_filho.findText(self.doc_dados.get("campo_label_filho", ""))
            if idx_cf >= 0:
                self.combo_label_filho.setCurrentIndex(idx_cf)

        self.atualizar_visibilidade_botoes()

        botoes_layout = QHBoxLayout()
        btn_salvar = QPushButton("💾 Salvar")
        btn_salvar.clicked.connect(self.salvar)
        btn_cancelar = QPushButton("Cancelar")
        btn_cancelar.clicked.connect(self.reject)

        botoes_layout.addStretch()
        botoes_layout.addWidget(btn_salvar)
        botoes_layout.addWidget(btn_cancelar)
        layout.addLayout(botoes_layout)

    def popula_camadas(self):
        self.combo_camadas.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayerType.VectorLayer:
                self.combo_camadas.addItem(layer.name())
        self.popula_campos_pai_e_relacoes()

    def popula_campos_pai_e_relacoes(self):
        nome_camada = self.combo_camadas.currentText()
        self.combo_label_pai.clear()
        
        if not nome_camada:
            return

        camadas = QgsProject.instance().mapLayersByName(nome_camada)
        if not camadas:
            return

        layer = camadas[0]
        for field in layer.fields():
            self.combo_label_pai.addItem(field.name())

        rel_manager = QgsProject.instance().relationManager()
        relacoes = [rel for rel in rel_manager.relations().values() if rel.referencedLayerId() == layer.id()]

        self.combo_rel_split.blockSignals(True)
        current_rel = self.combo_rel_split.currentText()
        self.combo_rel_split.clear()

        if relacoes:
            self.chk_por_relacao.setEnabled(True)
            for rel in relacoes:
                self.combo_rel_split.addItem(rel.name())
            idx = self.combo_rel_split.findText(current_rel)
            if idx >= 0:
                self.combo_rel_split.setCurrentIndex(idx)
        else:
            self.chk_por_relacao.setChecked(False)
            self.chk_por_relacao.setEnabled(False)

        self.combo_rel_split.blockSignals(False)
        self.atualizar_estado_relacao()

    def popula_campos_filho(self):
        nome_camada = self.combo_camadas.currentText()
        rel_nome = self.combo_rel_split.currentText()
        self.combo_label_filho.clear()

        if not nome_camada or not rel_nome:
            return

        camadas = QgsProject.instance().mapLayersByName(nome_camada)
        if not camadas:
            return

        layer = camadas[0]
        rel_manager = QgsProject.instance().relationManager()
        relacoes = [rel for rel in rel_manager.relations().values() if rel.referencedLayerId() == layer.id()]
        rel_obj = next((r for r in relacoes if r.name() == rel_nome), None)

        if rel_obj:
            pivo_layer = rel_obj.referencingLayer()
            outras_rels_pivo = [
                r for r in rel_manager.relations().values() 
                if r.referencingLayerId() == pivo_layer.id() and r.id() != rel_obj.id()
            ]

            if outras_rels_pivo and outras_rels_pivo[0].referencedLayer():
                camada_final = outras_rels_pivo[0].referencedLayer()
                for field in camada_final.fields():
                    self.combo_label_filho.addItem(field.name())
            elif pivo_layer:
                for field in pivo_layer.fields():
                    self.combo_label_filho.addItem(field.name())

        self.atualizar_info_relacoes()

    def atualizar_estado_relacao(self):
        ativo = self.chk_por_relacao.isChecked()
        self.combo_rel_split.setEnabled(ativo)
        self.combo_label_filho.setEnabled(ativo)
        self.popula_campos_filho()

    def atualizar_visibilidade_botoes(self):
        has_doc = bool(self.txt_path.text().strip())
        self.btn_gen_doc.setVisible(not has_doc)
        self.btn_edit_doc.setVisible(has_doc)
        self.btn_clear_doc.setVisible(has_doc)

    def _abrir_arquivo_externo(self, caminho_arquivo):
        if caminho_arquivo and os.path.exists(caminho_arquivo):
            try:
                os.startfile(caminho_arquivo)
            except Exception as e:
                QMessageBox.critical(self, "Erro", f"Não foi possível abrir o arquivo:\n{e}")
        else:
            QMessageBox.warning(self, "Aviso", "O caminho do arquivo não é válido ou o arquivo não foi encontrado.")

    def gerar_modelo_docx_direto(self):
        titulo = self.txt_nome.text().strip() or "Novo Documento"
        camada_selecionada = self.combo_camadas.currentText()

        caminho_created = gerar_template_word_documento_base(titulo, camada_selecionada)
        self.txt_path.setText(caminho_created)
        QMessageBox.information(self, "Sucesso", f"Modelo Word criado com sucesso em:\n{caminho_created}")

    def atualizar_info_relacoes(self):
        nome_camada = self.combo_camadas.currentText()
        if not nome_camada:
            self.txt_relacoes_info.setPlainText("Nenhuma camada selecionada.")
            return

        camadas = QgsProject.instance().mapLayersByName(nome_camada)
        if not camadas:
            self.txt_relacoes_info.setPlainText("Camada não encontrada no projeto.")
            return

        layer = camadas[0]
        rel_manager = QgsProject.instance().relationManager()
        
        rel_filhos = [rel for rel in rel_manager.relations().values() if rel.referencedLayerId() == layer.id()]
        rel_vos = [rel for rel in rel_manager.relations().values() if rel.referencingLayerId() == layer.id()]

        info_lines = []
        info_lines.append("📌 GUIA DE VARIÁVEIS DOS 3 NÍVEIS:")
        info_lines.append(f"1. PAI (Camada Atual '{nome_camada}'): {{{{campo}}}} ou {{{{{nome_camada}.campo}}}}")

        if rel_vos:
            info_lines.append("\n2. VÔ (Camadas Superiores Referenciadas por Chave Estrangeira):")
            for r in rel_vos:
                p_layer = r.referencedLayer()
                p_nome = p_layer.name() if p_layer else "PaiSuper"
                info_lines.append(f"   - Via Relação '{r.name()}': {{{{{r.name()}.campo}}}} ou {{{{{p_nome}.campo}}}}")

        if rel_filhos:
            info_lines.append("\n3. FILHO / N:M (Camadas Inferiores Referenciantes):")
            for r in rel_filhos:
                info_lines.append(f"   - Tabela Repetitiva: Insira {{{{{r.name()}.campo}}}} numa linha da tabela")
                info_lines.append(f"   - Bloco Parágrafo: {{{{#{r.name()}}}}} texto {{{{campo}}}} {{{{{r.name()}}}}}")
                info_lines.append(f"   - Lista Separada por Vírgula: {{{{{r.name()}.campo_LISTA}}}}")

        self.txt_relacoes_info.setPlainText("\n".join(info_lines))

    def selecionar_arquivo_docx(self):
        caminho, _ = QFileDialog.getOpenFileName(
            self, "Selecione o Modelo Word", "", "Arquivo Word (*.docx)"
        )
        if caminho:
            self.txt_path.setText(caminho)

    def salvar(self):
        titulo = self.txt_nome.text().strip()
        camada = self.combo_camadas.currentText()
        template_path = self.txt_path.text().strip()
        por_relacao = self.chk_por_relacao.isChecked()
        rel_split = self.combo_rel_split.currentText()
        campo_label_pai = self.combo_label_pai.currentText()
        campo_label_filho = self.combo_label_filho.currentText()

        if not titulo or not camada or not template_path:
            QMessageBox.warning(self, "Aviso", "Preencha todos os campos do formulário!")
            return

        self.dados_resultado = {
            "titulo": titulo,
            "camada": camada,
            "template_path": template_path,
            "por_relacao": por_relacao,
            "rel_split": rel_split,
            "campo_label_pai": campo_label_pai,
            "campo_label_filho": campo_label_filho
        }
        self.accept()


class GerenciadorDocumentosDialog(QDialog):
    """Janela principal de gerenciamento/listagem de pareceres e documentos."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configurar Pareceres e Documentos")
        self.resize(520, 320)
        self.documentos = carregar_config_documentos()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("<b>Modelos de Documentos Cadastrados:</b>"))
        self.list_widget = QListWidget()
        self.atualizar_lista()
        self.list_widget.currentRowChanged.connect(self.ao_selecionar_item)
        layout.addWidget(self.list_widget)

        btn_layout = QHBoxLayout()
        btn_adicionar = QPushButton("➕ Adicionar Modelo...")
        btn_adicionar.clicked.connect(self.adicionar_documento)
        btn_layout.addWidget(btn_adicionar)

        self.btn_editar = QPushButton("✏️ Editar Selecionado")
        self.btn_editar.setEnabled(False)
        self.btn_editar.clicked.connect(self.editar_documento)
        btn_layout.addWidget(self.btn_editar)

        self.btn_remover = QPushButton("❌ Remover Selecionado")
        self.btn_remover.setEnabled(False)
        self.btn_remover.clicked.connect(self.remover_documento)
        btn_layout.addWidget(self.btn_remover)

        layout.addLayout(btn_layout)

        botoes_fechar = QDialogButtonBox(QDialogButtonBox.Close)
        botoes_fechar.rejected.connect(self.accept)
        layout.addWidget(botoes_fechar)

    def atualizar_lista(self):
        self.list_widget.clear()
        for d in self.documentos:
            msg_rel = f" [Divisão por: {d['rel_split']}]" if d.get("por_relacao") else ""
            self.list_widget.addItem(f"{d['titulo']} ---> Camada: {d['camada']}{msg_rel}")

    def ao_selecionar_item(self, row):
        tem_selecao = row >= 0
        self.btn_editar.setEnabled(tem_selecao)
        self.btn_remover.setEnabled(tem_selecao)

    def adicionar_documento(self):
        dlg = FormEdicaoDocumentoDialog(doc_dados=None, parent=self)
        if dlg.exec_() == QDialog.Accepted and dlg.dados_resultado:
            self.documentos.append(dlg.dados_resultado)
            salvar_config_documentos(self.documentos)
            self.atualizar_lista()
            QMessageBox.information(self, "Sucesso", "Novo modelo cadastrado com sucesso!")

    def editar_documento(self):
        row = self.list_widget.currentRow()
        if row < 0:
            return

        doc_atual = self.documentos[row]
        dlg = FormEdicaoDocumentoDialog(doc_dados=doc_atual, parent=self)
        if dlg.exec_() == QDialog.Accepted and dlg.dados_resultado:
            self.documentos[row] = dlg.dados_resultado
            salvar_config_documentos(self.documentos)
            self.atualizar_lista()
            QMessageBox.information(self, "Sucesso", "Modelo de documento atualizado com sucesso!")

    def remover_documento(self):
        row = self.list_widget.currentRow()
        if row >= 0:
            titulo = self.documentos[row]["titulo"]
            resposta = QMessageBox.question(
                self,
                "Confirmar Remoção",
                f"Deseja realmente remover o modelo '{titulo}'?",
                QMessageBox.Yes | QMessageBox.No
            )
            if resposta == QMessageBox.Yes:
                del self.documentos[row]
                salvar_config_documentos(self.documentos)
                self.atualizar_lista()


def abrir_gerenciador_documentos():
    dlg = GerenciadorDocumentosDialog(iface.mainWindow())
    dlg.exec_()