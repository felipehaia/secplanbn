import csv
import os
import re
import zipfile
from xml.sax.saxutils import escape
from collections import defaultdict
import processing

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterCrs,
    QgsProcessingParameterEnum,
    QgsProcessingException,
    QgsPointXY,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject
)


def chave_ordenacao_natural(texto):
    """Ordena IDs como 'P01, P02, P10' ou 'N01, N02, N10' na ordem numérica correta."""
    return [int(pedaco) if pedaco.isdigit() else pedaco.lower() for pedaco in re.split(r'(\d+)', str(texto))]


class CsvParaKmzPorObjeto(QgsProcessingAlgorithm):
    INPUT_CSV = 'INPUT_CSV'
    GEOM_TYPE = 'GEOM_TYPE'
    INPUT_CRS = 'INPUT_CRS'
    OUTPUT_FOLDER = 'OUTPUT_FOLDER'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return CsvParaKmzPorObjeto()

    def name(self):
        return 'csv_para_kmz_por_objeto'

    def displayName(self):
        return self.tr('CSV para KMZ (Geometria por objeto)')

    def group(self):
        return self.tr('SECPlanBN - Utilitários')

    def groupId(self):
        return 'secplanbn_utilitarios'

    def shortHelpString(self):
        return self.tr(
            'Converte um arquivo CSV (colunas: Memorial, Ponto, X, Y ou nome, id_ponto, X, Y) '
            'em arquivos KMZ válidos (Polígono ou Linha) separados por objeto.'
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_CSV,
                self.tr('Arquivo CSV de entrada'),
                behavior=QgsProcessingParameterFile.File,
                fileFilter='Arquivos CSV (*.csv);;Todos os arquivos (*.*)'
            )
        )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.GEOM_TYPE,
                self.tr('Tipo de Geometria a gerar'),
                options=[self.tr('Polígono (Área)'), self.tr('Linha (Trajeto)')],
                defaultValue=0
            )
        )

        self.addParameter(
            QgsProcessingParameterCrs(
                self.INPUT_CRS,
                self.tr('Sistema de Coordenadas (SRC) do CSV'),
                defaultValue='EPSG:31982'
            )
        )

        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_FOLDER,
                self.tr('Pasta de destino dos arquivos KMZ')
            )
        )

    def limpar_nome_arquivo(self, nome):
        nome_limpo = re.sub(r'[\\/*?:"<>|]', '_', nome.strip())
        return nome_limpo if nome_limpo else 'objeto_sem_nome'

    def gerar_kml_string(self, nome_objeto, coords_wgs84, eh_poligono):
        """Gera XML KML 2.2 UTF-8 puro, compatível com QGIS, Google Earth e SIGEF."""
        nome_xml = escape(nome_objeto)
        coords_str = "\n              ".join(f"{pt.x():.8f},{pt.y():.8f},0" for pt in coords_wgs84)

        if eh_poligono:
            geometria_xml = f"""
        <Polygon>
          <tessellate>1</tessellate>
          <outerBoundaryIs>
            <LinearRing>
              <coordinates>
              {coords_str}
              </coordinates>
            </LinearRing>
          </outerBoundaryIs>
        </Polygon>"""
        else:
            geometria_xml = f"""
        <LineString>
          <tessellate>1</tessellate>
          <coordinates>
              {coords_str}
          </coordinates>
        </LineString>"""

        return f"""<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>{nome_xml}</name>
    <Style id="estilo_padrao">
      <LineStyle>
        <color>ff0000ff</color>
        <width>2</width>
      </LineStyle>
      <PolyStyle>
        <color>4d0000ff</color>
      </PolyStyle>
    </Style>
    <Placemark>
      <name>{nome_xml}</name>
      <styleUrl>#estilo_padrao</styleUrl>{geometria_xml}
    </Placemark>
  </Document>
</kml>
"""

    def processAlgorithm(self, parameters, context, feedback):
        caminho_csv = self.parameterAsFile(parameters, self.INPUT_CSV, context)
        tipo_geom_idx = self.parameterAsEnum(parameters, self.GEOM_TYPE, context)
        crs_origem = self.parameterAsCrs(parameters, self.INPUT_CRS, context)
        pasta_saida = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)

        eh_poligono = (tipo_geom_idx == 0)

        if not os.path.exists(caminho_csv):
            raise QgsProcessingException(self.tr('Arquivo CSV não encontrado.'))

        os.makedirs(pasta_saida, exist_ok=True)

        crs_destino = QgsCoordinateReferenceSystem('EPSG:4326')
        transformador = QgsCoordinateTransform(crs_origem, crs_destino, QgsProject.instance())

        objetos = defaultdict(list)

        try:
            with open(caminho_csv, mode='r', encoding='utf-8-sig') as f:
                conteudo = f.read()
        except UnicodeDecodeError:
            with open(caminho_csv, mode='r', encoding='latin-1') as f:
                conteudo = f.read()

        linhas = [l for l in conteudo.splitlines() if l.strip()]
        if not linhas:
            raise QgsProcessingException(self.tr('O arquivo CSV está vazio.'))

        delimitador = ';' if ';' in linhas[0] else ','
        leitor = csv.DictReader(linhas, delimiter=delimitador)

        # Identifica dinamicamente as colunas (suporta Memorial/Ponto ou nome/id_ponto)
        campos = {c.strip(): c for c in (leitor.fieldnames or [])}
        col_nome = campos.get('Memorial') or campos.get('nome')
        col_ponto = campos.get('Ponto') or campos.get('id_ponto')
        col_x = campos.get('X')
        col_y = campos.get('Y')

        if not all([col_nome, col_ponto, col_x, col_y]):
            raise QgsProcessingException(
                self.tr(f'Cabeçalho inválido. Esperado: (Memorial, Ponto, X, Y) ou (nome, id_ponto, X, Y). Encontrado: {leitor.fieldnames}')
            )

        for linha_num, linha in enumerate(leitor, start=2):
            if feedback.isCanceled():
                break
            try:
                nome = linha[col_nome].strip()
                id_ponto = linha[col_ponto].strip()
                x = float(linha[col_x].strip().replace(',', '.'))
                y = float(linha[col_y].strip().replace(',', '.'))

                ponto_xy = QgsPointXY(x, y)
                if crs_origem != crs_destino:
                    ponto_xy = transformador.transform(ponto_xy)

                objetos[nome].append({
                    'id_ponto': id_ponto,
                    'pt': ponto_xy
                })
            except Exception as e:
                feedback.pushWarning(f'Linha {linha_num} ignorada ({e})')

        total_objetos = len(objetos)
        if total_objetos == 0:
            raise QgsProcessingException(self.tr('Nenhum dado válido encontrado no CSV.'))

        for idx, (nome_objeto, vertices_raw) in enumerate(objetos.items()):
            if feedback.isCanceled():
                break

            vertices_ordenados = sorted(vertices_raw, key=lambda v: chave_ordenacao_natural(v['id_ponto']))
            lista_pontos = [v['pt'] for v in vertices_ordenados]

            if eh_poligono:
                if len(lista_pontos) < 3:
                    feedback.reportError(f'"{nome_objeto}" ignorado: polígono exige no mínimo 3 vértices.')
                    continue
                if lista_pontos[0] != lista_pontos[-1]:
                    lista_pontos.append(lista_pontos[0])
            else:
                if len(lista_pontos) < 2:
                    feedback.reportError(f'"{nome_objeto}" ignorado: linha exige no mínimo 2 vértices.')
                    continue

            kml_conteudo = self.gerar_kml_string(nome_objeto, lista_pontos, eh_poligono)

            nome_arquivo = f"{self.limpar_nome_arquivo(nome_objeto)}.kmz"
            caminho_kmz = os.path.join(pasta_saida, nome_arquivo)

            # Empacota doc.kml em UTF-8 diretamente no arquivo .kmz (evita bug de acentuação do LIBKML)
            with zipfile.ZipFile(caminho_kmz, 'w', compression=zipfile.ZIP_DEFLATED) as kmz:
                kmz.writestr('doc.kml', kml_conteudo.encode('utf-8'))

            tipo_label = 'Polígono' if eh_poligono else 'Linha'
            feedback.pushInfo(f'Exportado: {caminho_kmz} ({tipo_label} com {len(vertices_ordenados)} vértices)')
            feedback.setProgress(int(((idx + 1) / total_objetos) * 100))

        return {self.OUTPUT_FOLDER: pasta_saida}


def run():
    algoritmo = CsvParaKmzPorObjeto()
    processing.execAlgorithmDialog(algoritmo, {})


if __name__ == '__main__':
    run()