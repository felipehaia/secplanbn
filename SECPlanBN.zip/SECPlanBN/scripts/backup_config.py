# scripts/backup_config.py

import os
import zipfile
import shutil
from qgis.core import QgsApplication
from qgis.utils import iface
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QRadioButton, QGroupBox,
    QFileDialog, QDialogButtonBox
)

# Caminhos base
DIR_SCRIPTS = os.path.dirname(__file__)
PASTA_PERFIL_QGIS = QgsApplication.qgisSettingsDirPath()
PASTA_DADOS_PLUGIN = os.path.join(PASTA_PERFIL_QGIS, "SECPlanBN_Data")

# Pastas de análises no perfil do usuário
PASTA_SESSIONS_ANALISE = os.path.join(PASTA_DADOS_PLUGIN, "sessoes_analise")
PASTA_CHECKLISTS = os.path.join(PASTA_DADOS_PLUGIN, "checklists")
PASTA_MODELOS_DOC = os.path.join(PASTA_DADOS_PLUGIN, "modelos_doc")

# Mapeamento dos arquivos gerais (ficam dentro da pasta 'scripts' do plugin)
CONFIG_FILES_SCRIPTS = {
    "config_buscas.txt": os.path.join(DIR_SCRIPTS, "config_buscas.txt"),
    "config_relatorios.txt": os.path.join(DIR_SCRIPTS, "config_relatorios.txt"),
    "preferencias_colunas.txt": os.path.join(DIR_SCRIPTS, "preferencias_colunas.txt"),
    "ordem_etapas.txt": os.path.join(DIR_SCRIPTS, "ordem_etapas.txt"),
}

# Mapeamento do arquivo de configurações de análises (fica no perfil do usuário)
CONFIG_FILES_PLUGIN_DATA = {
    "config_analises.txt": os.path.join(PASTA_DADOS_PLUGIN, "config_analises.txt")
}


class DialogoExportarBackup(QDialog):
    """Diálogo interativo para escolha do escopo de exportação do backup."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Exportar Backup do SECPlanBN")
        self.resize(520, 260)
        self.escopo_selecionado = "COMPLETO"
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        grp_escopo = QGroupBox("Selecione o Nível do Backup")
        lay_grp = QVBoxLayout()

        self.rb_geral = QRadioButton("1. Apenas Configurações Gerais\n   (Buscas, relatórios, colunas e ordem das etapas)")
        self.rb_analises = QRadioButton("2. Configurações Gerais + Modelos e Checklists de Parecer\n   (Inclui modelos .docx e checklists .txt)")
        self.rb_completo = QRadioButton("3. Backup Completo (Geral + Modelos + Sessões/Histórico do Usuário)\n   (Inclui TUDO: configurações, pareceres e análises salvas)")

        self.rb_completo.setChecked(True)  # Padrão recomendado

        lay_grp.addWidget(self.rb_geral)
        lay_grp.addWidget(self.rb_analises)
        lay_grp.addWidget(self.rb_completo)
        grp_escopo.setLayout(lay_grp)
        layout.addWidget(grp_escopo)

        botoes = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        botoes.accepted.connect(self.validar_e_aceitar)
        botoes.rejected.connect(self.reject)
        layout.addWidget(botoes)

    def validar_e_aceitar(self):
        if self.rb_geral.isChecked():
            self.escopo_selecionado = "GERAL"
        elif self.rb_analises.isChecked():
            self.escopo_selecionado = "MODELOS"
        else:
            self.escopo_selecionado = "COMPLETO"
        self.accept()


# ==============================================================================
# FUNÇÕES PRINCIPAIS DE EXPORTAÇÃO E IMPORTAÇÃO
# ==============================================================================

def exportar_todas_configuracoes(parent_window=None):
    """Abre o diálogo de escolha e exporta o pacote ZIP acumulativo correspondente."""
    parent = parent_window if parent_window else iface.mainWindow()
    
    dlg = DialogoExportarBackup(parent)
    if dlg.exec_() != QDialog.Accepted:
        return

    escopo = dlg.escopo_selecionado

    sugestao_nome = {
        "GERAL": "backup_configuracoes_gerais.zip",
        "MODELOS": "backup_configuracoes_modelos_pareceres.zip",
        "COMPLETO": "backup_completo_secplanbn.zip"
    }.get(escopo, "backup_secplanbn.zip")

    caminho_zip, _ = QFileDialog.getSaveFileName(
        parent,
        "Salvar Backup (ZIP)",
        sugestao_nome,
        "Arquivo ZIP (*.zip)"
    )

    if not caminho_zip:
        return

    try:
        arquivos_incluidos = 0
        with zipfile.ZipFile(caminho_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            
            # --- TODAS AS OPÇÕES (1, 2 e 3): Incluem as Configurações Gerais ---
            for filename, full_path in CONFIG_FILES_SCRIPTS.items():
                if os.path.exists(full_path):
                    zipf.write(full_path, arcname=filename)
                    arquivos_incluidos += 1

            # --- OPÇÕES 2 e 3: Incluem Configuração de Análises + Checklists + Modelos .docx ---
            if escopo in ["MODELOS", "COMPLETO"]:
                for filename, full_path in CONFIG_FILES_PLUGIN_DATA.items():
                    if os.path.exists(full_path):
                        zipf.write(full_path, arcname=filename)
                        arquivos_incluidos += 1

                for pasta_nome, pasta_abs in [("checklists", PASTA_CHECKLISTS), ("modelos_doc", PASTA_MODELOS_DOC)]:
                    if os.path.exists(pasta_abs):
                        for root, _, files in os.walk(pasta_abs):
                            for file in files:
                                full_p = os.path.join(root, file)
                                rel_p = os.path.relpath(full_p, pasta_abs)
                                arcname = os.path.join(pasta_nome, rel_p)
                                zipf.write(full_p, arcname=arcname)
                                arquivos_incluidos += 1

            # --- OPÇÃO 3: Inclui também as Sessões de Análises Salvas pelo Usuário ---
            if escopo == "COMPLETO":
                if os.path.exists(PASTA_SESSIONS_ANALISE):
                    for root, _, files in os.walk(PASTA_SESSIONS_ANALISE):
                        for file in files:
                            full_p = os.path.join(root, file)
                            rel_p = os.path.relpath(full_p, PASTA_SESSIONS_ANALISE)
                            arcname = os.path.join("sessoes_analise", rel_p)
                            zipf.write(full_p, arcname=arcname)
                            arquivos_incluidos += 1

        if arquivos_incluidos > 0:
            iface.messageBar().pushSuccess(
                "Backup Concluído",
                f"Exportado ({escopo}) com sucesso! Total de {arquivos_incluidos} arquivo(s) em:\n{caminho_zip}"
            )
        else:
            iface.messageBar().pushWarning(
                "Aviso do Backup",
                "Nenhum arquivo correspondente foi localizado para exportar."
            )
    except Exception as e:
        iface.messageBar().pushCritical("Erro no Backup", f"Falha ao exportar configurações: {e}")


def importar_todas_configuracoes(parent_window=None):
    """Lê o arquivo ZIP e distribui corretamente cada tipo de arquivo no seu local apropriado."""
    parent = parent_window if parent_window else iface.mainWindow()

    caminho_zip, _ = QFileDialog.getOpenFileName(
        parent,
        "Importar Backup do SECPlanBN (ZIP)",
        "",
        "Arquivo ZIP (*.zip)"
    )

    if not caminho_zip:
        return

    try:
        arquivos_restaurados = 0
        os.makedirs(PASTA_DADOS_PLUGIN, exist_ok=True)

        with zipfile.ZipFile(caminho_zip, 'r') as zipf:
            for item in zipf.namelist():
                if item.endswith('/'):
                    continue

                # 1. Arquivos de configuração geral de buscas/relatórios -> Pasta scripts do Plugin
                if item in CONFIG_FILES_SCRIPTS:
                    zipf.extract(item, DIR_SCRIPTS)
                    arquivos_restaurados += 1

                # 2. Configuração de análises -> Pasta SECPlanBN_Data no Perfil
                elif item in CONFIG_FILES_PLUGIN_DATA:
                    zipf.extract(item, PASTA_DADOS_PLUGIN)
                    arquivos_restaurados += 1

                # 3. Subpastas (checklists, modelos_doc, sessoes_analise) -> Pasta SECPlanBN_Data no Perfil
                elif item.startswith("checklists/") or item.startswith("modelos_doc/") or item.startswith("sessoes_analise/"):
                    zipf.extract(item, PASTA_DADOS_PLUGIN)
                    arquivos_restaurados += 1

        if arquivos_restaurados > 0:
            iface.messageBar().pushSuccess(
                "Importação Concluída", 
                f"Backup restaurado com sucesso! Total de {arquivos_restaurados} arquivo(s) atualizado(s)."
            )
        else:
            iface.messageBar().pushWarning(
                "Aviso na Importação", 
                "O arquivo ZIP selecionado não contém uma estrutura de backup reconhecida do SECPlanBN."
            )
    except Exception as e:
        iface.messageBar().pushCritical("Erro na Importação", f"Falha ao importar backup: {e}")


def exportar_configuracoes_zip():
    exportar_todas_configuracoes()

def importar_configuracoes_zip():
    importar_todas_configuracoes()