# scripts/backup_config.py

import os
import zipfile
from qgis.utils import iface
from PyQt5.QtWidgets import QFileDialog

DIR_SCRIPTS = os.path.dirname(__file__)
CONFIG_BUSCAS = os.path.join(DIR_SCRIPTS, "config_buscas.txt")
CONFIG_RELATORIOS = os.path.join(DIR_SCRIPTS, "config_relatorios.txt")


def exportar_configuracoes_zip():
    """Gera um arquivo ZIP com as configurações de buscas e relatórios."""
    caminho_zip, _ = QFileDialog.getSaveFileName(
        iface.mainWindow(),
        "Exportar Configurações (ZIP)",
        "backup_configuracoes_secplanbn.zip",
        "Arquivo ZIP (*.zip)"
    )

    if not caminho_zip:
        return

    try:
        with zipfile.ZipFile(caminho_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            if os.path.exists(CONFIG_BUSCAS):
                zipf.write(CONFIG_BUSCAS, arcname="config_buscas.txt")
            if os.path.exists(CONFIG_RELATORIOS):
                zipf.write(CONFIG_RELATORIOS, arcname="config_relatorios.txt")

        iface.messageBar().pushSuccess(
            "Backup", f"Configurações exportadas com sucesso para:\n{caminho_zip}"
        )
    except Exception as e:
        iface.messageBar().pushCritical("Erro no Backup", f"Falha ao exportar configurações: {e}")


def importar_configuracoes_zip():
    """Lê um arquivo ZIP e restaura/sobrescreve os arquivos de configuração."""
    caminho_zip, _ = QFileDialog.getOpenFileName(
        iface.mainWindow(),
        "Importar Configurações (ZIP)",
        "",
        "Arquivo ZIP (*.zip)"
    )

    if not caminho_zip:
        return

    try:
        with zipfile.ZipFile(caminho_zip, 'r') as zipf:
            arquivos = zipf.namelist()
            if "config_buscas.txt" not in arquivos and "config_relatorios.txt" not in arquivos:
                iface.messageBar().pushWarning(
                    "Aviso", "O arquivo ZIP selecionado não contém configurações válidas do SECPlanBN."
                )
                return

            if "config_buscas.txt" in arquivos:
                zipf.extract("config_buscas.txt", DIR_SCRIPTS)
            if "config_relatorios.txt" in arquivos:
                zipf.extract("config_relatorios.txt", DIR_SCRIPTS)

        iface.messageBar().pushSuccess(
            "Backup", "Configurações importadas com sucesso! Os menus foram atualizados."
        )
    except Exception as e:
        iface.messageBar().pushCritical("Erro na Importação", f"Falha ao importar configurações: {e}")