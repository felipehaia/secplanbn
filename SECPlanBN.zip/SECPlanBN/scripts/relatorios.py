# scripts/relatorios.py

import os
import csv
from qgis.core import QgsProject, QgsMapLayerType
from qgis.utils import iface
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QTextEdit,
    QDialogButtonBox, QComboBox, QListWidget, QListWidgetItem, QPushButton, 
    QFormLayout, QMessageBox, QRadioButton, QButtonGroup, QAbstractItemView
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QTextDocument, QPageLayout, QPageSize
from PyQt5.QtPrintSupport import QPrinter

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config_relatorios.txt")

SCRIPT_PADRAO_EXEMPLO = """# Mapeamento dos campos booleanos na ordem de progressão
etapas = [
    ("vistoriado", "Vistoriado"),
    ("viabilidade", "Viabilidade"),
    ("projeto", "Projeto"),
    ("edital", "Edital"),
    ("crf", "CRF"),
    ("retorno_cartorio", "Retorno Cartório")
]

def is_true(valor):
    return valor in (True, 1, 'True', 'true', 't', '1')

resultado = "Não Iniciado"
for campo, rotulo in reversed(etapas):
    val = feat.attribute(campo)
    if is_true(val):
        resultado = rotulo
        break
"""

def carregar_config_relatorios():
    """Lê o arquivo TXT e retorna a lista de configurações de relatórios."""
    relatorios = []
    if not os.path.exists(CONFIG_PATH):
        padrao = [
            f"Relatório de Processos|Excel|LOTES-BASE-PLANEJAMENTO|cadastro,id_betha|todos|Etapa Processual|{SCRIPT_PADRAO_EXEMPLO.replace(chr(10), ';;')}"
        ]
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(padrao))

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and "|" in line:
                partes = line.split("|")
                if len(partes) >= 5:
                    relatorios.append({
                        "titulo": partes[0].strip(),
                        "formato": partes[1].strip(),
                        "camada": partes[2].strip(),
                        "campos": [c.strip() for c in partes[3].split(",") if c.strip()],
                        "escopo": partes[4].strip(),
                        "nome_campo_exp": partes[5].strip() if len(partes) > 5 else "",
                        "script_exp": partes[6].replace(";;", "\n").strip() if len(partes) > 6 else ""
                    })
    return relatorios


def salvar_config_relatorios(relatorios):
    """Grava as configurações de relatórios no arquivo TXT."""
    linhas = []
    for r in relatorios:
        campos_str = ",".join(r["campos"])
        script_sanitizado = r.get("script_exp", "").replace("\n", ";;").replace("\r", "")
        nome_campo_exp = r.get("nome_campo_exp", "")
        linhas.append(f"{r['titulo']}|{r['formato']}|{r['camada']}|{campos_str}|{r['escopo']}|{nome_campo_exp}|{script_sanitizado}")
    
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(linhas))


def _eval_script_expansor(feat, script_code):
    """Executa o script Python customizado sobre uma feição do QGIS."""
    if not script_code.strip():
        return ""
    try:
        local_scope = {"feat": feat, "resultado": ""}
        exec(script_code, {}, local_scope)
        return str(local_scope.get("resultado", ""))
    except Exception as e:
        return f"Erro: {e}"


def _executar_exportacao_relatorio(relatorio_dict):
    """Processa a extração dos dados da camada e gera o arquivo PDF ou Excel estilizado."""
    from PyQt5.QtWidgets import QFileDialog

    nome_camada = relatorio_dict["camada"]
    campos = list(relatorio_dict["campos"])
    formato = relatorio_dict["formato"]
    escopo = relatorio_dict["escopo"]
    titulo = relatorio_dict["titulo"]
    nome_campo_exp = relatorio_dict.get("nome_campo_exp", "").strip()
    script_exp = relatorio_dict.get("script_exp", "").strip()

    camadas = QgsProject.instance().mapLayersByName(nome_camada)
    if not camadas:
        iface.messageBar().pushCritical("Erro", f"A camada '{nome_camada}' não foi encontrada no projeto.")
        return

    layer = camadas[0]
    if layer.type() != QgsMapLayerType.VectorLayer:
        iface.messageBar().pushWarning("Aviso", f"A camada '{nome_camada}' não é vetorial.")
        return

    if escopo == "selecionados":
        feicoes = list(layer.selectedFeatures())
        if not feicoes:
            iface.messageBar().pushWarning("Aviso", f"Nenhuma feição selecionada na camada '{nome_camada}'.")
            return
    else:
        feicoes = list(layer.getFeatures())

    if not feicoes:
        iface.messageBar().pushWarning("Aviso", "Não há feições disponíveis para exportação.")
        return

    cabecalhos = list(campos)
    if nome_campo_exp and script_exp:
        cabecalhos.append(nome_campo_exp)

    extensao = "xlsx" if formato == "Excel" else "pdf"
    filtro_salvar = "Arquivo Excel (*.xlsx)" if formato == "Excel" else "Arquivo PDF (*.pdf)"
    
    caminho_arquivo, _ = QFileDialog.getSaveFileName(
        iface.mainWindow(),
        f"Salvar Relatório - {titulo}",
        f"{titulo}.{extensao}",
        filtro_salvar
    )

    if not caminho_arquivo:
        return

    dados_matriz = []
    for feat in feicoes:
        linha = []
        for campo in campos:
            val = feat.attribute(campo)
            linha.append(str(val) if val is not None else "")
        
        if nome_campo_exp and script_exp:
            val_calculado = _eval_script_expansor(feat, script_exp)
            linha.append(val_calculado)

        dados_matriz.append(linha)

    if formato == "Excel":
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            from openpyxl.utils import get_column_letter

            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Relatório"
            ws.views.sheetView[0].showGridLines = True

            ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(cabecalhos))
            cell_title = ws.cell(row=1, column=1, value=f"{titulo} — {nome_camada}")
            cell_title.font = Font(name="Segoe UI", size=14, bold=True, color="007AC2")
            cell_title.alignment = Alignment(horizontal="left", vertical="center")
            ws.row_dimensions[1].height = 30

            fill_header = PatternFill(start_color="007AC2", end_color="007AC2", fill_type="solid")
            font_header = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
            align_header = Alignment(horizontal="center", vertical="center", wrap_text=True)
            
            border_thin = Border(
                left=Side(style='thin', color='D3D3D3'),
                right=Side(style='thin', color='D3D3D3'),
                top=Side(style='thin', color='D3D3D3'),
                bottom=Side(style='thin', color='D3D3D3')
            )

            for col_idx, field_name in enumerate(cabecalhos, start=1):
                c = ws.cell(row=3, column=col_idx, value=str(field_name).upper())
                c.fill = fill_header
                c.font = font_header
                c.alignment = align_header
                c.border = border_thin

            ws.row_dimensions[3].height = 24

            fill_zebra = PatternFill(start_color="F2F5F8", end_color="F2F5F8", fill_type="solid")
            font_body = Font(name="Segoe UI", size=10, color="222222")
            align_body = Alignment(vertical="center", wrap_text=True)

            for row_idx, row_data in enumerate(dados_matriz, start=4):
                is_even = (row_idx % 2 == 0)
                for col_idx, val in enumerate(row_data, start=1):
                    c = ws.cell(row=row_idx, column=col_idx, value=val)
                    c.font = font_body
                    c.alignment = align_body
                    c.border = border_thin
                    if is_even:
                        c.fill = fill_zebra
                ws.row_dimensions[row_idx].height = 20

            for col in ws.columns:
                max_len = 0
                col_letter = get_column_letter(col[0].column)
                
                for cell in col:
                    if cell.row == 1:
                        continue
                    if cell.value:
                        lines = str(cell.value).split("\n")
                        for line in lines:
                            if len(line) > max_len:
                                max_len = len(line)
                
                adjusted_width = min(max(max_len + 4, 14), 50)
                ws.column_dimensions[col_letter].width = adjusted_width

            ws.freeze_panes = "A4"

            wb.save(caminho_arquivo)
            iface.messageBar().pushSuccess("Relatório", f"Relatório Excel gerado com sucesso em:\n{caminho_arquivo}")

        except ImportError:
            if not caminho_arquivo.endswith(".csv"):
                caminho_arquivo = os.path.splitext(caminho_arquivo)[0] + ".csv"
            with open(caminho_arquivo, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f, delimiter=";")
                writer.writerow(cabecalhos)
                writer.writerows(dados_matriz)
            iface.messageBar().pushInfo("Relatório", f"openpyxl não encontrado. Salvo como CSV formatado em:\n{caminho_arquivo}")

    else:
        html = f"""
        <html>
        <head>
            <style>
                h2 {{ text-align: center; font-family: sans-serif; color: #007ac2; margin-bottom: 5px; }}
                p.sub {{ text-align: center; font-family: sans-serif; font-size: 10px; color: #555; margin-top: 0px; }}
                table {{ width: 100%; border-collapse: collapse; font-family: sans-serif; font-size: 10px; }}
                th {{ background-color: #007ac2; color: white; border: 1px solid #ccc; padding: 6px; text-align: left; }}
                td {{ border: 1px solid #ccc; padding: 5px; word-wrap: break-word; }}
                tr:nth-child(even) {{ background-color: #f2f5f8; }}
            </style>
        </head>
        <body>
            <h2>{titulo}</h2>
            <p class="sub">Camada: {nome_camada} | Registros: {len(dados_matriz)}</p>
            <table>
                <thead>
                    <tr>{''.join([f'<th>{c}</th>' for c in cabecalhos])}</tr>
                </thead>
                <tbody>
        """
        for row in dados_matriz:
            html += "<tr>" + "".join([f"<td>{val}</td>" for val in row]) + "</tr>"
        html += "</tbody></table></body></html>"

        doc = QTextDocument()
        doc.setHtml(html)

        printer = QPrinter(QPrinter.HighResolution)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName(caminho_arquivo)
        printer.setPageSize(QPageSize(QPageSize.A4))
        printer.setPageOrientation(QPageLayout.Landscape if len(cabecalhos) > 4 else QPageLayout.Portrait)

        doc.print_(printer)
        iface.messageBar().pushSuccess("Relatório", f"Relatório PDF salvo com sucesso em:\n{caminho_arquivo}")


class GerenciadorRelatoriosDialog(QDialog):
    """Janela de Configuração, Edição e Remoção de Relatórios."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configurar Relatórios de Exportação")
        self.resize(580, 700)
        self.relatorios = carregar_config_relatorios()
        self.indice_em_edicao = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("<b>Relatórios Cadastrados:</b>"))
        self.list_widget = QListWidget()
        self.atualizar_lista()
        self.list_widget.currentRowChanged.connect(self.ao_selecionar_item)
        layout.addWidget(self.list_widget)

        btn_layout = QHBoxLayout()
        self.btn_editar = QPushButton("✏️ Editar Relatório Selecionado")
        self.btn_editar.setEnabled(False)
        self.btn_editar.clicked.connect(self.carregar_para_edicao)
        btn_layout.addWidget(self.btn_editar)

        btn_remover = QPushButton("❌ Remover Relatório Selecionado")
        btn_remover.clicked.connect(self.remover_relatorio)
        btn_layout.addWidget(btn_remover)
        layout.addLayout(btn_layout)

        layout.addWidget(QLabel("<hr><b>Formulário de Relatório:</b>"))

        form_layout = QFormLayout()

        self.txt_nome = QLineEdit()
        self.txt_nome.setPlaceholderText("Ex: Relatório de Acompanhamento de Processos")
        form_layout.addRow("Nome do Relatório:", self.txt_nome)

        self.combo_formato = QComboBox()
        self.combo_formato.addItems(["Excel", "PDF"])
        form_layout.addRow("Formato de Exportação:", self.combo_formato)

        self.combo_camadas = QComboBox()
        form_layout.addRow("Selecione a Camada:", self.combo_camadas)

        layout.addLayout(form_layout)

        layout.addWidget(QLabel("Selecione os Campos a Exportar:"))
        self.list_campos = QListWidget()
        self.list_campos.setSelectionMode(QAbstractItemView.MultiSelection)
        self.list_campos.setFixedHeight(100)
        layout.addWidget(self.list_campos)

        layout.addWidget(QLabel("<b>Campo Calculado Expansor (Opcional - Script Python):</b>"))
        
        form_exp = QFormLayout()
        self.txt_nome_campo_exp = QLineEdit()
        self.txt_nome_campo_exp.setPlaceholderText("Ex: Etapa Atual")
        form_exp.addRow("Nome da Coluna Calculada:", self.txt_nome_campo_exp)
        layout.addLayout(form_exp)

        self.txt_script_exp = QTextEdit()
        self.txt_script_exp.setPlaceholderText("Escreva a lógica Python. Defina a variável 'resultado' para salvar o texto.")
        self.txt_script_exp.setPlainText(SCRIPT_PADRAO_EXEMPLO)
        self.txt_script_exp.setFixedHeight(120)
        layout.addWidget(self.txt_script_exp)

        layout.addWidget(QLabel("Filtro de Exportação:"))
        radio_layout = QHBoxLayout()
        self.radio_todos = QRadioButton("Exportar Todos da Camada")
        self.radio_selecionados = QRadioButton("Exportar Apenas Selecionados")
        self.radio_todos.setChecked(True)

        self.btn_group_escopo = QButtonGroup(self)
        self.btn_group_escopo.addButton(self.radio_todos)
        self.btn_group_escopo.addButton(self.radio_selecionados)

        radio_layout.addWidget(self.radio_todos)
        radio_layout.addWidget(self.radio_selecionados)
        layout.addLayout(radio_layout)

        self.popula_camadas()
        self.combo_camadas.currentIndexChanged.connect(self.popula_campos)

        botoes_salvar_layout = QHBoxLayout()
        self.btn_salvar = QPushButton("💾 Salvar Relatório")
        self.btn_salvar.clicked.connect(self.salvar_relatorio)
        botoes_salvar_layout.addWidget(self.btn_salvar)

        self.btn_cancelar_edicao = QPushButton("Cancelar Edição")
        self.btn_cancelar_edicao.setVisible(False)
        self.btn_cancelar_edicao.clicked.connect(self.limpar_formulario)
        botoes_salvar_layout.addWidget(self.btn_cancelar_edicao)

        layout.addLayout(botoes_salvar_layout)

        botoes_fechar = QDialogButtonBox(QDialogButtonBox.Close)
        botoes_fechar.rejected.connect(self.accept)
        layout.addWidget(botoes_fechar)

    def ao_selecionar_item(self, row):
        self.btn_editar.setEnabled(row >= 0)

    def atualizar_lista(self):
        self.list_widget.clear()
        for r in self.relatorios:
            escopo_str = "Apenas Selecionados" if r["escopo"] == "selecionados" else "Todos os Registros"
            exp_str = f" | Expansor: [{r['nome_campo_exp']}]" if r.get("nome_campo_exp") else ""
            item_str = f"[{r['formato']}] {r['titulo']} ---> Camada: {r['camada']}{exp_str} | Filtro: {escopo_str}"
            self.list_widget.addItem(item_str)

    def popula_camadas(self):
        self.combo_camadas.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayerType.VectorLayer:
                self.combo_camadas.addItem(layer.name())
        self.popula_campos()

    def popula_campos(self):
        self.list_campos.clear()
        nome_camada = self.combo_camadas.currentText()
        if nome_camada:
            camadas = QgsProject.instance().mapLayersByName(nome_camada)
            if camadas and camadas[0].type() == QgsMapLayerType.VectorLayer:
                layer = camadas[0]
                for field in layer.fields():
                    item = QListWidgetItem(field.name())
                    self.list_campos.addItem(item)

    def carregar_para_edicao(self):
        row = self.list_widget.currentRow()
        if row < 0:
            return
        
        self.indice_em_edicao = row
        r = self.relatorios[row]

        self.txt_nome.setText(r["titulo"])
        
        index_fmt = self.combo_formato.findText(r["formato"])
        if index_fmt >= 0:
            self.combo_formato.setCurrentIndex(index_fmt)

        index_camada = self.combo_camadas.findText(r["camada"])
        if index_camada >= 0:
            self.combo_camadas.setCurrentIndex(index_camada)
            self.popula_campos()

        for i in range(self.list_campos.count()):
            item = self.list_campos.item(i)
            if item.text() in r["campos"]:
                item.setSelected(True)
            else:
                item.setSelected(False)

        self.txt_nome_campo_exp.setText(r.get("nome_campo_exp", ""))
        self.txt_script_exp.setPlainText(r.get("script_exp", SCRIPT_PADRAO_EXEMPLO))

        if r["escopo"] == "selecionados":
            self.radio_selecionados.setChecked(True)
        else:
            self.radio_todos.setChecked(True)

        self.btn_salvar.setText("💾 Atualizar Relatório")
        self.btn_cancelar_edicao.setVisible(True)

    def limpar_formulario(self):
        self.indice_em_edicao = None
        self.txt_nome.clear()
        self.list_campos.clearSelection()
        self.txt_nome_campo_exp.clear()
        self.txt_script_exp.setPlainText(SCRIPT_PADRAO_EXEMPLO)
        self.radio_todos.setChecked(True)
        self.btn_salvar.setText("💾 Salvar Relatório")
        self.btn_cancelar_edicao.setVisible(False)
        self.list_widget.clearSelection()

    def salvar_relatorio(self):
        titulo = self.txt_nome.text().strip()
        formato = self.combo_formato.currentText()
        camada = self.combo_camadas.currentText()
        campos_selecionados = [item.text() for item in self.list_campos.selectedItems()]
        escopo = "selecionados" if self.radio_selecionados.isChecked() else "todos"
        
        nome_campo_exp = self.txt_nome_campo_exp.text().strip()
        script_exp = self.txt_script_exp.toPlainText().strip()

        if not titulo:
            QMessageBox.warning(self, "Aviso", "Informe o nome do relatório!")
            return

        if not camada:
            QMessageBox.warning(self, "Aviso", "Selecione uma camada válida!")
            return

        if not campos_selecionados:
            QMessageBox.warning(self, "Aviso", "Selecione pelo menos um campo para exportar!")
            return

        dados_relatorio = {
            "titulo": titulo,
            "formato": formato,
            "camada": camada,
            "campos": campos_selecionados,
            "escopo": escopo,
            "nome_campo_exp": nome_campo_exp,
            "script_exp": script_exp
        }

        if self.indice_em_edicao is not None:
            self.relatorios[self.indice_em_edicao] = dados_relatorio
            msg = "Relatório atualizado com sucesso!"
        else:
            self.relatorios.append(dados_relatorio)
            msg = "Novo relatório configurado com sucesso!"

        salvar_config_relatorios(self.relatorios)
        self.atualizar_lista()
        self.limpar_formulario()
        QMessageBox.information(self, "Sucesso", msg)

    def remover_relatorio(self):
        row = self.list_widget.currentRow()
        if row >= 0:
            del self.relatorios[row]
            salvar_config_relatorios(self.relatorios)
            self.atualizar_lista()
            self.limpar_formulario()


def abrir_gerenciador_relatorios():
    """Abre a janela de gerenciamento de relatórios."""
    dlg = GerenciadorRelatoriosDialog(iface.mainWindow())
    dlg.exec_()