# scripts/gerar_notificacoes.py

import os
import csv
import re
import locale
from datetime import datetime
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

from qgis.core import QgsProject
from qgis.utils import iface
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QDialogButtonBox, QMessageBox
)

def _limpar_nome_arquivo(texto):
    return re.sub(r'[\\/*?:"<>|]', "-", str(texto))

def _obter_data_por_extenso():
    try:
        locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil.1252')
    except Exception:
        pass
    return datetime.now().strftime('%d de %B de %Y')

def _formatar_cpf_cnpj(documento):
    """
    Remove caracteres não numéricos e formata CPF (11 dígitos) ou CNPJ (14 dígitos).
    Caso o zero inicial tenha sido removido na exportação, completa com zeros à esquerda até 11 dígitos.
    """
    digitos = re.sub(r'\D', '', str(documento if documento is not None else '').strip())
    
    if 0 < len(digitos) < 11:
        digitos = digitos.zfill(11)
        
    if len(digitos) == 11:
        return f"{digitos[:3]}.{digitos[3:6]}.{digitos[6:9]}-{digitos[9:]}"
    elif len(digitos) == 14:
        return f"{digitos[:2]}.{digitos[2:5]}.{digitos[5:8]}/{digitos[8:12]}-{digitos[12:]}"
    
    return digitos

def _substituir_variaveis(texto, context):
    for chave, valor in context.items():
        str_val = str(valor if valor is not None else "")
        texto = texto.replace(f"{{{{ {chave} }}}}", str_val)
        texto = texto.replace(f"{{{{ {chave.lower()} }}}}", str_val)
        texto = texto.replace(f"{{{{ {chave.upper()} }}}}", str_val)
        texto = texto.replace(f"{{{{ {chave.capitalize()} }}}}", str_val)
    return texto

def _processar_paragrafos(paragraphs, context, caminhos_imagens=None):
    for paragraph in paragraphs:
        texto_completo = "".join([run.text for run in paragraph.runs])
        
        # Inserção e centralização de imagens na tag {{ imagens }}
        if "{{ imagens }}" in texto_completo or "{{imagens}}" in texto_completo:
            paragraph.clear()
            if caminhos_imagens:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for idx, img_path in enumerate(caminhos_imagens):
                    if os.path.exists(img_path):
                        run = paragraph.add_run()
                        if idx > 0:
                            run.add_break()  # Adiciona quebra de linha entre as imagens mantendo a centralização
                        run.add_picture(img_path, width=Inches(5.5))
            continue

        novo_texto = _substituir_variaveis(texto_completo, context)
        for run in paragraph.runs:
            run.text = ""
        if paragraph.runs:
            paragraph.runs[0].text = novo_texto
            
def _processar_tabelas(tables, context, caminhos_imagens=None):
    for table in tables:
        for row in table.rows:
            for cell in row.cells:
                _processar_paragrafos(cell.paragraphs, context, caminhos_imagens)
                _processar_tabelas(cell.tables, context, caminhos_imagens)

class NotificacoesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Gerar Notificações em Lote (CSV + PROCESSOS_REURB)")
        self.resize(540, 300)
        self.caminhos_imagens = []
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # 1. Seleção do CSV
        layout.addWidget(QLabel("<b>1. Selecione o arquivo CSV das Notificações:</b>"))
        csv_layout = QHBoxLayout()
        self.txt_csv = QLineEdit()
        self.txt_csv.setPlaceholderText("Caminho para o arquivo .csv...")
        btn_csv = QPushButton("Buscar CSV...")
        btn_csv.clicked.connect(self.selecionar_csv)
        csv_layout.addWidget(self.txt_csv)
        csv_layout.addWidget(btn_csv)
        layout.addLayout(csv_layout)

        # 2. Seleção do Modelo Word (.docx)
        layout.addWidget(QLabel("<b>2. Selecione o Modelo Word (.docx):</b>"))
        doc_layout = QHBoxLayout()
        self.txt_template = QLineEdit()
        
        script_dir = os.path.dirname(__file__)
        padrao_template = os.path.join(script_dir, "modelos", "TEMPLATE_NOTIFICACAO.docx")
        self.txt_template.setText(padrao_template)

        btn_template = QPushButton("Buscar Modelo...")
        btn_template.clicked.connect(self.selecionar_template)
        doc_layout.addWidget(self.txt_template)
        doc_layout.addWidget(btn_template)
        layout.addLayout(doc_layout)

        # 3. Seleção de Imagens Opcionais
        layout.addWidget(QLabel("<b>3. Selecione as Imagens para Anexar (Opcional):</b>"))
        img_layout = QHBoxLayout()
        self.txt_imagens = QLineEdit()
        self.txt_imagens.setPlaceholderText("Nenhuma imagem selecionada...")
        self.txt_imagens.setReadOnly(True)
        btn_imagens = QPushButton("Buscar Imagens...")
        btn_imagens.clicked.connect(self.selecionar_imagens)
        img_layout.addWidget(self.txt_imagens)
        img_layout.addWidget(btn_imagens)
        layout.addLayout(img_layout)

        # Botões
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, parent=self)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selecionar_csv(self):
        caminho, _ = QFileDialog.getOpenFileName(self, "Selecione o arquivo CSV", "", "Arquivos CSV (*.csv);;Todos os arquivos (*.*)")
        if caminho:
            self.txt_csv.setText(caminho)

    def selecionar_template(self):
        caminho, _ = QFileDialog.getOpenFileName(self, "Selecione o Modelo Word", "", "Arquivo Word (*.docx)")
        if caminho:
            self.txt_template.setText(caminho)

    def selecionar_imagens(self):
        caminhos, _ = QFileDialog.getOpenFileNames(
            self, "Selecione as Imagens", "", "Imagens (*.png *.jpg *.jpeg *.bmp)"
        )
        if caminhos:
            self.caminhos_imagens = caminhos
            self.txt_imagens.setText(f"{len(caminhos)} imagem(ns) selecionada(s)")
        else:
            self.caminhos_imagens = []
            self.txt_imagens.setText("Nenhuma imagem selecionada...")

def run():
    # 1. Verifica e extrai dados da feição selecionada em PROCESSOS_REURB
    nome_camada_reurb = "PROCESSOS_REURB"
    camadas_reurb = QgsProject.instance().mapLayersByName(nome_camada_reurb)
    
    if not camadas_reurb:
        QMessageBox.warning(iface.mainWindow(), "Aviso", f"A camada '{nome_camada_reurb}' não foi encontrada no projeto.")
        return

    layer_reurb = camadas_reurb[0]
    feicoes_reurb = list(layer_reurb.selectedFeatures())

    if not feicoes_reurb:
        QMessageBox.warning(iface.mainWindow(), "Seleção Necessária", f"Por favor, selecione a feição do processo na camada '{nome_camada_reurb}' antes de gerar as notificações.")
        return

    feature_reurb = feicoes_reurb[0]

    # 2. Executa a caixa de diálogo
    dlg = NotificacoesDialog(iface.mainWindow())
    if dlg.exec_() != QDialog.Accepted:
        return

    csv_path = dlg.txt_csv.text().strip()
    template_path = dlg.txt_template.text().strip()
    caminhos_imagens = dlg.caminhos_imagens

    if not csv_path or not os.path.exists(csv_path):
        QMessageBox.warning(iface.mainWindow(), "Aviso", "Por favor, selecione um arquivo CSV válido!")
        return

    if not template_path or not os.path.exists(template_path):
        QMessageBox.warning(iface.mainWindow(), "Aviso", f"O arquivo de modelo Word não foi encontrado:\n{template_path}")
        return

    output_folder = r"C:\temp\notificacoes_docx"
    os.makedirs(output_folder, exist_ok=True)

    # 3. Leitura do arquivo CSV
    linhas_csv = []
    encodings = ['utf-8-sig', 'utf-8', 'latin-1', 'cp1252']
    
    for enc in encodings:
        try:
            with open(csv_path, 'r', encoding=enc) as f:
                amostra = f.read(2048)
                f.seek(0)
                delimiter = '|' if '|' in amostra else (';' if ';' in amostra else ',')
                reader = csv.reader(f, delimiter=delimiter)
                linhas_csv = [row for row in reader if row and any(cell.strip() for cell in row)]
                break
        except Exception:
            continue

    if not linhas_csv:
        QMessageBox.warning(iface.mainWindow(), "Erro CSV", "Não foi possível ler os dados do arquivo CSV ou o arquivo está vazio.")
        return

    # 4. Monta o contexto base com os atributos da camada PROCESSOS_REURB
    contexto_base = {
        "data_extenso": _obter_data_por_extenso(),
        "ano": datetime.now().year
    }

    for field in layer_reurb.fields():
        f_name = field.name()
        val = feature_reurb.attribute(f_name)
        str_val = str(val) if val is not None else ""
        contexto_base[f_name] = str_val
        contexto_base[f"{nome_camada_reurb}.{f_name}"] = str_val

    gerados = 0

    # 5. Processa cada linha do CSV combinada com a feição de PROCESSOS_REURB
    for idx, row in enumerate(linhas_csv, start=1):
        context = dict(contexto_base)

        get_val = lambda i: row[i].strip() if len(row) > i and row[i] is not None else ""

        # Mapeamento dos campos do CSV
        raw_cpf_cnpj = get_val(0)                               # Campo 1 (coluna 0)
        context["cpf_cnpj"] = _formatar_cpf_cnpj(raw_cpf_cnpj)  # Formatado como CPF/CNPJ
        context["cpf_cnpj_raw"] = raw_cpf_cnpj                  # Sem formatação
        context["nome"] = get_val(3)                            # Campo 4
        context["cep"] = get_val(4)                             # Campo 5
        context["bairro"] = get_val(5)                          # Campo 6
        context["rua"] = get_val(6)                             # Campo 7
        context["numero"] = get_val(7)                          # Campo 8
        context["contato"] = get_val(9)                         # Campo 10
        context["email"] = get_val(10)                          # Campo 11

        # Mapeamento genérico de colunas do CSV
        for col_i, val in enumerate(row, start=1):
            val_str = val.strip() if val is not None else ""
            context[f"campo{col_i}"] = val_str
            context[f"campo_{col_i}"] = val_str

        # Substituição de variáveis e inserção das imagens centralizadas no Word
        doc = Document(template_path)
        _processar_paragrafos(doc.paragraphs, context, caminhos_imagens)
        _processar_tabelas(doc.tables, context, caminhos_imagens)

        for section in doc.sections:
            _processar_paragrafos(section.header.paragraphs, context, caminhos_imagens)
            _processar_tabelas(section.header.tables, context, caminhos_imagens)
            _processar_paragrafos(section.footer.paragraphs, context, caminhos_imagens)
            _processar_tabelas(section.footer.tables, context, caminhos_imagens)

        nome_contribuinte = context["nome"] if context["nome"] else f"notificacao_{idx}"
        processo_str = context.get("n_processo", context.get("protocolo", ""))
        prefixo_proc = f"{processo_str}_" if processo_str else ""
        
        nome_arquivo = _limpar_nome_arquivo(f"Notificacao_{prefixo_proc}{nome_contribuinte}_{idx}")
        output_path = os.path.join(output_folder, f"{nome_arquivo}.docx")
        
        doc.save(output_path)
        gerados += 1

    QMessageBox.information(iface.mainWindow(), "Sucesso", f"{gerados} notificação(ões) gerada(s) com sucesso na pasta:\n{output_folder}")
    os.startfile(output_folder)