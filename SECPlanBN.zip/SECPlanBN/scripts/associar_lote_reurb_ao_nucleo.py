from qgis.core import QgsProject
from qgis.pyqt.QtWidgets import QMessageBox

# 1. Definição dos nomes exatos das camadas conforme o print
nome_camada_lotes = 'lotes_reurb'
nome_camada_nucleos = 'Núcleo Urbano Informal Consolidado'

# 2. Definição dos campos de ligação conforme o print
campo_origem_id_nucleo = 'id_0'          # Chave primária do núcleo
campo_destino_no_lote = 'nucleo_urbano'  # Chave estrangeira no lote

# 3. Configuração do filtro de atributos (mantendo a lógica anterior)
campo_filtro = 'situação'
valor_filtro = 'IRREGULAR'

# 4. Resgatar as camadas do projeto atual
camada_lotes = QgsProject.instance().mapLayersByName(nome_camada_lotes)
camada_nucleos = QgsProject.instance().mapLayersByName(nome_camada_nucleos)

if not camada_lotes or not camada_nucleos:
    print(f"Erro: Verifique se as camadas '{nome_camada_lotes}' e '{nome_camada_nucleos}' estão abertas no QGIS.")
else:
    layer_lotes = camada_lotes[0]
    layer_nucleos = camada_nucleos[0]

    # Validação para garantir que os campos necessários existem nas camadas
    if layer_lotes.fields().indexFromName(campo_destino_no_lote) == -1:
        print(f"Erro: O campo '{campo_destino_no_lote}' não foi encontrado na camada '{nome_camada_lotes}'.")
    elif layer_nucleos.fields().indexFromName(campo_origem_id_nucleo) == -1:
        print(f"Erro: O campo '{campo_origem_id_nucleo}' não foi encontrado na camada '{nome_camada_nucleos}'.")
    else:
        print(f"Filtrando núcleos onde '{campo_filtro}' é igual a '{valor_filtro}'...")
        
        # Mapeia os núcleos filtrados armazenando o ID do atributo e a Geometria
        nucleos_validos = []
        for f in layer_nucleos.getFeatures():
            if f.attribute(campo_filtro) == valor_filtro:
                if f.geometry() and not f.geometry().isEmpty():
                    id_nucleo = f.attribute(campo_origem_id_nucleo)
                    nucleos_validos.append({
                        'id': id_nucleo,
                        'geom': f.geometry()
                    })

        if not nucleos_validos:
            print(f"Aviso: Nenhum núcleo encontrado com o critério {campo_filtro} = '{valor_filtro}'.")
        else:
            # Dicionário para guardar as alterações {id_do_lote: {indice_do_campo: novo_valor}}
            alteracoes_atributos = {}
            lotes_com_erro_de_area = 0
            lotes_associados = 0
            
            print(f"Analisando sobreposição dos lotes contra {len(nucleos_validos)} núcleo(s) filtrado(s)...")
            idx_campo_destino = layer_lotes.fields().indexFromName(campo_destino_no_lote)

            # Inicia o loop varrendo os lotes
            for lote in layer_lotes.getFeatures():
                geom_lote = lote.geometry()
                
                if geom_lote and not geom_lote.isEmpty():
                    area_total = geom_lote.area()
                    
                    if area_total > 0:
                        # Variáveis para monitorar qual núcleo dá a maior interseção (caso ocorra sobreposição de núcleos)
                        maior_proporcao = 0.0
                        id_nucleo_vencedor = None
                        
                        for nucleo in nucleos_validos:
                            geom_nucleo = nucleo['geom']
                            
                            if geom_lote.intersects(geom_nucleo):
                                intersecao = geom_lote.intersection(geom_nucleo)
                                if intersecao and not intersecao.isEmpty():
                                    proporcao = intersecao.area() / area_total
                                    
                                    # Se a proporção for a maior encontrada para este lote e passar de 90%
                                    if proporcao >= 0.90 and proporcao > maior_proporcao:
                                        maior_proporcao = proporcao
                                        id_nucleo_vencedor = nucleo['id']
                        
                        # Se encontramos um núcleo válido que cobre mais de 90% do lote
                        if id_nucleo_vencedor is not None:
                            alteracoes_atributos[lote.id()] = {idx_campo_destino: id_nucleo_vencedor}
                            lotes_associados += 1
                    else:
                        lotes_com_erro_de_area += 1

            # Bloco de gravação dos dados no banco/shapefile
            if lotes_associados > 0:
                print(f"Processando gravação de {lotes_associados} lote(s)...")
                
                # Abre edição com segurança
                layer_lotes.startEditing()
                
                # Aplica todas as mudanças de uma vez só na tabela de atributos (muito mais rápido)
                layer_lotes.dataProvider().changeAttributeValues(alteracoes_atributos)
                
                # Atualiza a interface do QGIS para mostrar os novos dados na tabela
                layer_lotes.updateFields()
                
                print("Associações prontas na memória!")
                
                # Pergunta visual na tela se deseja salvar as alterações no disco
                resposta = QMessageBox.question(None, "Salvar Alterações", 
                                                f"{lotes_associados} lotes foram associados com sucesso aos seus respectivos núcleos.\nDeseja salvar as alterações na camada '{nome_camada_lotes}' agora?",
                                                QMessageBox.Yes | QMessageBox.No)
                
                if resposta == QMessageBox.Yes:
                    layer_lotes.commitChanges()
                    print("Alterações salvas e gravadas com sucesso no arquivo!")
                else:
                    layer_lotes.rollBack()
                    print("Edições descartadas pelo usuário. Nada foi alterado no arquivo original.")
            else:
                print("Nenhum lote atendeu ao requisito de ter 90% ou mais da área contida nos núcleos filtrados.")
            
            if lotes_com_erro_de_area > 0:
                print(f"Aviso: {lotes_com_erro_de_area} lote(s) ignorado(s) devido a geometria inválida (área zero).")