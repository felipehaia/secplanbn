from qgis.core import *
import os, re, locale
from datetime import datetime
from openpyxl import load_workbook
from PyQt5.QtWidgets import QMessageBox

def run():
    import os
    import re
    import locale
    from qgis.core import QgsProject
    from datetime import datetime
    from openpyxl import load_workbook
    # código original adaptado
    print("Rodando Cadastro Número Endereço...")
    
    # Caminhos
    output_folder = r"C:\temp\lotes_excel"
    os.makedirs(output_folder, exist_ok=True)
    plugin_dir = os.path.dirname(__file__)  # raiz do plugin
    pasta_template = os.path.join(plugin_dir, "modelos")
    template_path = os.path.join(pasta_template, f"modelo_numeros_oficiais.xlsx")

    # Parâmetros
    layer_name = "NUMERO_OFICIAIS"
    
    # Carrega a camada principal
    layers = QgsProject.instance().mapLayersByName(layer_name)
    if not layers:
        QMessageBox.warning(None, "Erro", "Camada '{layer_name}' não encontrada.")
    layer = layers[0]
    
    # Função para substituir variáveis nas células
    def substituir_variaveis_na_planilha(wb, context):
        for sheet in wb.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    if cell.value and isinstance(cell.value, str):
                        for chave, valor in context.items():
                            cell.value = cell.value.replace(f"{{{{{chave}}}}}", str(valor))
        return wb
    
    # Função para limpar o nome do arquivo
    def limpar_nome_arquivo(texto):
        return re.sub(r'[\\/*?:"<>|]', "-", texto)
    
    # Define idioma da localização
    locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil.1252')
    
    # Geração dos arquivos
    if not layer.selectedFeatures():
        QMessageBox.warning(None, "SECPlanBN", "Selecione os elementos para processar o comando.")
    else:
        for feature in layer.selectedFeatures():
            context = {
                "protocolo": feature["protocolo"],
                "bairro": feature["bairro"],
                "numero": feature["numero"],
                "rua": feature["rua"],
                "data": datetime.now().strftime('%d de %B de %Y'),
                "contribuinte": feature["contribuinte"],
            }
    
            # Carrega o modelo
            wb = load_workbook(template_path)
            wb = substituir_variaveis_na_planilha(wb, context)
    
            # Define nome de arquivo
            nome_arquivo = limpar_nome_arquivo(f"{context['protocolo']}_{context['bairro']}_{context['rua']}_n{context['numero']}")
            output_path = os.path.join(output_folder, f"{nome_arquivo}.xlsx")
    
            wb.save(output_path)
            print(f"Planilha criada: {output_path}")
            os.startfile(output_path)
    

