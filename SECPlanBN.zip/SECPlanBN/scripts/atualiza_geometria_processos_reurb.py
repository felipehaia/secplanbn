# scripts/atualiza_geometria_processos_reurb.py

from qgis.core import (
    QgsGeometry,
    QgsProject,
    QgsWkbTypes,
    QgsDataSourceUri,
    QgsFeatureRequest
)
from qgis.PyQt.QtWidgets import QMessageBox


def _obter_coluna_pk(layer):
    """Obtém o nome da coluna chave primária da camada via DataSourceUri ou fallback."""
    uri = QgsDataSourceUri(layer.source())
    key_col = uri.keyColumn()
    if key_col and key_col in [f.name() for f in layer.fields()]:
        return key_col

    nomes_campos = [f.name() for f in layer.fields()]
    for candidato in ["id", "id_0", f"id_{layer.name().lower()}"]:
        if candidato in nomes_campos:
            return candidato
    return None


def _buscar_nucleos_vinculados(camada_processos, feicao_processo):
    """
    Percorre as relações do projeto (Processo -> Tabela Pivô -> Núcleo)
    para retornar a camada de núcleos e as feições vinculadas ao processo.
    """
    rel_manager = QgsProject.instance().relationManager()
    todas_relacoes = rel_manager.relations().values()

    # 1. Encontra relações onde PROCESSOS_REURB é o pai (referencedLayer)
    relacoes_processo = [
        r for r in todas_relacoes
        if r.isValid() and r.referencedLayerId() == camada_processos.id()
    ]

    for rel_pai in relacoes_processo:
        camada_pivo = rel_pai.referencingLayer()
        if not camada_pivo:
            continue

        # 2. Encontra a outra relação que aponta para a mesma tabela pivô (Núcleo -> Pivô)
        outras_relacoes = [
            r for r in todas_relacoes
            if r.isValid()
            and r.referencingLayerId() == camada_pivo.id()
            and r.id() != rel_pai.id()
        ]

        for rel_outro_pai in outras_relacoes:
            camada_destino = rel_outro_pai.referencedLayer()
            if not camada_destino:
                continue

            # Filtra pela pivô que liga processos a núcleos
            nome_pivo = camada_pivo.name().lower()
            nome_dest = camada_destino.name().lower()
            if "nucleo" in nome_pivo or "nucleo" in nome_dest or "núcleo" in nome_dest:
                nucleos = []
                for feat_pivo in rel_pai.getRelatedFeatures(feicao_processo):
                    feat_nucleo = rel_outro_pai.getReferencedFeature(feat_pivo)
                    if feat_nucleo.isValid():
                        nucleos.append(feat_nucleo)
                return camada_destino, nucleos

    return None, []


def atualizar_geometria_processo_por_vinculos(camada_processos, feat_id, parent_widget=None):
    """
    Atualiza a geometria de uma feição de PROCESSOS_REURB fazendo a união (unaryUnion)
    de todos os lotes em 'lotes_reurb' vinculados aos núcleos associados ao processo.
    """
    if not camada_processos:
        QMessageBox.warning(parent_widget, "Erro", "Camada 'PROCESSOS_REURB' inválida.")
        return False

    feicao_alvo = camada_processos.getFeature(feat_id)
    if not feicao_alvo.isValid():
        QMessageBox.warning(parent_widget, "Erro", "Feição do processo não encontrada.")
        return False

    camadas_lotes = QgsProject.instance().mapLayersByName("lotes_reurb")
    if not camadas_lotes:
        QMessageBox.warning(parent_widget, "Erro", "Camada 'lotes_reurb' não encontrada no projeto.")
        return False
    camada_lotes = camadas_lotes[0]

    # 1. Busca os núcleos vinculados ao processo via tabela pivô
    camada_nucleos, nucleos_vinculados = _buscar_nucleos_vinculados(camada_processos, feicao_alvo)
    if not camada_nucleos:
        QMessageBox.warning(
            parent_widget,
            "Relação não encontrada",
            "Não foi possível localizar a relação N:M entre 'PROCESSOS_REURB' e os Núcleos no projeto QGIS."
        )
        return False

    if not nucleos_vinculados:
        QMessageBox.information(
            parent_widget,
            "Sem vínculos",
            "Este processo não possui nenhum Núcleo Urbano Informal vinculado."
        )
        return False

    # 2. Obtém as PKs dos núcleos vinculados
    pk_nucleo_col = _obter_coluna_pk(camada_nucleos)
    if not pk_nucleo_col:
        QMessageBox.warning(
            parent_widget,
            "Erro de Esquema",
            f"Não foi possível identificar a chave primária da camada '{camada_nucleos.name()}'."
        )
        return False

    ids_nucleos = [
        f[pk_nucleo_col] for f in nucleos_vinculados
        if f[pk_nucleo_col] is not None
    ]

    if not ids_nucleos:
        QMessageBox.warning(
            parent_widget,
            "Chave Primária Pendente",
            "Os núcleos vinculados ainda não possuem chave primária salva no banco. Salve as edições dos núcleos primeiro."
        )
        return False

    # 3. Busca os lotes vinculados a esses núcleos via campo 'nucleo_urbano'
    if "nucleo_urbano" not in [f.name() for f in camada_lotes.fields()]:
        QMessageBox.warning(
            parent_widget,
            "Campo não encontrado",
            "A camada 'lotes_reurb' não possui o campo 'nucleo_urbano'."
        )
        return False

    # Monta expressão de filtro segura para os IDs encontrados
    valores_formatados = ", ".join(
        f"'{v}'" if isinstance(v, str) else str(v) for v in ids_nucleos
    )
    expressao = f'"nucleo_urbano" IN ({valores_formatados})'
    request = QgsFeatureRequest().setFilterExpression(expressao)

    geometrias_lotes = [
        f.geometry() for f in camada_lotes.getFeatures(request)
        if f.hasGeometry() and not f.geometry().isEmpty()
    ]

    if not geometrias_lotes:
        QMessageBox.information(
            parent_widget,
            "Nenhum Lote Encontrado",
            "Não há lotes com geometria válida vinculados aos núcleos deste processo."
        )
        return False

    # 4. Une as geometrias e garante compatibilidade MultiPolígono
    geometria_unida = QgsGeometry.unaryUnion(geometrias_lotes)
    if not geometria_unida or geometria_unida.isEmpty():
        QMessageBox.warning(parent_widget, "Erro Geométrico", "Falha ao calcular a união das geometrias dos lotes.")
        return False

    if QgsWkbTypes.isMultiType(camada_processos.wkbType()) and not geometria_unida.isMultipart():
        geometria_unida.convertToMultiType()

    # 5. Aplica a nova geometria na camada PROCESSOS_REURB
    ja_estava_editando = camada_processos.isEditable()
    if not ja_estava_editando:
        camada_processos.startEditing()

    sucesso = camada_processos.changeGeometry(feicao_alvo.id(), geometria_unida)
    if not sucesso:
        QMessageBox.warning(parent_widget, "Erro", "Não foi possível alterar a geometria da feição do processo.")
        return False

    camada_processos.triggerRepaint()

    # 6. Confirmação de salvamento (se a camada não estava previamente aberta em edição)
    if not ja_estava_editando:
        resp = QMessageBox.question(
            parent_widget,
            "Geometria Atualizada",
            f"Geometria atualizada a partir da união de {len(geometrias_lotes)} lote(s) vinculado(s).\n\n"
            "Deseja salvar as alterações na camada PROCESSOS_REURB agora?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )
        if resp == QMessageBox.Yes:
            if not camada_processos.commitChanges():
                QMessageBox.warning(
                    parent_widget,
                    "Erro ao Salvar",
                    f"A geometria foi atualizada no mapa, mas houve erro ao salvar no banco:\n{camada_processos.commitErrors()}"
                )
    else:
        QMessageBox.information(
            parent_widget,
            "Geometria Atualizada",
            f"Geometria atualizada a partir de {len(geometrias_lotes)} lote(s).\n"
            "A camada permanece em modo de edição para você salvar quando desejar."
        )

    return True