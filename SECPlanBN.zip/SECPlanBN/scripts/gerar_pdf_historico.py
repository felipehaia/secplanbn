import os
import json
from datetime import datetime, date
import matplotlib.pyplot as plt

from qgis.core import QgsProject
from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox
from qgis.PyQt.QtCore import QDateTime, QDate

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

# ==========================================
# LISTA DE ETAPAS PADRONIZADAS E ORDENADAS
# ==========================================
ETAPAS_ORDENADAS = [
    "INDEFERIDO",
    "VISTORIA",
    "VIABILIDADE",
    "PROJETO",
    "EDITAL",
    "CRF",
    "RETORNO CARTÓRIO",
    "CONCLUÍDO"
]

# ==========================================
# HELPERS DE CONVERSÃO E LIMPEZA
# ==========================================
def tratar_data(val_data):
    """Converte qualquer tipo de data retornado pelo QGIS para um objeto datetime.date do Python."""
    if isinstance(val_data, QDateTime):
        return val_data.toPyDateTime().date()
    elif isinstance(val_data, QDate):
        return val_data.toPyDate()
    elif isinstance(val_data, datetime):
        return val_data.date()
    elif isinstance(val_data, date):
        return val_data
    elif isinstance(val_data, str) and val_data.strip():
        return datetime.strptime(val_data[:10], '%Y-%m-%d').date()
    
    raise ValueError(f"Formato de data desconhecido: {type(val_data)} -> {val_data}")

def parse_json(valor):
    """Garante a conversão e limpa aspas internas dos nomes de chaves do JSON."""
    dados_brutos = {}
    if isinstance(valor, dict):
        dados_brutos = valor
    elif isinstance(valor, str) and valor.strip():
        try:
            dados_brutos = json.loads(valor)
        except Exception:
            dados_brutos = {}

    dados_limpos = {}
    for k, v in dados_brutos.items():
        chave_limpa = str(k).replace('"', '').strip() if k else "NÃO INFORMADO"
        dados_limpos[chave_limpa] = v

    return dados_limpos

def calcular_processos_ativos(por_etapa):
    """Calcula total de processos ativos excluindo INDEFERIDO e CONCLUÍDO."""
    total_inativos = por_etapa.get("INDEFERIDO", 0) + por_etapa.get("CONCLUÍDO", 0)
    total_geral = sum(por_etapa.values()) if por_etapa else 0
    return max(0, total_geral - total_inativos)

def formatar_detalhado_cuidados(etapa_nome, dict_detalhado):
    """Extrai os totais por 'aos_cuidados' para uma etapa específica, ignorando INDEFERIDO e CONCLUÍDO."""
    if etapa_nome in ["INDEFERIDO", "CONCLUÍDO"]:
        return "-"

    resultado = []
    prefixo = f"{etapa_nome} | "
    
    for chave, total in dict_detalhado.items():
        if chave.startswith(prefixo):
            cuidados_nome = chave.replace(prefixo, '').strip()
            resultado.append(f"<b>{cuidados_nome}:</b> {total}")
        elif " | " in chave:
            partes = chave.split(" | ")
            if len(partes) == 2 and partes[0].strip() == etapa_nome:
                resultado.append(f"<b>{partes[1].strip()}:</b> {total}")
                
    if not resultado:
        return "-"
    return "<br/>".join(resultado)

# ==========================================
# 1. OBTER DADOS DA CAMADA DO QGIS
# ==========================================
def buscar_dados_da_camada(id_snapshot_escolhido=None):
    camadas = QgsProject.instance().mapLayersByName('historico_processos_reurb')
    
    if not camadas:
        raise ValueError("A camada 'historico_processos_reurb' não foi encontrada no painel de camadas do QGIS.")
    
    layer = camadas[0]
    features = list(layer.getFeatures())
    
    if not features:
        raise ValueError("A camada 'historico_processos_reurb' não contém registros.")

    # 1. Buscar o snapshot de referência
    feat_atual = None
    if id_snapshot_escolhido is None:
        # Pega automaticamente a feição com a data de snapshot mais recente
        feat_atual = max(features, key=lambda f: tratar_data(f['data_snapshot']))
    else:
        # Busca pelo ID específico
        for f in features:
            if f['id'] == id_snapshot_escolhido:
                feat_atual = f
                break

    if not feat_atual:
        raise ValueError(f"Snapshot ID {id_snapshot_escolhido} não foi encontrado na camada.")

    data_atual = tratar_data(feat_atual['data_snapshot'])

    atual = {
        'id': feat_atual['id'],
        'data_snapshot': data_atual,
        'semana_ano': feat_atual['semana_ano'],
        'total_processos': feat_atual['total_processos'],
        'por_etapa': parse_json(feat_atual['por_etapa']),
        'por_aos_cuidados': parse_json(feat_atual['por_aos_cuidados']),
        'por_responsavel_empresa': parse_json(feat_atual['por_responsavel_empresa']),
        'detalhado_etapa_cuidados': parse_json(feat_atual.attribute('detalhado_etapa_cuidados') if 'detalhado_etapa_cuidados' in feat_atual.fields().names() else {})
    }

    # 2. Buscar o snapshot de ~1 mês atrás em relação à data atual identificada
    feat_mes_anterior = None
    menor_diferenca = None

    for f in features:
        dt_f = tratar_data(f['data_snapshot'])
        dias_atras = (data_atual - dt_f).days
        
        if dias_atras >= 20:
            diferenca_meta = abs(dias_atras - 30)
            if menor_diferenca is None or diferenca_meta < menor_diferenca:
                menor_diferenca = diferenca_meta
                feat_mes_anterior = f

    mes_anterior = None
    if feat_mes_anterior:
        dt_p = tratar_data(feat_mes_anterior['data_snapshot'])
        mes_anterior = {
            'id': feat_mes_anterior['id'],
            'data_snapshot': dt_p,
            'semana_ano': feat_mes_anterior['semana_ano'],
            'total_processos': feat_mes_anterior['total_processos'],
            'por_etapa': parse_json(feat_mes_anterior['por_etapa']),
            'por_aos_cuidados': parse_json(feat_mes_anterior['por_aos_cuidados']),
            'por_responsavel_empresa': parse_json(feat_mes_anterior['por_responsavel_empresa'])
        }

    # 3. Lista para o gráfico de evolução
    dados_grafico = []
    for f in features:
        dt_f = tratar_data(f['data_snapshot'])
        dias_atras = (data_atual - dt_f).days
        
        if 0 <= dias_atras <= 365:
            etapas_f = parse_json(f['por_etapa'])
            ativos_f = calcular_processos_ativos(etapas_f)
            dados_grafico.append((dt_f, f['semana_ano'], f['total_processos'], ativos_f))

    dados_grafico.sort(key=lambda x: x[0])

    return atual, mes_anterior, dados_grafico

# ==========================================
# 2. GERAÇÃO DOS GRÁFICOS (MATPLOTLIB)
# ==========================================
def gerar_grafico_evolucao(dados_grafico, filename="grafico_evolucao_temp.png"):
    semanas = [row[1] for row in dados_grafico]
    totais = [row[2] for row in dados_grafico]
    ativos = [row[3] for row in dados_grafico]

    plt.figure(figsize=(8, 3.5))
    plt.plot(semanas, totais, marker='o', color='#1a5276', linewidth=2, markersize=4, label='Total de Processos')
    plt.plot(semanas, ativos, marker='s', color='#27ae60', linewidth=2, markersize=4, linestyle='--', label='Processos Ativos (excl. Indeferidos/Concluídos)')

    plt.title("Evolução do Total e Processos Ativos", fontsize=11, fontweight='bold', pad=10)
    plt.xlabel("Semana/Ano", fontsize=9)
    plt.ylabel("Qtd. de Processos", fontsize=9)
    plt.xticks(rotation=45, fontsize=8)
    plt.yticks(fontsize=8)
    plt.legend(fontsize=8, loc='upper left')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(filename, dpi=200)
    plt.close()
    return filename

def gerar_grafico_aos_cuidados(cuidados_atual, cuidados_anterior, filename="grafico_cuidados_temp.png"):
    import numpy as np

    todas_chaves = sorted(list(set(list(cuidados_atual.keys()) + list(cuidados_anterior.keys()))))
    
    val_atual = [cuidados_atual.get(k, 0) for k in todas_chaves]
    val_anterior = [cuidados_anterior.get(k, 0) for k in todas_chaves]

    x = np.arange(len(todas_chaves))
    largura = 0.35

    plt.figure(figsize=(8, 3.5))
    plt.bar(x - largura/2, val_anterior, largura, label='Mês Anterior', color='#aeb6bf')
    plt.bar(x + largura/2, val_atual, largura, label='Atual', color='#2e4053')

    plt.title("Comparativo de Processos por 'Aos Cuidados'", fontsize=11, fontweight='bold', pad=10)
    plt.xlabel("Aos Cuidados De", fontsize=9)
    plt.ylabel("Qtd. de Processos", fontsize=9)
    plt.xticks(x, todas_chaves, rotation=30, ha='right', fontsize=8)
    plt.yticks(fontsize=8)
    plt.legend(fontsize=8)
    plt.grid(axis='y', linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(filename, dpi=200)
    plt.close()
    return filename

# ==========================================
# 3. GERAR O RELATÓRIO PDF (REPORTLAB)
# ==========================================
def gerar_relatorio_pdf(id_snapshot_escolhido=None):
    caminho_pdf, _ = QFileDialog.getSaveFileName(
        None,
        "Salvar Relatório REURB em PDF",
        "Relatorio_REURB_Comparativo.pdf",
        "Arquivos PDF (*.pdf)"
    )

    if not caminho_pdf:
        print("Exportação cancelada.")
        return

    atual, mes_anterior, dados_grafico = buscar_dados_da_camada(id_snapshot_escolhido)

    data_atual_str = atual['data_snapshot'].strftime('%d/%m/%Y')
    ativos_atual = calcular_processos_ativos(atual['por_etapa'])
    
    if mes_anterior:
        semana_anterior = mes_anterior['semana_ano']
        data_anterior_str = mes_anterior['data_snapshot'].strftime('%d/%m/%Y')
        total_anterior = mes_anterior['total_processos']
        etapa_anterior = mes_anterior['por_etapa']
        cuidados_anterior = mes_anterior['por_aos_cuidados']
        ativos_anterior = calcular_processos_ativos(etapa_anterior)
    else:
        semana_anterior = "N/A (Sem dados do mês anterior)"
        data_anterior_str = "N/A"
        total_anterior = 0
        etapa_anterior = {}
        cuidados_anterior = {}
        ativos_anterior = 0

    doc = SimpleDocTemplate(
        caminho_pdf,
        pagesize=A4,
        rightMargin=1.5*cm, leftMargin=1.5*cm,
        topMargin=1.5*cm, bottomMargin=1.5*cm
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('DocTitle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor('#1a5276'), spaceAfter=4, fontName='Helvetica-Bold')
    subtitle_style = ParagraphStyle('DocSubtitle', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#566573'), spaceAfter=15)
    section_style = ParagraphStyle('SectionHeader', parent=styles['Heading2'], fontSize=12, textColor=colors.HexColor('#1a5276'), spaceBefore=10, spaceAfter=6, fontName='Helvetica-Bold')
    cell_style = ParagraphStyle('Cell', parent=styles['Normal'], fontSize=9)
    cell_bold = ParagraphStyle('CellB', parent=styles['Normal'], fontSize=9, fontName='Helvetica-Bold')

    elements = []

    # Cabeçalho
    elements.append(Paragraph("Prefeitura Municipal - Relatório de Desempenho REURB", title_style))
    elements.append(Paragraph(f"<b>Snapshot de Referência:</b> {atual['semana_ano']} ({data_atual_str}) | <b>Comparativo Mês Anterior:</b> {semana_anterior} ({data_anterior_str})", subtitle_style))
    elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#1a5276'), spaceAfter=15))

    # 1. Resumo Geral
    elements.append(Paragraph("1. Resumo do Volume Geral", section_style))
    var_total = atual['total_processos'] - total_anterior
    var_tot_str = f"+{var_total}" if var_total >= 0 else str(var_total)

    var_ativos = ativos_atual - ativos_anterior
    var_ati_str = f"+{var_ativos}" if var_ativos >= 0 else str(var_ativos)

    dados_resumo = [
        [Paragraph('Métrica', cell_bold), Paragraph('Atual', cell_bold), Paragraph('Mês Anterior', cell_bold), Paragraph('Diferença', cell_bold)],
        [Paragraph('Total de Processos', cell_style), str(atual['total_processos']), str(total_anterior), var_tot_str],
        [Paragraph('Processos Ativos (excl. Indef./Concl.)', cell_style), str(ativos_atual), str(ativos_anterior), var_ati_str]
    ]

    t_resumo = Table(dados_resumo, colWidths=[6.5*cm, 3.5*cm, 3.5*cm, 4.5*cm])
    t_resumo.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#eaeded')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.HexColor('#1a5276')),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#bdc3c7')),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING', (0,0), (-1,-1), 6),
    ]))
    elements.append(t_resumo)
    elements.append(Spacer(1, 15))

    # 2. Gráfico de Evolução
    if dados_grafico:
        elements.append(Paragraph("2. Evolução Histórica de Processos", section_style))
        img_evolucao = gerar_grafico_evolucao(dados_grafico)
        elements.append(Image(img_evolucao, width=17*cm, height=6.8*cm))
        elements.append(Spacer(1, 15))

    # 3. Tabela e Gráfico "Aos Cuidados"
    elements.append(Paragraph("3. Distribuição e Comparativo: 'Aos Cuidados'", section_style))
    
    img_cuidados = gerar_grafico_aos_cuidados(atual['por_aos_cuidados'], cuidados_anterior)
    elements.append(Image(img_cuidados, width=17*cm, height=7.4*cm))
    elements.append(Spacer(1, 10))

    todas_opcoes_cuidados = sorted(list(set(list(atual['por_aos_cuidados'].keys()) + list(cuidados_anterior.keys()))))
    dados_cuidados = [[Paragraph('Aos Cuidados De', cell_bold), Paragraph('Qtd. Atual', cell_bold), Paragraph('Qtd. Mês Anterior', cell_bold), Paragraph('Diferença', cell_bold)]]

    for c in todas_opcoes_cuidados:
        q_at = atual['por_aos_cuidados'].get(c, 0)
        q_pas = cuidados_anterior.get(c, 0)
        diff = q_at - q_pas
        diff_str = f"+{diff}" if diff >= 0 else str(diff)
        dados_cuidados.append([Paragraph(c, cell_style), str(q_at), str(q_pas), diff_str])

    t_cuidados = Table(dados_cuidados, colWidths=[7*cm, 3.5*cm, 3.5*cm, 4*cm])
    t_cuidados.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#2e4053')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#bdc3c7')),
        ('ALIGN', (1,0), (-1,-1), 'CENTER'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
    ]))
    elements.append(t_cuidados)
    elements.append(Spacer(1, 15))

    # 4. Tabela por Etapa
    elements.append(Paragraph("4. Detalhamento por Etapa e Responsável (Aos Cuidados)", section_style))
    
    dados_etapa = [[
        Paragraph('Etapa', cell_bold),
        Paragraph('Qtd. Atual', cell_bold),
        Paragraph('Qtd. Mês Ant.', cell_bold),
        Paragraph('Diferença', cell_bold),
        Paragraph('Aos Cuidados (Detalhamento Atual)', cell_bold)
    ]]

    etapas_no_banco = set(list(atual['por_etapa'].keys()) + list(etapa_anterior.keys()))
    todas_etapas = list(ETAPAS_ORDENADAS)
    for e in etapas_no_banco:
        if e not in todas_etapas:
            todas_etapas.append(e)

    for idx, e in enumerate(todas_etapas):
        q_at = atual['por_etapa'].get(e, 0)
        q_pas = etapa_anterior.get(e, 0)
        diff = q_at - q_pas
        diff_str = f"+{diff}" if diff >= 0 else str(diff)
        
        nome_exibicao = f"{idx + 1} - {e}" if idx < len(ETAPAS_ORDENADAS) else e
        
        # Formatar detalhamento de aos_cuidados (retorna '-' se for INDEFERIDO ou CONCLUÍDO)
        txt_cuidados_etapa = formatar_detalhado_cuidados(e, atual['detalhado_etapa_cuidados'])

        dados_etapa.append([
            Paragraph(nome_exibicao, cell_style),
            str(q_at),
            str(q_pas),
            diff_str,
            Paragraph(txt_cuidados_etapa, cell_style)
        ])

    t_etapa = Table(dados_etapa, colWidths=[4.5*cm, 2.2*cm, 2.3*cm, 2.2*cm, 6.8*cm])
    t_etapa.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1a5276')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#bdc3c7')),
        ('ALIGN', (1,0), (3,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
    ]))
    elements.append(t_etapa)

    # Construir PDF tratando arquivo aberto
    try:
        doc.build(elements)
    except PermissionError:
        QMessageBox.warning(
            None, 
            "Arquivo Aberto", 
            f"O arquivo PDF está aberto em outro programa!\n\nFeche o arquivo '{caminho_pdf}' e tente novamente."
        )
        for temp_file in ["grafico_evolucao_temp.png", "grafico_cuidados_temp.png"]:
            if os.path.exists(temp_file):
                os.remove(temp_file)
        return

    # Limpar imagens temporárias
    for temp_file in ["grafico_evolucao_temp.png", "grafico_cuidados_temp.png"]:
        if os.path.exists(temp_file):
            os.remove(temp_file)

    QMessageBox.information(None, "Sucesso", f"Relatório gerado com sucesso!\n\nSalvo em:\n{caminho_pdf}")

# Executa para o snapshot mais recente automaticamente (id_snapshot_escolhido=None)
# Se quiser um ID específico no futuro, basta passar como número: gerar_relatorio_pdf(id_snapshot_escolhido=3)
gerar_relatorio_pdf(id_snapshot_escolhido=None)