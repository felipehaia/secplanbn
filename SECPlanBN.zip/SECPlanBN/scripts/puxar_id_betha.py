from qgis.core import *
from PyQt5.QtWidgets import *
from qgis.PyQt.QtCore import QVariant, Qt
from PyQt5.QtWidgets import QMessageBox


def run():
    from qgis.PyQt.QtCore import QVariant
    from qgis.PyQt.QtWidgets import QProgressDialog
    from qgis.utils import iface
    
    # Camada ativa
    layer = iface.activeLayer()
    
    if not layer:
        QMessageBox.warning(None, "SECPlanBN", "Nenhuma camada ativa encontrada")
    
    # Verifica se tem elementos selecionados
    selecionados = layer.selectedFeatures()
    if not selecionados:
        QMessageBox.warning(None, "SECPlanBN", "Selecione antes os elementos que deseja atualizar.")
    
    # Garante que o campo id_betha exista
    campos = [field.name() for field in layer.fields()]
    if 'id_betha' not in campos:
        layer.dataProvider().addAttributes([QgsField('id_betha', QVariant.String)])
        layer.updateFields()
    
    # Função para extrair apenas os 4 primeiros blocos do cadastro
    def extrair_base_cadastro(cadastro):
        partes = str(cadastro).strip().split('.')
        if len(partes) >= 4:
            return '.'.join(partes[:4])
        return str(cadastro)
    
    # Monta dicionário de imóveis (camada "imóveis")
    try:
        imoveis = QgsProject.instance().mapLayersByName('imoveis')[0]
    except:
        QMessageBox.warning(None, "SECPlanBN", "Adicione o arquivo CSV exportado da Betha para as camadas do Qgis com o nome imoveis.")
    dic_imoveis = {}
    for feat in imoveis.getFeatures():
        raw_cadastro = feat['Inscricao Imobiliaria']
        id_betha = feat['Codigo Imovel']
        if raw_cadastro:
            chave = extrair_base_cadastro(raw_cadastro)
            dic_imoveis[chave] = id_betha
    
    # Cria janela de progresso
    progress = QProgressDialog("Atualizando feições selecionadas...", "Cancelar", 0, len(selecionados))
    progress.setWindowTitle("Processando")
    progress.setWindowModality(Qt.WindowModal)
    progress.show()
    
    # Atualiza apenas selecionados da camada ativa
    with edit(layer):
        for i, feat in enumerate(selecionados, 1):
            if progress.wasCanceled():
                break
            raw_cadastro = feat['cadastro']
            if raw_cadastro:
                chave = extrair_base_cadastro(raw_cadastro)
                if chave in dic_imoveis:
                    feat['id_betha'] = dic_imoveis[chave]
                    layer.updateFeature(feat)
            progress.setValue(i)
    
    progress.close()
    print(f"{len(selecionados)} feições processadas na camada {layer.name()}.")

