from qgis.core import QgsProject

# 1. Definição dos nomes das camadas
nome_camada_lotes = 'LOTES-BASE-PLANEJAMENTO'
nome_camada_nucleos = 'IDENTIFICAÇÃO-PARCELAMENTOS'

# 2. Configuração do filtro de atributos para a camada de parcelamentos
campo_filtro = 'vistoriado'       # Nome da coluna/campo na tabela de atributos
valor_filtro = True     # Valor exato que você deseja filtrar

# 3. Resgatar as camadas do projeto atual
camada_lotes = QgsProject.instance().mapLayersByName(nome_camada_lotes)
camada_nucleos = QgsProject.instance().mapLayersByName(nome_camada_nucleos)

if not camada_lotes or not camada_nucleos:
    print(f"Erro: Verifique se as camadas '{nome_camada_lotes}' e '{nome_camada_nucleos}' estão abertas no QGIS.")
else:
    layer_lotes = camada_lotes[0]
    layer_nucleos = camada_nucleos[0]

    print(f"Filtrando parcelamentos onde o campo '{campo_filtro}' é igual a '{valor_filtro}'...")
    
    # Coleta as geometrias apenas dos parcelamentos que passam no filtro de atributo
    geometrias_nucleos = []
    for f in layer_nucleos.getFeatures():
        if f.attribute(campo_filtro) == valor_filtro:
            if f.geometry() and not f.geometry().isEmpty():
                geometrias_nucleos.append(f.geometry())

    if not geometrias_nucleos:
        print(f"Aviso: Nenhum objeto foi encontrado com o critério {campo_filtro} = '{valor_filtro}'.")
    else:
        ids_para_selecionar = []
        lotes_com_erro_de_area = 0
        
        print(f"Analisando a sobreposição dos lotes contra {len(geometrias_nucleos)} polígono(s) filtrado(s)...")
        
        # Loop para checar cada lote
        for lote in layer_lotes.getFeatures():
            geom_lote = lote.geometry()
            
            if geom_lote and not geom_lote.isEmpty():
                area_total = geom_lote.area()
                
                # PROTEÇÃO: Só avança se a área for maior que zero (evita o ZeroDivisionError)
                if area_total > 0:
                    area_intersecao_acumulada = 0.0
                    
                    # Testando o lote contra cada polígono de parcelamento filtrado
                    for geom_nucleo in geometrias_nucleos:
                        if geom_lote.intersects(geom_nucleo):
                            intersecao = geom_lote.intersection(geom_nucleo)
                            if intersecao and not intersecao.isEmpty():
                                area_intersecao_acumulada += intersecao.area()
                    
                    # Calcula a proporção com segurança
                    proporcao = area_intersecao_acumulada / area_total
                    
                    if proporcao >= 0.90:
                        ids_para_selecionar.append(lote.id())
                else:
                    lotes_com_erro_de_area += 1

        # Aplica a seleção de ID's na camada de lotes
        layer_lotes.selectByIds(ids_para_selecionar)
        
        print(f"Sucesso! {len(ids_para_selecionar)} lotes foram selecionados.")
        if lotes_com_erro_de_area > 0:
            print(f"Aviso: {lotes_com_erro_de_area} lote(s) foram ignorados por possuírem área igual a zero (geometria inválida).")