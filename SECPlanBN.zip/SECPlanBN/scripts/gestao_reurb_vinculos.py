import unicodedata

from qgis.core import (
    Qgis,
    QgsAttributeEditorContainer,
    QgsAttributeEditorField,
    QgsDataSourceUri,
    QgsCoordinateTransform,
    QgsDefaultValue,
    QgsEditFormConfig,
    QgsExpression,
    QgsFeature,
    QgsProject,
    QgsVectorLayer,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)
from qgis.gui import QgsAttributeEditorContext
from qgis.utils import iface


class GerenciadorVinculosReurb:
    def __init__(self, parent_dialog, process_layer):
        self.parent_dialog = parent_dialog
        self.process_layer = process_layer
        self._pending_digitizing = None

    def criar_menu(self):
        from qgis.PyQt.QtWidgets import QMenu

        menu = QMenu(self.parent_dialog)

        menu_nucleos = menu.addMenu("Núcleos")
        menu_nucleos.addAction("Mostrar núcleos do processo", self.mostrar_nucleos)
        menu_nucleos.addAction("Vincular núcleo existente...", self.vincular_nucleo_existente)
        menu_nucleos.addAction("Desenhar novo núcleo...", self.adicionar_nucleo)

        menu_lotes = menu.addMenu("Lotes")
        menu_lotes.addAction("Mostrar lotes...", self.mostrar_lotes)
        menu_lotes.addAction("Vincular lote existente...", self.vincular_lote_existente)
        menu_lotes.addAction("Desenhar novo lote...", self.adicionar_lote)

        menu_legitimados = menu.addMenu("Legitimados")
        menu_legitimados.addAction("Mostrar Legitimados de um lote...", self.mostrar_legitimados)
        menu_legitimados.addAction("Vincular Legitimados a um lote...", self.vincular_legitimado_existente)
        menu_legitimados.addAction("Cadastrar Legitimado a um lote...", self.adicionar_legitimado)
        return menu

    def cancelar_digitizacao_pendente(self):
        if self._pending_digitizing:
            self._finalizar_digitizacao()

    def _mensagem(self, texto, nivel=None):
        from qgis.core import Qgis

        iface.messageBar().pushMessage(
            "Gestão REURB",
            texto,
            level=nivel if nivel is not None else Qgis.Info,
            duration=8,
        )

    def _registrar_camadas_alteradas(self, layers):
        if self._pending_digitizing:
            afetadas = self._pending_digitizing["affected_layers"]
            ids_afetados = {layer.id() for layer in afetadas}
            for layer in layers:
                if layer.id() not in ids_afetados:
                    afetadas.append(layer)
                    ids_afetados.add(layer.id())
            return
        self._perguntar_destino_edicoes(layers)

    def _perguntar_destino_edicoes(self, layers):
        editaveis = []
        ids_vistos = set()
        for layer in layers:
            if layer and layer.id() not in ids_vistos and layer.isEditable():
                editaveis.append(layer)
                ids_vistos.add(layer.id())
        if not editaveis:
            return

        nomes = "\n".join(f"• {layer.name()}" for layer in editaveis)
        box = QMessageBox(self.parent_dialog)
        box.setIcon(QMessageBox.Question)
        box.setWindowTitle("Finalizar alterações REURB")
        box.setText(
            "Deseja salvar ou descartar as alterações feitas nestas camadas?\n\n"
            f"{nomes}\n\n"
            "A decisão vale para todo o buffer de edição dessas camadas, inclusive "
            "alterações anteriores que ainda não tenham sido salvas."
        )
        btn_salvar = box.addButton("Salvar alterações", QMessageBox.AcceptRole)
        btn_descartar = box.addButton("Descartar alterações", QMessageBox.DestructiveRole)
        box.setDefaultButton(btn_salvar)
        box.setEscapeButton(btn_salvar)
        box.exec_()

        if box.clickedButton() == btn_descartar:
            falhas = []
            for layer in editaveis:
                if not layer.rollBack():
                    falhas.append(layer.name())
            if falhas:
                QMessageBox.warning(
                    self.parent_dialog,
                    "Descarte incompleto",
                    "Não foi possível encerrar a edição de: " + ", ".join(falhas),
                )
            else:
                self._mensagem("Alterações descartadas; as camadas saíram do modo de edição.")
            return

        falhas = []
        for layer in editaveis:
            if not layer.commitChanges():
                erros = layer.commitErrors()
                falhas.append(f"{layer.name()}: {'; '.join(erros)}")
        if falhas:
            QMessageBox.warning(
                self.parent_dialog,
                "Falha ao salvar",
                "Uma ou mais camadas não foram salvas e podem continuar em edição. "
                "Verifique os erros e conclua a edição no QGIS:\n\n" + "\n".join(falhas),
            )
        else:
            self._mensagem("Alterações salvas; as camadas saíram do modo de edição.")

    def _processo_selecionado(self):
        selecionadas = self.process_layer.selectedFeatures()
        if len(selecionadas) != 1:
            QMessageBox.warning(
                self.parent_dialog,
                "Selecione um processo",
                "Selecione exatamente um processo REURB na tabela antes de gerenciar os vínculos.",
            )
            return None
        return selecionadas[0]

    @staticmethod
    def _nome_tabela(layer):
        if not layer:
            return ""
        if layer.providerType() == "postgres":
            uri = QgsDataSourceUri(layer.source())
            if uri.table():
                return uri.table().lower()
        return layer.name().lower()

    def _buscar_camada(self, nome_tabela, aliases=()):
        project = QgsProject.instance()
        layers = [
            layer for layer in project.mapLayers().values()
            if isinstance(layer, QgsVectorLayer)
        ]
        for layer in layers:
            if self._nome_tabela(layer) == nome_tabela.lower():
                return layer
        for alias in aliases:
            matches = project.mapLayersByName(alias)
            for layer in matches:
                if isinstance(layer, QgsVectorLayer):
                    return layer
        return None

    def _camada_nucleos(self):
        return self._buscar_camada(
            "nucleos_urbanos_informais",
            ("Núcleo Urbano Informal Consolidado",),
        )

    @staticmethod
    def _relacoes():
        return list(QgsProject.instance().relationManager().relations().values())

    def _relacao_nm(self, camada_pai, camada_filho, tabela_pivo):
        for relacao_pai in self._relacoes():
            if relacao_pai.referencedLayerId() != camada_pai.id():
                continue
            camada_pivo_atual = relacao_pai.referencingLayer()
            if not camada_pivo_atual:
                continue
            if tabela_pivo.lower() not in self._nome_tabela(camada_pivo_atual):
                continue

            for relacao_filho in self._relacoes():
                if relacao_filho.id() == relacao_pai.id():
                    continue
                if (
                    relacao_filho.referencingLayerId() == camada_pivo_atual.id()
                    and relacao_filho.referencedLayerId() == camada_filho.id()
                    and relacao_pai.isValid()
                    and relacao_filho.isValid()
                ):
                    return relacao_pai, relacao_filho, camada_pivo_atual
        return None

    @staticmethod
    def _chave_por_relacao(feicao, relacao):
        pares = dict(relacao.fieldPairs())
        if pares:
            return tuple(feicao.attribute(campo_pai) for campo_pai in pares.values())
        return (feicao.id(),)

    def _feicoes_nm(self, feicao_pai, relacoes):
        relacao_pai, relacao_filho, _ = relacoes
        chaves_vistas = set()
        resultado = []
        for feicao_pivo in relacao_pai.getRelatedFeatures(feicao_pai):
            feicao_filho = relacao_filho.getReferencedFeature(feicao_pivo)
            if not feicao_filho.isValid():
                continue
            chave = self._chave_por_relacao(feicao_filho, relacao_filho)
            if chave not in chaves_vistas:
                resultado.append(feicao_filho)
                chaves_vistas.add(chave)
        return resultado

    def _relacao_lote_nucleo(self, camada_nucleo, camada_lote):
        for relacao in self._relacoes():
            if (
                relacao.referencedLayerId() == camada_nucleo.id()
                and relacao.referencingLayerId() == camada_lote.id()
                and relacao.isValid()
            ):
                pares = dict(relacao.fieldPairs())
                if pares:
                    campo_fk, campo_pk = next(iter(pares.items()))
                    return campo_fk, campo_pk

        campo_fk = "nucleo_urbano"
        campo_pk = "id_0"
        if (
            camada_lote.fields().indexFromName(campo_fk) >= 0
            and camada_nucleo.fields().indexFromName(campo_pk) >= 0
        ):
            return campo_fk, campo_pk
        return None

    @staticmethod
    def _valor_vazio(valor):
        return valor is None or str(valor).strip() == ""

    def _lotes_do_nucleo(self, nucleo, camada_lote, relacao_direta):
        campo_fk, campo_pk = relacao_direta
        valor_pk = nucleo.attribute(campo_pk)
        return [
            lote for lote in camada_lote.getFeatures()
            if lote.attribute(campo_fk) == valor_pk
        ]

    def _nucleos_do_processo(self, processo, camada_nucleo):
        relacoes = self._relacao_nm(
            self.process_layer,
            camada_nucleo,
            "processos_reurb_nucleos_urbanos_informais",
        )
        if not relacoes:
            self._erro_relacao(
                "Não encontrei as duas relações QGIS entre PROCESSOS_REURB e "
                "processos_reurb_nucleos_urbanos_informais."
            )
            return None, None
        return self._feicoes_nm(processo, relacoes), relacoes

    def _contexto_lotes(self, processo):
        camada_nucleo = self._camada_nucleos()
        camada_lote = self._buscar_camada("lotes_reurb")
        if not camada_nucleo or not camada_lote:
            self._erro_relacao(
                "Carregue as camadas do núcleo urbano informal e lotes_reurb no projeto."
            )
            return None

        nucleos, relacoes_nm = self._nucleos_do_processo(processo, camada_nucleo)
        if nucleos is None:
            return None
        relacao_direta = self._relacao_lote_nucleo(camada_nucleo, camada_lote)
        if not relacao_direta:
            self._erro_relacao(
                "Não encontrei o vínculo lote→núcleo. Esperava a relação QGIS ou os "
                "campos lotes_reurb.nucleo_urbano e núcleo.id_0."
            )
            return None
        return camada_nucleo, camada_lote, nucleos, relacoes_nm, relacao_direta

    def _escolher_nucleo(self, processo, nucleo_layer, nucleos=None):
        if nucleos is None:
            nucleos, _ = self._nucleos_do_processo(processo, nucleo_layer)
        if nucleos is None:
            return None
        if not nucleos:
            QMessageBox.information(
                self.parent_dialog,
                "Sem núcleos vinculados",
                "Este processo ainda não possui núcleos vinculados.",
            )
            return None
        if len(nucleos) == 1:
            return nucleos[0]
        escolhidos = self._dialogo_feicoes(
            "Selecionar núcleo",
            "Escolha o núcleo deste processo:",
            nucleo_layer,
            nucleos,
            multipla=False,
            botao="Continuar",
        )
        return escolhidos[0] if escolhidos else None

    def _lotes_do_processo(self, contexto):
        camada_nucleo, camada_lote, nucleos, _, relacao_direta = contexto
        lotes = []
        rotulos = {}
        vistos = set()
        campo_fk, campo_pk = relacao_direta
        campo_pk_lote = self._campo_chave(camada_lote)

        for nucleo in nucleos:
            for lote in self._lotes_do_nucleo(nucleo, camada_lote, relacao_direta):
                chave = (
                    lote.attribute(campo_pk_lote)
                    if campo_pk_lote and lote.attribute(campo_pk_lote) is not None
                    else lote.id()
                )
                if chave in vistos:
                    continue
                vistos.add(chave)
                lotes.append(lote)
                rotulos[lote.id()] = (
                    f"{self._rotulo_feicao(camada_lote, lote)} "
                    f"(Núcleo: {self._rotulo_feicao(camada_nucleo, nucleo)})"
                )
        return lotes, rotulos

    @staticmethod
    def _campo_chave(layer):
        if layer.providerType() == "postgres":
            campo = QgsDataSourceUri(layer.source()).keyColumn()
            if campo and layer.fields().indexFromName(campo) >= 0:
                return campo
        for nome in ("id_0", "id", "fid"):
            if layer.fields().indexFromName(nome) >= 0:
                return nome
        return None

    @staticmethod
    def _rotulo_feicao(layer, feature):
        campos_prioritarios = (
            "nome", "nome_nucleo", "nome_legitimado", "n_lote", "n_crf",
            "protocolo", "matricula", "descricao", "identificacao",
        )
        for nome in campos_prioritarios:
            idx = layer.fields().indexFromName(nome)
            if idx >= 0:
                valor = feature.attribute(idx)
                if not GerenciadorVinculosReurb._valor_vazio(valor):
                    return f"{valor} [fid {feature.id()}]"

        for campo in layer.fields():
            nome = campo.name().lower()
            if nome in ("id", "fid", "id_0") or nome.startswith("fk_"):
                continue
            valor = feature.attribute(campo.name())
            if not GerenciadorVinculosReurb._valor_vazio(valor):
                return f"{campo.name()}: {valor} [fid {feature.id()}]"
        return f"Feição {feature.id()}"

    @staticmethod
    def _normalizar_busca(texto):
        texto_normalizado = unicodedata.normalize("NFKD", str(texto))
        return "".join(
            caractere for caractere in texto_normalizado
            if not unicodedata.combining(caractere)
        ).casefold()

    def _dialogo_feicoes(
        self,
        titulo,
        instrucao,
        layer,
        features,
        multipla=False,
        botao="Selecionar",
        rotulos=None,
        permitir_edicao=False,
    ):
        if not features:
            QMessageBox.information(
                self.parent_dialog,
                titulo,
                "Não há registros disponíveis para esta ação.",
            )
            return []

        dialog = QDialog(self.parent_dialog)
        dialog.setWindowTitle(titulo)
        dialog.resize(540, 420)
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel(instrucao))

        campo_busca = QLineEdit()
        campo_busca.setClearButtonEnabled(True)
        campo_busca.setPlaceholderText("Buscar por nome, identificador ou qualquer atributo...")
        layout.addWidget(campo_busca)

        lista = QListWidget()
        lista.setSelectionMode(
            QAbstractItemView.MultiSelection if multipla else QAbstractItemView.SingleSelection
        )
        for feature in features:
            label = (rotulos or {}).get(
                feature.id(),
                self._rotulo_feicao(layer, feature),
            )
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, feature.id())
            termos_busca = [label, str(feature.id())]
            termos_busca.extend(
                str(valor) for valor in feature.attributes()
                if not self._valor_vazio(valor)
            )
            item.setData(
                Qt.UserRole + 1,
                self._normalizar_busca(" ".join(termos_busca)),
            )
            lista.addItem(item)
        layout.addWidget(lista)

        linha_botoes = QHBoxLayout()
        btn_aproximar = QPushButton("Aproximar feição")
        btn_editar = QPushButton("Abrir formulário de edição")

        def aproximar_selecionada():
            item = lista.currentItem()
            if not item:
                QMessageBox.information(
                    dialog,
                    "Aproximar feição",
                    "Selecione uma feição na lista primeiro.",
                )
                return
            self._aproximar_feicao(layer, item.data(Qt.UserRole), dialog)

        btn_aproximar.clicked.connect(aproximar_selecionada)
        linha_botoes.addWidget(btn_aproximar)
        if permitir_edicao:
            def editar_selecionada():
                item = lista.currentItem()
                if not item:
                    QMessageBox.information(
                        dialog,
                        "Editar feição",
                        "Selecione uma feição na lista primeiro.",
                    )
                    return

                feature_id = item.data(Qt.UserRole)
                feature = layer.getFeature(feature_id)
                if not feature.isValid():
                    QMessageBox.warning(
                        dialog,
                        "Feição não encontrada",
                        "A feição selecionada não está mais disponível na camada.",
                    )
                    return

                iniciou_edicao = not layer.isEditable()
                if iniciou_edicao and not layer.startEditing():
                    QMessageBox.critical(
                        dialog,
                        "Camada não editável",
                        f"Não foi possível iniciar a edição da camada {layer.name()}.",
                    )
                    return

                try:
                    form = iface.getFeatureForm(layer, feature)
                    if not form:
                        raise RuntimeError("O QGIS não conseguiu criar o formulário da feição.")
                    form.setMode(QgsAttributeEditorContext.SingleEditMode)
                    form.setEditCommandMessage("Editar feição pela listagem REURB")
                    aceito = form.exec_() == QDialog.Accepted
                except Exception as erro:
                    if iniciou_edicao and layer.isEditable():
                        layer.rollBack()
                    QMessageBox.critical(
                        dialog,
                        "Falha ao abrir formulário",
                        f"Não foi possível abrir o formulário de edição do QGIS: {erro}",
                    )
                    return

                if not aceito:
                    if iniciou_edicao and layer.isEditable():
                        layer.rollBack()
                    return

                self._perguntar_destino_edicoes([layer])
                atualizada = layer.getFeature(feature_id)
                if atualizada.isValid():
                    item.setText(self._rotulo_feicao(layer, atualizada))
                    termos_busca = [item.text(), str(feature_id)]
                    termos_busca.extend(
                        str(valor) for valor in atualizada.attributes()
                        if not self._valor_vazio(valor)
                    )
                    item.setData(
                        Qt.UserRole + 1,
                        self._normalizar_busca(" ".join(termos_busca)),
                    )
                    filtrar_itens(campo_busca.text())

            btn_editar.clicked.connect(editar_selecionada)
            linha_botoes.addWidget(btn_editar)
        linha_botoes.addStretch()

        def filtrar_itens(texto):
            termos = self._normalizar_busca(texto).split()
            for indice in range(lista.count()):
                item = lista.item(indice)
                conteudo = item.data(Qt.UserRole + 1)
                item.setHidden(not all(termo in conteudo for termo in termos))

        campo_busca.textChanged.connect(filtrar_itens)

        botoes = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        botoes.button(QDialogButtonBox.Ok).setText(botao)
        botoes.accepted.connect(dialog.accept)
        botoes.rejected.connect(dialog.reject)
        linha_botoes.addWidget(botoes)
        layout.addLayout(linha_botoes)

        if dialog.exec_() != QDialog.Accepted:
            return []
        return [
            layer.getFeature(item.data(Qt.UserRole))
            for item in lista.selectedItems()
            if layer.getFeature(item.data(Qt.UserRole)).isValid()
        ]

    def _aproximar_feicao(self, layer, feature_id, parent):
        feature = layer.getFeature(feature_id)
        if not feature.isValid():
            QMessageBox.warning(
                parent,
                "Feição não encontrada",
                "A feição selecionada não está mais disponível na camada.",
            )
            return

        geometry = feature.geometry()
        if not geometry or geometry.isEmpty():
            QMessageBox.information(
                parent,
                "Sem geometria",
                "Este registro não possui geometria para aproximar no mapa.",
            )
            return

        canvas = iface.mapCanvas()
        try:
            transform = QgsCoordinateTransform(
                layer.crs(),
                canvas.mapSettings().destinationCrs(),
                QgsProject.instance(),
            )
            extent = transform.transformBoundingBox(geometry.boundingBox())
        except Exception as erro:
            QMessageBox.warning(
                parent,
                "Não foi possível aproximar",
                f"Falha ao transformar a extensão da feição para o CRS do mapa: {erro}",
            )
            return

        extent.scale(1.25)
        canvas_extent = canvas.extent()
        min_width = max(canvas_extent.width() * 0.01, 1e-6)
        min_height = max(canvas_extent.height() * 0.01, 1e-6)
        center_x = (extent.xMinimum() + extent.xMaximum()) / 2
        center_y = (extent.yMinimum() + extent.yMaximum()) / 2
        half_width = max(extent.width() / 2, min_width / 2)
        half_height = max(extent.height() / 2, min_height / 2)
        extent.setXMinimum(center_x - half_width)
        extent.setXMaximum(center_x + half_width)
        extent.setYMinimum(center_y - half_height)
        extent.setYMaximum(center_y + half_height)

        layer.selectByIds([feature.id()])
        iface.setActiveLayer(layer)
        canvas.setExtent(extent)
        canvas.refresh()

    def _mostrar_feicoes(self, titulo, layer, features, rotulos=None):
        if not features:
            QMessageBox.information(
                self.parent_dialog,
                titulo,
                "Nenhum vínculo/registro encontrado para esta seleção.",
            )
            return
        self._dialogo_feicoes(
            titulo,
            "Registros encontrados:",
            layer,
            features,
            multipla=False,
            botao="Fechar",
            rotulos=rotulos,
            permitir_edicao=True,
        )

    def _erro_relacao(self, mensagem):
        QMessageBox.warning(self.parent_dialog, "Relação REURB não configurada", mensagem)

    def mostrar_nucleos(self):
        processo = self._processo_selecionado()
        if not processo:
            return
        camada_nucleo = self._camada_nucleos()
        if not camada_nucleo:
            self._erro_relacao("A camada de núcleos urbanos informais não está carregada.")
            return
        nucleos, _ = self._nucleos_do_processo(processo, camada_nucleo)
        if nucleos is not None:
            self._mostrar_feicoes("Núcleos do processo", camada_nucleo, nucleos)

    def vincular_nucleo_existente(self):
        processo = self._processo_selecionado()
        if not processo:
            return
        camada_nucleo = self._camada_nucleos()
        if not camada_nucleo:
            self._erro_relacao("A camada de núcleos urbanos informais não está carregada.")
            return
        nucleos_vinculados, relacoes = self._nucleos_do_processo(processo, camada_nucleo)
        if nucleos_vinculados is None:
            return
        chaves_vinculadas = {
            self._chave_por_relacao(feature, relacoes[1])
            for feature in nucleos_vinculados
        }
        candidatos = [
            feature for feature in camada_nucleo.getFeatures()
            if self._chave_por_relacao(feature, relacoes[1]) not in chaves_vinculadas
        ]
        escolhidos = self._dialogo_feicoes(
            "Vincular núcleos",
            "Selecione um ou mais núcleos existentes para associar ao processo:",
            camada_nucleo,
            candidatos,
            multipla=True,
        )
        if escolhidos:
            self._adicionar_vinculos_nm(processo, escolhidos, relacoes)

    def adicionar_nucleo(self):
        processo = self._processo_selecionado()
        if not processo:
            return
        camada_nucleo = self._camada_nucleos()
        if not camada_nucleo:
            self._erro_relacao("A camada de núcleos urbanos informais não está carregada.")
            return
        relacoes = self._relacao_nm(
            self.process_layer,
            camada_nucleo,
            "processos_reurb_nucleos_urbanos_informais",
        )
        if not relacoes:
            self._erro_relacao(
                "Não encontrei as relações QGIS do processo e do núcleo com a tabela "
                "processos_reurb_nucleos_urbanos_informais."
            )
            return
        self._iniciar_digitizacao(
            camada_nucleo,
            relacao_nm=(processo, relacoes),
        )

    def mostrar_lotes(self):
        processo = self._processo_selecionado()
        if not processo:
            return
        contexto = self._contexto_lotes(processo)
        if not contexto:
            return
        lotes, rotulos = self._lotes_do_processo(contexto)
        self._mostrar_feicoes(
            "Lotes do processo",
            contexto[1],
            lotes,
            rotulos=rotulos,
        )

    def vincular_lote_existente(self):
        processo = self._processo_selecionado()
        if not processo:
            return
        contexto = self._contexto_lotes(processo)
        if not contexto:
            return
        camada_nucleo, camada_lote, nucleos, _, relacao_direta = contexto
        nucleo = self._escolher_nucleo(processo, camada_nucleo, nucleos)
        if not nucleo:
            return

        campo_fk, _ = relacao_direta
        candidatos = [
            lote for lote in camada_lote.getFeatures()
            if self._valor_vazio(lote.attribute(campo_fk))
        ]
        escolhidos = self._dialogo_feicoes(
            "Vincular lotes",
            "Selecione os lotes ainda sem núcleo para associar ao núcleo escolhido:",
            camada_lote,
            candidatos,
            multipla=True,
        )
        if escolhidos:
            self._atribuir_fk_direta(camada_lote, escolhidos, relacao_direta, nucleo)

    def adicionar_lote(self):
        processo = self._processo_selecionado()
        if not processo:
            return
        contexto = self._contexto_lotes(processo)
        if not contexto:
            return
        camada_nucleo, camada_lote, nucleos, _, relacao_direta = contexto
        nucleo = self._escolher_nucleo(processo, camada_nucleo, nucleos)
        if nucleo:
            self._iniciar_digitizacao(
                camada_lote,
                fk_direta=(nucleo, relacao_direta),
            )

    def _escolher_lote_do_processo(self, processo):
        contexto = self._contexto_lotes(processo)
        if not contexto:
            return None
        lotes, rotulos = self._lotes_do_processo(contexto)
        if not lotes:
            QMessageBox.information(
                self.parent_dialog,
                "Sem lotes no processo",
                "Não há lotes vinculados aos núcleos deste processo REURB.",
            )
            return None
        escolhidos = self._dialogo_feicoes(
            "Selecionar lote",
            "Escolha um dos lotes pertencentes aos núcleos deste processo:",
            contexto[1],
            lotes,
            multipla=False,
            rotulos=rotulos,
        )
        return (escolhidos[0], contexto[1]) if escolhidos else None

    def _relacoes_lote_legitimado(self, camada_lote, camada_legitimado):
        relacoes = self._relacao_nm(
            camada_lote,
            camada_legitimado,
            "lotes_reurb_legitimados_reurb",
        )
        if not relacoes:
            self._erro_relacao(
                "Não encontrei as duas relações QGIS entre lotes_reurb e "
                "lotes_reurb_legitimados_reurb."
            )
        return relacoes

    def _com_lote_e_relacao_legitimado(self, acao):
        processo = self._processo_selecionado()
        if not processo:
            return
        selecionado = self._escolher_lote_do_processo(processo)
        if not selecionado:
            return
        lote, camada_lote = selecionado
        camada_legitimado = self._buscar_camada("legitimados_reurb")
        if not camada_legitimado:
            self._erro_relacao("A camada legitimados_reurb não está carregada.")
            return
        relacoes = self._relacoes_lote_legitimado(camada_lote, camada_legitimado)
        if relacoes:
            acao(lote, camada_legitimado, relacoes)

    def mostrar_legitimados(self):
        self._com_lote_e_relacao_legitimado(
            lambda lote, layer, rel: self._mostrar_feicoes(
                "Legitimados do lote",
                layer,
                self._feicoes_nm(lote, rel),
            )
        )

    def vincular_legitimado_existente(self):
        self._com_lote_e_relacao_legitimado(self._vincular_legitimado_existente)

    def _vincular_legitimado_existente(self, lote, camada_legitimado, relacoes):
        vinculados = self._feicoes_nm(lote, relacoes)
        chaves_vinculadas = {
            self._chave_por_relacao(feature, relacoes[1])
            for feature in vinculados
        }
        candidatos = [
            feature for feature in camada_legitimado.getFeatures()
            if self._chave_por_relacao(feature, relacoes[1]) not in chaves_vinculadas
        ]
        escolhidos = self._dialogo_feicoes(
            "Vincular legitimados",
            "Selecione um ou mais legitimados existentes para associar ao lote:",
            camada_legitimado,
            candidatos,
            multipla=True,
        )
        if escolhidos:
            self._adicionar_vinculos_nm(lote, escolhidos, relacoes)

    def adicionar_legitimado(self):
        self._com_lote_e_relacao_legitimado(self._iniciar_formulario_legitimado)

    def _iniciar_formulario_legitimado(self, lote, layer, relacoes):
        if self._pending_digitizing:
            QMessageBox.warning(
                self.parent_dialog,
                "Cadastro em andamento",
                "Finalize o cadastro atual antes de iniciar outro vínculo.",
            )
            return

        iniciou_edicao = not layer.isEditable()
        if iniciou_edicao and not layer.startEditing():
            QMessageBox.critical(
                self.parent_dialog,
                "Camada não editável",
                f"Não foi possível iniciar a edição da camada {layer.name()}.",
            )
            return

        original_config = layer.editFormConfig()
        pending = {
            "layer": layer,
            "fk_direta": None,
            "relacao_nm": (lote, relacoes),
            "tool": None,
            "feature_slot": None,
            "original_default": None,
            "default_index": -1,
            "original_form_config": original_config,
            "affected_layers": [],
            "started_layers": [layer] if iniciou_edicao else [],
            "managed_form": True,
        }

        try:
            form_config = layer.editFormConfig()
            form_layout = getattr(Qgis, "AttributeFormLayout", None)
            layout = form_layout.TabLayout if form_layout else QgsEditFormConfig.TabLayout
            form_config.setLayout(layout)
            form_config.clearTabs()

            campos_relacionados = {
                campo
                for relacao in self._relacoes()
                if relacao.referencingLayerId() == layer.id()
                for campo in dict(relacao.fieldPairs()).keys()
            }
            chave_primaria = self._campo_chave(layer)
            aba = QgsAttributeEditorContainer("Dados do legitimado", None)
            aba.setIsGroupBox(False)
            for idx, field in enumerate(layer.fields()):
                nome = field.name()
                if nome in (chave_primaria, "id_lote_reurb") or nome.startswith("fk_"):
                    continue
                if nome in campos_relacionados:
                    continue
                aba.addChildElement(QgsAttributeEditorField(nome, idx, aba))
            form_config.addTab(aba)
            layer.setEditFormConfig(form_config)
        except Exception as erro:
            layer.setEditFormConfig(original_config)
            if iniciou_edicao:
                layer.rollBack()
            QMessageBox.critical(
                self.parent_dialog,
                "Falha ao preparar o cadastro",
                f"Não foi possível preparar o formulário do legitimado: {erro}",
            )
            return

        feature = QgsFeature(layer.fields())
        pending["feature_slot"] = self._ao_adicionar_feicao
        self._pending_digitizing = pending
        layer.featureAdded.connect(pending["feature_slot"])
        iface.setActiveLayer(layer)
        self.parent_dialog.hide()

        try:
            form = iface.getFeatureForm(layer, feature)
            if not form:
                raise RuntimeError("O QGIS não conseguiu criar o formulário do legitimado.")
            form.setMode(QgsAttributeEditorContext.AddFeatureMode)
            form.setEditCommandMessage("Cadastrar legitimado vinculado ao lote")
            aceito = form.exec_() == QDialog.Accepted
            if aceito and not pending["affected_layers"]:
                QMessageBox.warning(
                    self.parent_dialog,
                    "Cadastro não confirmado",
                    "O formulário foi aceito, mas o QGIS não informou a inclusão da feição.",
                )
        except Exception as erro:
            QMessageBox.critical(
                self.parent_dialog,
                "Falha ao cadastrar legitimado",
                f"O formulário não pôde ser concluído: {erro}",
            )
        finally:
            if self._pending_digitizing is pending:
                self._finalizar_digitizacao()

    def _adicionar_vinculos_nm(self, feicao_pai, feicoes_filhas, relacoes):
        relacao_pai, relacao_filho, camada_pivo = relacoes
        chaves_existentes = {
            self._chave_por_relacao(feature, relacao_filho)
            for feature in self._feicoes_nm(feicao_pai, relacoes)
        }
        novos = [
            feature for feature in feicoes_filhas
            if self._chave_por_relacao(feature, relacao_filho) not in chaves_existentes
        ]
        if not novos:
            QMessageBox.information(
                self.parent_dialog,
                "Vínculos existentes",
                "Todos os registros selecionados já estão vinculados.",
            )
            return True

        for feicao_filha in novos:
            for relacao, feicao in (
                (relacao_pai, feicao_pai),
                (relacao_filho, feicao_filha),
            ):
                for _, campo_pk in dict(relacao.fieldPairs()).items():
                    if self._valor_vazio(feicao.attribute(campo_pk)):
                        QMessageBox.warning(
                            self.parent_dialog,
                            "Chave ainda não disponível",
                            f"A chave '{campo_pk}' da feição nova ainda não foi gerada. "
                            "Salve primeiro a camada da feição e depois use a opção de "
                            "vincular registro existente.",
                        )
                        return False

        iniciou_edicao = not camada_pivo.isEditable()
        if iniciou_edicao and not camada_pivo.startEditing():
            QMessageBox.critical(
                self.parent_dialog,
                "Camada não editável",
                f"Não foi possível iniciar a edição da tabela pivô {camada_pivo.name()}.",
            )
            return False
        if iniciou_edicao and self._pending_digitizing:
            self._pending_digitizing["started_layers"].append(camada_pivo)

        quantidade = 0
        try:
            for feicao_filha in novos:
                nova = QgsFeature(camada_pivo.fields())
                for relacao in (relacao_pai, relacao_filho):
                    pares = dict(relacao.fieldPairs())
                    if not pares:
                        raise RuntimeError(
                            f"A relação '{relacao.name()}' não possui pares de campos configurados."
                        )
                    for campo_fk, campo_pai in pares.items():
                        idx_fk = camada_pivo.fields().indexFromName(campo_fk)
                        if idx_fk < 0:
                            raise RuntimeError(
                                f"O campo '{campo_fk}' não existe na tabela pivô {camada_pivo.name()}."
                            )
                        pai = feicao_pai if relacao is relacao_pai else feicao_filha
                        nova.setAttribute(idx_fk, pai.attribute(campo_pai))
                if not camada_pivo.addFeature(nova):
                    raise RuntimeError(
                        f"Falha ao adicionar uma associação em {camada_pivo.name()}."
                    )
                quantidade += 1
        except Exception as erro:
            QMessageBox.critical(
                self.parent_dialog,
                "Falha ao criar vínculo",
                f"{erro}\n\nAs alterações já feitas permanecem no buffer de edição da camada.",
            )
            if quantidade:
                self._registrar_camadas_alteradas([camada_pivo])
            elif iniciou_edicao and not self._pending_digitizing:
                camada_pivo.rollBack()
            return False

        self._registrar_camadas_alteradas([camada_pivo])
        return True

    def _atribuir_fk_direta(self, layer, features, relacao_direta, nucleo):
        campo_fk, campo_pk = relacao_direta
        idx_fk = layer.fields().indexFromName(campo_fk)
        valor_pk = nucleo.attribute(campo_pk)
        if idx_fk < 0 or self._valor_vazio(valor_pk):
            QMessageBox.critical(
                self.parent_dialog,
                "Chave de vínculo inválida",
                f"Não foi possível ler a FK '{campo_fk}' ou a chave '{campo_pk}' do núcleo.",
            )
            return

        iniciou_edicao = not layer.isEditable()
        if iniciou_edicao and not layer.startEditing():
            QMessageBox.critical(
                self.parent_dialog,
                "Camada não editável",
                f"Não foi possível iniciar a edição da camada {layer.name()}.",
            )
            return

        alterados = 0
        for feature in features:
            if layer.changeAttributeValue(feature.id(), idx_fk, valor_pk):
                alterados += 1
        if alterados != len(features):
            QMessageBox.warning(
                self.parent_dialog,
                "Vínculo parcialmente aplicado",
                f"Foram vinculados {alterados} de {len(features)} lotes. "
                "Verifique o buffer de edição da camada.",
            )
        if alterados:
            self._registrar_camadas_alteradas([layer])
        elif iniciou_edicao:
            layer.rollBack()

    def _iniciar_digitizacao(self, layer, fk_direta=None, relacao_nm=None):
        if self._pending_digitizing:
            QMessageBox.warning(
                self.parent_dialog,
                "Digitalização em andamento",
                "Finalize a ferramenta de adição ativa no QGIS antes de iniciar outro vínculo.",
            )
            return
        if not layer or not layer.isValid():
            self._erro_relacao("A camada de destino não é válida.")
            return

        if fk_direta:
            nucleo, (campo_fk, campo_pk) = fk_direta
            idx_fk = layer.fields().indexFromName(campo_fk)
            valor_pk = nucleo.attribute(campo_pk)
            if idx_fk < 0 or self._valor_vazio(valor_pk):
                QMessageBox.critical(
                    self.parent_dialog,
                    "Chave de vínculo inválida",
                    f"Não foi possível preparar o campo '{campo_fk}' para o núcleo selecionado.",
                )
                return

        iniciou_edicao = not layer.isEditable()
        if iniciou_edicao and not layer.startEditing():
            QMessageBox.critical(
                self.parent_dialog,
                "Camada não editável",
                f"Não foi possível iniciar a edição da camada {layer.name()}.",
            )
            return

        pending = {
            "layer": layer,
            "fk_direta": fk_direta,
            "relacao_nm": relacao_nm,
            "tool": None,
            "feature_slot": None,
            "original_default": None,
            "default_index": -1,
            "original_form_config": None,
            "affected_layers": [],
            "started_layers": [layer] if iniciou_edicao else [],
            "managed_form": False,
        }

        if fk_direta:
            pending["default_index"] = idx_fk
            pending["original_default"] = layer.defaultValueDefinition(idx_fk)
            pending["original_form_config"] = layer.editFormConfig()
            try:
                layer.setDefaultValueDefinition(
                    idx_fk,
                    QgsDefaultValue(QgsExpression.quotedValue(valor_pk), False),
                )
                form_config = layer.editFormConfig()
                form_config.setReadOnly(idx_fk, True)
                layer.setEditFormConfig(form_config)
            except Exception as erro:
                layer.setDefaultValueDefinition(idx_fk, pending["original_default"])
                QMessageBox.critical(
                    self.parent_dialog,
                    "Não foi possível preparar o formulário",
                    f"Falha ao pré-preencher/bloquear '{campo_fk}': {erro}",
                )
                if iniciou_edicao:
                    layer.rollBack()
                return

        pending["feature_slot"] = self._ao_adicionar_feicao
        self._pending_digitizing = pending
        layer.featureAdded.connect(pending["feature_slot"])
        iface.mapCanvas().mapToolSet.connect(self._ao_trocar_ferramenta)
        iface.setActiveLayer(layer)

        action = iface.actionAddFeature()
        if not action:
            self._finalizar_digitizacao()
            QMessageBox.critical(
                self.parent_dialog,
                "Ferramenta indisponível",
                "Não encontrei a ação nativa 'Adicionar feição' do QGIS.",
            )
            return
        try:
            action.trigger()
        except Exception as erro:
            self._finalizar_digitizacao()
            QMessageBox.critical(
                self.parent_dialog,
                "Falha ao iniciar a ferramenta",
                f"Não foi possível iniciar a ferramenta de adição do QGIS: {erro}",
            )
            return
        if self._pending_digitizing is not pending:
            return
        pending["tool"] = iface.mapCanvas().mapTool()
        if not layer.isSpatial():
            self._finalizar_digitizacao()
            return
        self.parent_dialog.hide()
        self._mensagem(
            f"Ferramenta nativa de adição ativa para {layer.name()}. "
            "O vínculo será aplicado automaticamente; encerre a ferramenta para voltar à gestão REURB."
        )

    def _ao_adicionar_feicao(self, feature_id):
        pending = self._pending_digitizing
        if not pending:
            return
        layer = pending["layer"]
        self._registrar_camadas_alteradas([layer])
        feature = layer.getFeature(feature_id)
        if not feature.isValid():
            self._mensagem(
                "A feição foi criada, mas não foi possível recuperá-la para aplicar o vínculo.",
            )
            return

        try:
            if pending["fk_direta"]:
                feicao_pai, (campo_fk, campo_pk) = pending["fk_direta"]
                idx_fk = layer.fields().indexFromName(campo_fk)
                valor_pk = feicao_pai.attribute(campo_pk)
                if idx_fk < 0 or not layer.changeAttributeValue(feature_id, idx_fk, valor_pk):
                    raise RuntimeError(f"Não foi possível preencher a FK '{campo_fk}'.")
            if pending["relacao_nm"]:
                feicao_pai, relacoes = pending["relacao_nm"]
                if not self._adicionar_vinculos_nm(feicao_pai, [feature], relacoes):
                    return
        except Exception as erro:
            self._mensagem(
                f"A feição foi criada, mas não foi possível aplicar o vínculo: {erro}",
            )
            return

        self._mensagem(
            f"Nova feição e vínculo preparados em {layer.name()}. "
            "Ao encerrar a ferramenta, escolha salvar ou descartar as alterações.",
        )
        if not layer.isSpatial() and not pending.get("managed_form"):
            self._finalizar_digitizacao()

    def _ao_trocar_ferramenta(self, nova_ferramenta, _ferramenta_anterior):
        pending = self._pending_digitizing
        if not pending:
            return
        if pending["tool"] is None:
            pending["tool"] = nova_ferramenta
            return
        if nova_ferramenta is not pending["tool"]:
            self._finalizar_digitizacao()

    def _finalizar_digitizacao(self):
        pending = self._pending_digitizing
        if not pending:
            return

        layer = pending["layer"]
        try:
            if pending["feature_slot"]:
                layer.featureAdded.disconnect(pending["feature_slot"])
        except (TypeError, RuntimeError):
            pass
        try:
            iface.mapCanvas().mapToolSet.disconnect(self._ao_trocar_ferramenta)
        except (TypeError, RuntimeError):
            pass

        if pending["default_index"] >= 0:
            layer.setDefaultValueDefinition(
                pending["default_index"],
                pending["original_default"],
            )
        if pending["original_form_config"] is not None:
            layer.setEditFormConfig(pending["original_form_config"])

        self._pending_digitizing = None
        if not self.parent_dialog.isVisible():
            self.parent_dialog.show()
            self.parent_dialog.raise_()

        afetadas = pending["affected_layers"]
        ids_afetados = {layer.id() for layer in afetadas}
        for layer_iniciada in pending["started_layers"]:
            if layer_iniciada.id() not in ids_afetados and layer_iniciada.isEditable():
                layer_iniciada.rollBack()

        if afetadas:
            self._perguntar_destino_edicoes(afetadas)
        else:
            texto = (
                "Ferramenta encerrada sem novas feições; edições iniciadas por esta ação foram revertidas."
                if pending["started_layers"]
                else "Ferramenta encerrada sem novas feições; nenhuma edição foi feita."
            )
            self._mensagem(texto)
