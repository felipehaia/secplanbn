import csv
import unicodedata
from qgis.core import (
    QgsProject,
    QgsFeature,
    Qgis
)
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QFileDialog, QProgressBar

NOME_CAMADA = "imoveis"

def normalizar_texto(texto):
    """Remove acentos e converte para minúsculas para associar o CSV com a Camada."""
    if not texto:
        return ""
    texto_nfd = unicodedata.normalize('NFD', texto)
    sem_acentos = ''.join(c for c in texto_nfd if unicodedata.category(c) != 'Mn')
    return sem_acentos.lower().strip()

def run():
    # 1. Janela de Seleção de Arquivo CSV
    caminho_csv, _ = QFileDialog.getOpenFileName(
        None,
        "Selecione o arquivo CSV para atualizar o banco de dados",
        "",
        "Arquivos CSV (*.csv);;Todos os Arquivos (*)"
    )

    if not caminho_csv:
        print("Execução cancelada: Nenhum arquivo foi selecionado.")
        return

    # 2. Obter a camada do QGIS
    camadas = QgsProject.instance().mapLayersByName(NOME_CAMADA)

    if not camadas:
        iface.messageBar().pushMessage(
            "Erro", 
            f"A camada '{NOME_CAMADA}' não foi encontrada no projeto atual.", 
            level=Qgis.MessageLevel.Critical, 
            duration=5
        )
        return

    camada_destino = camadas[0]

    # 3. Ler o arquivo CSV utilizando UTF-8-SIG para acentuação perfeita (Ç, Ã, É, etc.)
    try:
        with open(caminho_csv, mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f, delimiter=';')
            linhas_csv = list(reader)
    except Exception as e:
        iface.messageBar().pushMessage(
            "Erro", 
            f"Falha ao ler o arquivo CSV: {e}", 
            level=Qgis.MessageLevel.Critical, 
            duration=5
        )
        return

    total_linhas = len(linhas_csv)
    if total_linhas == 0:
        iface.messageBar().pushMessage(
            "Aviso", 
            "O arquivo CSV selecionado está vazio ou inválido.", 
            level=Qgis.MessageLevel.Warning, 
            duration=5
        )
        return

    # 4. Mapear os campos da camada para as colunas do CSV
    fields_camada = camada_destino.fields()
    colunas_csv_map = {normalizar_texto(col): col for col in linhas_csv[0].keys() if col}

    mapeamento_campos = {}
    for field in fields_camada:
        nome_campo = field.name()
        nome_norm = normalizar_texto(nome_campo)
        
        if nome_norm in colunas_csv_map:
            mapeamento_campos[nome_campo] = colunas_csv_map[nome_norm]

    # 5. Criar e Exibir a Barra de Progresso
    progress_bar = QProgressBar()
    progress_bar.setMaximum(total_linhas)
    progress_bar.setValue(0)
    
    message_bar = iface.messageBar().createMessage("Atualizando banco de dados Betha...")
    message_bar.layout().addWidget(progress_bar)
    iface.messageBar().pushWidget(message_bar, Qgis.MessageLevel.Info)

    # 6. Iniciar edição na camada
    camada_destino.startEditing()

    try:
        # A. Apagar registros existentes
        ids_existentes = [f.id() for f in camada_destino.getFeatures()]
        if ids_existentes:
            camada_destino.deleteFeatures(ids_existentes)

        # B. Inserir novos registros respeitando a estrutura original
        novas_feicoes = []
        for i, linha in enumerate(linhas_csv):
            feicao = QgsFeature(fields_camada)

            for nome_campo_camada, col_csv in mapeamento_campos.items():
                valor = linha.get(col_csv, "")
                feicao.setAttribute(nome_campo_camada, valor if valor is not None else "")

            novas_feicoes.append(feicao)

            # Atualizar barra de progresso a cada 100 registros
            if (i + 1) % 100 == 0 or (i + 1) == total_linhas:
                progress_bar.setValue(i + 1)
                iface.mainWindow().repaint()

        # C. Efetivar alterações
        sucesso, feicoes_add = camada_destino.dataProvider().addFeatures(novas_feicoes)

        if sucesso:
            camada_destino.commitChanges()
            camada_destino.triggerRepaint()
            
            iface.messageBar().clearWidgets()
            iface.messageBar().pushMessage(
                "Sucesso", 
                f"Banco de dados de '{NOME_CAMADA}' substituído por {len(feicoes_add)} registro(s).", 
                level=Qgis.MessageLevel.Success, 
                duration=5
            )
        else:
            camada_destino.rollBack()
            iface.messageBar().clearWidgets()
            iface.messageBar().pushMessage(
                "Erro", 
                "Falha ao salvar feições.", 
                level=Qgis.MessageLevel.Critical, 
                duration=5
            )

    except Exception as err:
        camada_destino.rollBack()
        iface.messageBar().clearWidgets()
        iface.messageBar().pushMessage(
            "Erro", 
            f"Erro durante a execução: {err}", 
            level=Qgis.MessageLevel.Critical, 
            duration=5
        )