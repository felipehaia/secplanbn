from collections import Counter
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsCoordinateTransform,
)
from qgis.PyQt.QtCore import QVariant

# --- 1. MAPEAMENTO DE NOMES CNAE (2 DÍGITOS) ---
NOME_CNAE = {
    "01": "Agricultura, Pecuária e Serviços Relacionados",
    "02": "Produção Florestal",
    "03": "Pesca e Aqüicultura",
    "05": "Extração de Carvão Mineral",
    "06": "Extração de Petróleo e Gás Natural",
    "07": "Extração de Minerais Metálicos",
    "08": "Extração de Minerais Não-Metálicos",
    "09": "Apoio à Extração de Minerais",
    "10": "Fabricação de Produtos Alimentícios",
    "11": "Fabricação de Bebidas",
    "12": "Fabricação de Produtos do Fumo",
    "13": "Fabricação de Produtos Têxteis",
    "14": "Confecção de Artigos do Vestuário e Acessórios",
    "15": "Couros, Artefatos de Couro, Calçados e Viagem",
    "16": "Fabricação de Produtos de Madeira",
    "17": "Fabricação de Celulose, Papel e Produtos de Papel",
    "18": "Impressão e Reprodução de Gravações",
    "19": "Coque, Derivados do Petróleo e Biocombustíveis",
    "20": "Fabricação de Produtos Químicos",
    "21": "Produtos Farmoquímicos e Farmacêuticos",
    "22": "Produtos de Borracha e Material Plástico",
    "23": "Produtos de Minerais Não-Metálicos",
    "24": "Metalurgia",
    "25": "Produtos de Metal (exceto máquinas)",
    "26": "Equipamentos de Informática, Eletrônicos e Ópticos",
    "27": "Máquinas, Aparelhos e Materiais Elétricos",
    "28": "Fabricação de Máquinas e Equipamentos",
    "29": "Veículos Automotores, Reboques e Carrocerias",
    "30": "Outros Equipamentos de Transporte",
    "31": "Fabricação de Móveis",
    "32": "Fabricação de Produtos Diversos",
    "33": "Manutenção e Instalação de Máquinas",
    "35": "Eletricidade, Gás e Outras Utilidades",
    "36": "Captação, Tratamento e Distribuição de Água",
    "37": "Esgoto e Atividades Relacionadas",
    "38": "Coleta, Tratamento e Disposição de Resíduos",
    "39": "Descontaminação e Gestão de Resíduos",
    "41": "Construção de Edifícios",
    "42": "Obras de Infra-Estrutura",
    "43": "Serviços Especializados para Construção",
    "45": "Comércio e Reparação de Veículos Automotores",
    "46": "Comércio por Atacado",
    "47": "Comércio Varejista",
    "49": "Transporte Terrestre",
    "50": "Transporte Aquaviário",
    "51": "Transporte Aéreo",
    "52": "Armazenamento e Apoio aos Transportes",
    "53": "Correio e Entregas",
    "55": "Alojamento",
    "56": "Alimentação",
    "58": "Edição e Edição Integrada à Impressão",
    "59": "Atividades Cinematográficas e Produção de Vídeos",
    "60": "Atividades de Rádio e Televisão",
    "61": "Telecomunicações",
    "62": "Serviços de Tecnologia da Informação",
    "63": "Serviços de Informação",
    "64": "Serviços Financeiros",
    "65": "Seguros, Resseguros e Previdência Complementar",
    "66": "Atividades Auxiliares dos Serviços Financeiros",
    "68": "Atividades Imobiliárias",
    "69": "Atividades Jurídicas, Contabilidade e Auditoria",
    "70": "Sedes de Empresas e Consultoria em Gestão",
    "71": "Arquitetura, Engenharia e Testes Técnicos",
    "72": "Pesquisa e Desenvolvimento Científico",
    "73": "Publicidade e Pesquisa de Mercado",
    "74": "Outras Atividades Profissionais e Técnicas",
    "75": "Atividades Veterinárias",
    "77": "Aluguéis Não-Imobiliários e Ativos Intangíveis",
    "78": "Seleção e Agenciamento de Mão-de-Obra",
    "79": "Agências de Viagens e Operadores Turísticos",
    "80": "Vigilância, Segurança e Investigação",
    "81": "Serviços para Edifícios e Paisagismo",
    "82": "Serviços de Escritório e Apoio Administrativo",
    "84": "Administração Pública, Defesa e Seguridade Social",
    "85": "Educação",
    "86": "Atenção à Saúde Humana",
    "87": "Atenção à Saúde Humana em Residências Coletivas",
    "88": "Serviços de Assistência Social sem Alojamento",
    "90": "Atividades Artísticas, Criativas e Espetáculos",
    "91": "Patrimônio Cultural e Ambiental",
    "92": "Exploração de Jogos de Azar e Apostas",
    "93": "Atividades Esportivas e Recreação",
    "94": "Atividades de Organizações Associativas",
    "95": "Reparação de Equipamentos e Objetos Pessoais",
    "96": "Outras Atividades de Serviços Pessoais",
    "97": "Serviços Domésticos",
    "99": "Organismos Internacionais e Extraterritoriais",
}


# --- 2. HIERARQUIA: SETOR x SUBSETOR ---
def classificar_cnae_hierarquico(codigo_str):
    """Mapeia os 2 dígitos do CNAE em (Setor Global, Subsetor Específico)."""
    try:
        code = int(codigo_str)
    except (ValueError, TypeError):
        return ("Outros", "Não Especificado")

    # 1. Atividades Rurais e Extrativistas
    if 1 <= code <= 3:
        return ("Atividades Rurais e Extrativistas", "Agropecuária, Pesca e Silvicultura")
    elif 5 <= code <= 9:
        return ("Atividades Rurais e Extrativistas", "Extrativa Mineral e Fóssil")

    # 2. Indústria
    elif code in (10, 11):
        return ("Indústria", "Alimentícia e Bebidas")
    elif code in (13, 14, 15):
        return ("Indústria", "Têxtil, Vestuário e Calçados")
    elif code in (16, 31):
        return ("Indústria", "Madeira e Móveis")
    elif code in (17, 18):
        return ("Indústria", "Papel, Celulose e Gráfica")
    elif code in (19, 20, 21, 22):
        return ("Indústria", "Química, Borracha e Farmacêutica")
    elif code in (23, 24, 25):
        return ("Indústria", "Metalurgia e Minerais Não-Metálicos")
    elif code in (26, 27, 28):
        return ("Indústria", "Máquinas, Equipamentos e Eletrônicos")
    elif code in (29, 30):
        return ("Indústria", "Automotiva e Transportes")
    elif code in (12, 32, 33):
        return ("Indústria", "Diversos e Manutenção Industrial")

    # 3. Comércio
    elif code == 45:
        return ("Comércio", "Veículos, Peças e Oficinas")
    elif code == 46:
        return ("Comércio", "Atacadista")
    elif code == 47:
        return ("Comércio", "Varejista em Geral")
    elif code == 56:
        return ("Comércio", "Alimentício (Bares e Restaurantes)")

    # 4. Serviços
    elif 35 <= code <= 39:
        return ("Serviços", "Infraestrutura, Saneamento e Utilidades")
    elif 41 <= code <= 43:
        return ("Serviços", "Construção Civil e Obras")
    elif 49 <= code <= 53:
        return ("Serviços", "Transporte, Logística e Entregas")
    elif code == 55:
        return ("Serviços", "Alojamento e Hotelaria")
    elif 58 <= code <= 63:
        return ("Serviços", "Tecnologia e Informação")
    elif 64 <= code <= 66:
        return ("Serviços", "Financeiros e Seguros")
    elif code == 68:
        return ("Serviços", "Imobiliários")
    elif 69 <= code <= 75:
        return ("Serviços", "Profissionais, Técnicos e Científicos")
    elif 77 <= code <= 82:
        return ("Serviços", "Apoio Administrativo e Operacional")
    elif code == 84:
        return ("Serviços", "Administração Pública e Defesa")
    elif code == 85:
        return ("Serviços", "Educação")
    elif 86 <= code <= 88:
        return ("Serviços", "Saúde e Assistência Social")
    elif 90 <= code <= 93:
        return ("Serviços", "Cultura, Esporte e Lazer")
    elif 94 <= code <= 97:
        return ("Serviços", "Pessoais e Comunitários")

    else:
        return ("Serviços", "Outros Serviços")


def extrair_dias_cnae(val_cnae):
    digits = "".join(filter(str.isdigit, str(val_cnae))).strip()[:2]
    return digits.zfill(2) if digits else None


# --- 3. CARREGAMENTO DAS CAMADAS ---
project = QgsProject.instance()

layer_pontos = project.mapLayersByName("economia")[0]
layer_bairros = project.mapLayersByName("BAIRROS")[0]
camadas_quadras = project.mapLayersByName("QUADRAS")
layer_quadras = camadas_quadras[0] if camadas_quadras else None


# --- 4. PROCESSAMENTO ESPACIAL ---
def processar_estatisticas(layer_poligonos, e_quadra=False):
    resultados = {}

    crs_pontos = layer_pontos.crs()
    crs_poligonos = layer_poligonos.crs()
    transformar = crs_pontos != crs_poligonos

    if transformar:
        ct = QgsCoordinateTransform(
            crs_pontos, crs_poligonos, project.transformContext()
        )

    pontos_preparados = []
    for p_feat in layer_pontos.getFeatures():
        geom_p = p_feat.geometry()
        if geom_p.isEmpty():
            continue

        if transformar:
            geom_p = QgsGeometry(geom_p)
            geom_p.transform(ct)

        cod_cnae = extrair_dias_cnae(p_feat["cnae_principal"])
        if cod_cnae:
            pontos_preparados.append((geom_p, cod_cnae))

    for feature in layer_poligonos.getFeatures():
        geom_poly = feature.geometry()
        if geom_poly.isEmpty():
            continue

        if not geom_poly.isGeosValid():
            geom_poly = geom_poly.makeValid()

        if e_quadra:
            fields_names = [f.name() for f in feature.fields()]
            setor = str(feature["setor"]) if "setor" in fields_names and feature["setor"] is not None else ""
            quadra = str(feature["quadra"]) if "quadra" in fields_names and feature["quadra"] is not None else ""
            id_0 = str(feature["id_0"]) if "id_0" in fields_names else str(feature.id())
            
            id_val = f"Setor {setor} - Q{quadra}" if setor and quadra else f"Quadra_{id_0}"
        else:
            campo_bairro = "nome" if "nome" in [f.name() for f in feature.fields()] else feature.fields()[0].name()
            id_val = str(feature[campo_bairro])

        geom_busca = geom_poly.buffer(1.0, 5) if e_quadra and not crs_poligonos.isGeographic() else geom_poly

        cnaes = []
        for geom_p, cod_cnae in pontos_preparados:
            if geom_busca.intersects(geom_p):
                cnaes.append(cod_cnae)

        resultados[id_val] = {"cnaes": cnaes, "geometry": geom_poly}

    return resultados


# --- 5. GERAÇÃO DA CAMADA DE SAÍDA ---
def criar_camada_estatisticas(
    nome_camada, dados, nome_campo_id, com_geometria=False, crs_str="EPSG:4326"
):
    tipo_geom = f"Polygon?crs={crs_str}" if com_geometria else f"None?crs={crs_str}"
    mem_layer = QgsVectorLayer(tipo_geom, nome_camada, "memory")
    prov = mem_layer.dataProvider()

    campos = [
        QgsField(nome_campo_id, QVariant.String),
        QgsField("total_empresas", QVariant.Int),
        QgsField("maior_incidencia", QVariant.String),
        QgsField("setor_predominante", QVariant.String),
        QgsField("subsetor_predominante", QVariant.String),
    ]

    for i in range(1, 6):
        campos.append(QgsField(f"top{i}_cnae", QVariant.String))
        campos.append(QgsField(f"top{i}_pct", QVariant.Double, "double", 6, 2))

    campos.append(QgsField("outros_pct", QVariant.Double, "double", 6, 2))

    prov.addAttributes(campos)
    mem_layer.updateFields()

    mem_layer.startEditing()

    for item_id, info in dados.items():
        cnaes = info["cnaes"]
        total = len(cnaes)

        if total > 0:
            counts = Counter(cnaes)
            mais_comuns = counts.most_common()

            # Maior incidência isolada (TOP 1)
            top_cod, top_freq = mais_comuns[0]
            nome_top = NOME_CNAE.get(top_cod, f"Divisão {top_cod}")
            maior_incidencia = f"{top_cod} - {nome_top}"

            # Deriva o Setor e Subsetor DIRETAMENTE da atividade TOP 1
            setor_predominante, subsetor_predominante = classificar_cnae_hierarquico(top_cod)

            top5_cnae_vals = []
            top5_pct_vals = []
            soma_top5_count = 0

            for idx in range(5):
                if idx < len(mais_comuns):
                    cod, qtd = mais_comuns[idx]
                    pct = round((qtd / total) * 100, 2)
                    desc = NOME_CNAE.get(cod, f"Divisão {cod}")

                    top5_cnae_vals.append(f"{cod} - {desc}")
                    top5_pct_vals.append(pct)
                    soma_top5_count += qtd
                else:
                    top5_cnae_vals.append(None)
                    top5_pct_vals.append(0.0)

            outros_pct = round(((total - soma_top5_count) / total) * 100, 2)

        else:
            maior_incidencia = "Sem empresas"
            setor_predominante = "Sem empresas"
            subsetor_predominante = "Sem empresas"
            top5_cnae_vals = [None] * 5
            top5_pct_vals = [0.0] * 5
            outros_pct = 0.0

        feat = QgsFeature()
        if com_geometria:
            feat.setGeometry(info["geometry"])

        attrs = [
            item_id,
            total,
            maior_incidencia,
            setor_predominante,
            subsetor_predominante,
            top5_cnae_vals[0],
            top5_pct_vals[0],
            top5_cnae_vals[1],
            top5_pct_vals[1],
            top5_cnae_vals[2],
            top5_pct_vals[2],
            top5_cnae_vals[3],
            top5_pct_vals[3],
            top5_cnae_vals[4],
            top5_pct_vals[4],
            outros_pct,
        ]

        feat.setAttributes(attrs)
        prov.addFeature(feat)

    mem_layer.commitChanges()
    return mem_layer


# --- 6. EXECUÇÃO ---
# Processa Bairros
dados_bairros = processar_estatisticas(layer_bairros, e_quadra=False)
camada_bairros_out = criar_camada_estatisticas(
    "Estatísticas_CNAE_Bairros",
    dados_bairros,
    "bairro",
    com_geometria=False,
    crs_str=layer_bairros.crs().authid(),
)
project.addMapLayer(camada_bairros_out)

# Processa Quadras
if layer_quadras:
    dados_quadras = processar_estatisticas(layer_quadras, e_quadra=True)
    camada_quadras_out = criar_camada_estatisticas(
        "Estatísticas_CNAE_Quadras",
        dados_quadras,
        "quadra_id",
        com_geometria=True,
        crs_str=layer_quadras.crs().authid(),
    )
    project.addMapLayer(camada_quadras_out)

print("Tabelas atualizadas! O Setor e Subsetor agora refletem a atividade líder (TOP 1).")