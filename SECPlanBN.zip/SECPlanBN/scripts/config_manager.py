# scripts/config_manager.py

import os
import json
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from qgis.utils import iface

from .buscas import carregar_config_buscas, salvar_config_buscas
from .relatorios import carregar_config_relatorios, salvar_config_relatorios
from .documentos import carregar_config_documentos, salvar_config_documentos


def exportar_todas_configuracoes(parent=None):
    """Agrupa todas as configurações dos três módulos e exporta para um arquivo JSON."""
    if parent is None:
        parent = iface.mainWindow()

    dados_backup = {
        "version": "1.0",
        "buscas": carregar_config_buscas(),
        "relatorios": carregar_config_relatorios(),
        "documentos": carregar_config_documentos()
    }

    caminho_arquivo, _ = QFileDialog.getSaveFileName(
        parent,
        "Exportar Backup de Configurações",
        "backup_configuracoes_secplanbn.json",
        "Arquivo JSON (*.json)"
    )

    if not caminho_arquivo:
        return False

    try:
        with open(caminho_arquivo, "w", encoding="utf-8") as f:
            json.dump(dados_backup, f, ensure_ascii=False, indent=4)

        QMessageBox.information(
            parent,
            "Backup Exportado",
            f"Configurações exportadas com sucesso para:\n{caminho_arquivo}"
        )
        return True
    except Exception as e:
        QMessageBox.critical(
            parent,
            "Erro ao Exportar",
            f"Ocorreu um erro ao salvar o arquivo de backup:\n{e}"
        )
        return False


def importar_todas_configuracoes(parent=None):
    """Lê um arquivo JSON de backup e restaura/mescla as configurações nos arquivos TXT."""
    if parent is None:
        parent = iface.mainWindow()

    caminho_arquivo, _ = QFileDialog.getOpenFileName(
        parent,
        "Importar Backup de Configurações",
        "",
        "Arquivo JSON (*.json)"
    )

    if not caminho_arquivo:
        return False

    try:
        with open(caminho_arquivo, "r", encoding="utf-8") as f:
            dados_backup = json.load(f)

        buscas_novas = dados_backup.get("buscas", [])
        relatorios_novos = dados_backup.get("relatorios", [])
        documentos_novos = dados_backup.get("documentos", [])

        # Pergunta ao usuário se deseja sobrescrever ou mesclar
        resposta = QMessageBox.question(
            parent,
            "Modo de Importação",
            "Deseja **Substituir** todas as configurações atuais ou **Mesclar** com as existentes?\n\n"
            "• Sim = Substituir tudo\n"
            "• Não = Mesclar sem duplicar\n"
            "• Cancelar = Abortar importação",
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
            QMessageBox.No
        )

        if resposta == QMessageBox.Cancel:
            return False

        if resposta == QMessageBox.Yes:
            # Substituição completa
            salvar_config_buscas(buscas_novas)
            salvar_config_relatorios(relatorios_novos)
            salvar_config_documentos(documentos_novos)
        else:
            # Mesclagem inteligente sem duplicar
            buscas_atuais = carregar_config_buscas()
            titulos_buscas = {b["titulo"] for b in buscas_atuais}
            for b in buscas_novas:
                if b["titulo"] not in titulos_buscas:
                    buscas_atuais.append(b)
            salvar_config_buscas(buscas_atuais)

            relatorios_atuais = carregar_config_relatorios()
            titulos_relatorios = {r["titulo"] for r in relatorios_atuais}
            for r in relatorios_novos:
                if r["titulo"] not in titulos_relatorios:
                    relatorios_atuais.append(r)
            salvar_config_relatorios(relatorios_atuais)

            documentos_atuais = carregar_config_documentos()
            titulos_documentos = {d["titulo"] for d in documentos_atuais}
            for d in documentos_novos:
                if d["titulo"] not in titulos_documentos:
                    documentos_atuais.append(d)
            salvar_config_documentos(documentos_atuais)

        QMessageBox.information(
            parent,
            "Importação Concluída",
            "Configurações importadas e salvas com sucesso!"
        )
        return True

    except Exception as e:
        QMessageBox.critical(
            parent,
            "Erro ao Importar",
            f"Ocorreu um erro ao carregar o arquivo de backup:\n{e}"
        )
        return False