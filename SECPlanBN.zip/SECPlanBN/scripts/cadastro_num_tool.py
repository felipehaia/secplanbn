import re
import unicodedata
from qgis.core import (
    QgsProject,
    QgsFeature,
    QgsGeometry,
    QgsCoordinateTransform,
    QgsVectorLayerUtils,
    Qgis
)
from qgis.gui import QgsMapToolEmitPoint, QgsAttributeDialog, QgsMapToolPan
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.utils import iface

# --- CONFIGURAÇÕES DAS CAMADAS ---
CAMADA_PONTOS = 'NUMERO_OFICIAIS'
CAMADA_LOTES = 'LOTES-BASE-PLANEJAMENTO'
CAMADA_RUAS = 'gerador_numero'
CAMADA_RUAS_OFICIAIS = 'RUASOFICIAIS'

CAMPO_RUA_LOTE = 'endereco_betha'
CAMPO_NOME_RUA = 'NOME'
CAMPO_NUM_INICIAL = 'NUMERO_INICIAL'

DISTANCIA_MAX_METROS = 35.0

# Variável global para manter a referência da ferramenta ativa na memória
_ferramenta_ativa = None

def remover_acentos(texto):
    if not texto or str(texto) in ['NULL', 'None']:
        return ""
    nfkd = unicodedata.normalize('NFD', str(texto))
    return "".join([c for c in nfkd if not unicodedata.combining(c)])

def normalizar_nome_rua(texto):
    if not texto:
        return ""
    txt = remover_acentos(texto).upper().strip()
    txt = re.sub(r'^(RUA|R\.|AVENIDA|AV\.|RODOVIA|ROD\.|TRAVESSA|TRV\.|ALAMEDA|AL\.|SERVIDAO|SERV\.|PRACA|PRC\.)\s+', '', txt)
    txt = re.sub(r'^(RUA|R\.)\s+', '', txt)
    txt = re.sub(r'[^\w\s]', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return txt.lower()

def identificar_lado_da_rua(geom_rua, ponto_ref, dist_ao_longo_da_rua):
    comprimento_total = geom_rua.length()
    if dist_ao_longo_da_rua + 0.1 > comprimento_total:
        geom_p0 = geom_rua.interpolate(max(0.0, dist_ao_longo_da_rua - 0.1))
        geom_p1 = geom_rua.interpolate(dist_ao_longo_da_rua)
    else:
        geom_p0 = geom_rua.interpolate(dist_ao_longo_da_rua)
        geom_p1 = geom_rua.interpolate(dist_ao_longo_da_rua + 0.1)

    if geom_p0.isEmpty() or geom_p1.isEmpty() or ponto_ref.isEmpty():
        return 'direita'

    p0 = geom_p0.asPoint()
    p1 = geom_p1.asPoint()
    p_lote = ponto_ref.asPoint()

    det = (p1.x() - p0.x()) * (p_lote.y() - p0.y()) - (p1.y() - p0.y()) * (p_lote.x() - p0.x())
    return 'esquerda' if det > 0 else 'direita'


class GeradorNumeroInteractiveTool(QgsMapToolEmitPoint):
    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas

    def canvasReleaseEvent(self, event):
        ponto_clique = self.toMapCoordinates(event.pos())
        
        layers_pontos = QgsProject.instance().mapLayersByName(CAMADA_PONTOS)
        layers_ruas = QgsProject.instance().mapLayersByName(CAMADA_RUAS)
        layers_ruas_oficiais = QgsProject.instance().mapLayersByName(CAMADA_RUAS_OFICIAIS)

        if not layers_pontos or not layers_ruas:
            iface.messageBar().pushMessage(
                "Erro", 
                f"Certifique-se de que '{CAMADA_PONTOS}' e '{CAMADA_RUAS}' estão abertas.", 
                level=Qgis.Warning, duration=5
            )
            return

        layer_ponto = layers_pontos[0]
        layer_rua = layers_ruas[0]
        layer_rua_oficial = layers_ruas_oficiais[0] if layers_ruas_oficiais else None

        crs_canvas = self.canvas.mapSettings().destinationCrs()
        
        def transformar_geom(geom, crs_origem):
            if crs_origem != crs_canvas:
                t = QgsCoordinateTransform(crs_origem, crs_canvas, QgsProject.instance())
                geom.transform(t)
            return geom

        geom_clique = QgsGeometry.fromPointXY(ponto_clique)

        # 1. Encontra a rua mais próxima
        linha_mais_proxima = None
        ponto_projetado = None
        dist_min_rua = float('inf')
        
        tem_campo_num_inicial = CAMPO_NUM_INICIAL in [f.name() for f in layer_rua.fields()]

        for feat in layer_rua.getFeatures():
            g = QgsGeometry(feat.geometry())
            transformar_geom(g, layer_rua.crs())
            
            p_prox = g.nearestPoint(geom_clique)
            dist_m = geom_clique.distance(p_prox)

            if dist_m <= DISTANCIA_MAX_METROS and dist_m < dist_min_rua:
                dist_min_rua = dist_m
                linha_mais_proxima = feat
                ponto_projetado = p_prox

        if not linha_mais_proxima:
            iface.messageBar().pushMessage(
                "Aviso", 
                f"Nenhuma rua encontrada a menos de {DISTANCIA_MAX_METROS}m do clique.", 
                level=Qgis.Warning, duration=4
            )
            return

        geom_rua = QgsGeometry(linha_mais_proxima.geometry())
        transformar_geom(geom_rua, layer_rua.crs())

        # 2. Nome Oficial da rua
        nome_rua_gerador = str(linha_mais_proxima[CAMPO_NOME_RUA]).strip() if linha_mais_proxima[CAMPO_NOME_RUA] not in [None, 'NULL'] else ""
        nome_rua_norm = normalizar_nome_rua(nome_rua_gerador)
        
        nome_oficial = nome_rua_gerador
        if layer_rua_oficial:
            for feat in layer_rua_oficial.getFeatures():
                nome_orig = str(feat[CAMPO_NOME_RUA]).strip() if feat[CAMPO_NOME_RUA] not in [None, 'NULL'] else ""
                if normalizar_nome_rua(nome_orig) == nome_rua_norm:
                    nome_oficial = nome_orig
                    break

        # 3. Distância e Offset
        offset_num = 0
        if tem_campo_num_inicial:
            val_in = linha_mais_proxima[CAMPO_NUM_INICIAL]
            if val_in not in [None, 'NULL', '']:
                try:
                    offset_num = int(val_in)
                except (ValueError, TypeError):
                    offset_num = 0

        distancia_rua = geom_rua.lineLocatePoint(ponto_projetado)
        num_base = round(distancia_rua) + offset_num

        # 4. Regra Par / Ímpar
        lado = identificar_lado_da_rua(geom_rua, geom_clique, distancia_rua)
        if lado == 'esquerda':
            numero_final = num_base if num_base % 2 != 0 else num_base + 1
        else:
            numero_final = num_base if num_base % 2 == 0 else num_base + 1

        # 5. Prepara a Feature com os valores padrão da camada
        layer_ponto.startEditing()
        
        geom_ponto_destino = QgsGeometry.fromPointXY(ponto_clique)
        if crs_canvas != layer_ponto.crs():
            t_ponto = QgsCoordinateTransform(crs_canvas, layer_ponto.crs(), QgsProject.instance())
            geom_ponto_destino.transform(t_ponto)

        nova_feature = QgsVectorLayerUtils.createFeature(
            layer_ponto, 
            geom_ponto_destino
        )

        idx_numero = layer_ponto.fields().indexOf("numero")
        if idx_numero != -1:
            nova_feature.setAttribute(idx_numero, str(numero_final))

        idx_rua = layer_ponto.fields().indexOf("rua")
        if idx_rua != -1:
            nova_feature.setAttribute(idx_rua, nome_oficial)

        # 6. Janela Padrão do QGIS
        dialogo = QgsAttributeDialog(layer_ponto, nova_feature, False, iface.mainWindow(), True)
        dialogo.setWindowTitle("Confirmar e Salvar Ponto Oficial")

        if dialogo.exec_():
            # Adiciona o elemento e força o salvamento automático
            layer_ponto.addFeature(nova_feature)
            layer_ponto.triggerRepaint()
            
            if layer_ponto.commitChanges():
                iface.messageBar().pushMessage(
                    "Sucesso", 
                    f"Ponto cadastrado e salvo com sucesso! Número: {numero_final} | Rua: {nome_oficial}", 
                    level=Qgis.Success, duration=4
                )
            else:
                iface.messageBar().pushMessage(
                    "Erro ao Salvar", 
                    f"Não foi possível salvar automaticamente: {layer_ponto.commitErrors()}", 
                    level=Qgis.Critical, duration=5
                )

            # Redefine o ponteiro para a ferramenta de Pan (mãozinha)
            self.canvas.setMapTool(QgsMapToolPan(self.canvas))
        else:
            # Cancela a edição e reverte alterações pendentes
            layer_ponto.rollBack()
            iface.messageBar().pushMessage(
                "Info", "Cadastro de número cancelado.", level=Qgis.Info, duration=3
            )
            self.canvas.setMapTool(QgsMapToolPan(self.canvas))


def ativar_modo_cadastro():
    global _ferramenta_ativa
    canvas = iface.mapCanvas()
    
    _ferramenta_ativa = GeradorNumeroInteractiveTool(canvas)
    canvas.setMapTool(_ferramenta_ativa)

    QMessageBox.information(
        iface.mainWindow(),
        "Cadastrar Número de Endereço",
        "Modo de captura ativado!\n\nClique no mapa sobre a testada/frente do lote onde deseja criar o ponto de número."
    )

    iface.messageBar().pushMessage(
        "Modo Ativo", 
        "Clique no mapa para cadastrar o ponto de número.", 
        level=Qgis.Info, duration=5
    )