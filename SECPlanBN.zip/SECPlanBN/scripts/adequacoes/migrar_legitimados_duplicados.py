import re
import unicodedata
from collections import defaultdict
from decimal import Decimal
from datetime import datetime

import psycopg2
from psycopg2 import sql
from qgis.core import QgsDataSourceUri, QgsProject, QgsVectorLayer
from qgis.PyQt.QtWidgets import QInputDialog, QLineEdit, QMessageBox


NOME_LOTES = "lotes_reurb"
NOME_LEGITIMADOS = "legitimados_reurb"
NOME_PIVO = "lotes_reurb_legitimados_reurb"


def _nome_tabela(layer):
    if not layer or layer.providerType() != "postgres":
        return ""
    return QgsDataSourceUri(layer.source()).table().lower()


def _camada_por_tabela(nome):
    correspondencias = [
        layer
        for layer in QgsProject.instance().mapLayers().values()
        if isinstance(layer, QgsVectorLayer) and _nome_tabela(layer) == nome
    ]
    return correspondencias[0] if len(correspondencias) == 1 else None


def _chave_primaria(layer):
    uri = QgsDataSourceUri(layer.source())
    chave = uri.keyColumn()
    if not chave or "," in chave or layer.fields().indexFromName(chave) < 0:
        raise RuntimeError(f"Não consegui determinar a chave primária simples de {layer.name()}.")
    return chave


def _identificador(texto):
    texto = unicodedata.normalize("NFKD", str(texto or ""))
    texto = "".join(caractere for caractere in texto if not unicodedata.combining(caractere))
    return "".join(caractere.casefold() for caractere in texto if caractere.isalnum())


def _chave_valor(valor):
    if valor is None:
        return None
    texto = str(valor).strip()
    if not texto:
        return None
    if re.fullmatch(r"[+-]?\d+", texto):
        return "numero", int(texto)
    try:
        return "numero", Decimal(texto).normalize()
    except Exception:
        return "texto", texto.casefold()


def _ordenar_id(valor):
    try:
        return 0, Decimal(str(valor))
    except Exception:
        return 1, str(valor)


def _mesma_conexao(uri_a, uri_b):
    return (
        uri_a.service(),
        uri_a.host(),
        uri_a.port(),
        uri_a.database(),
    ) == (
        uri_b.service(),
        uri_b.host(),
        uri_b.port(),
        uri_b.database(),
    )


def _relacoes_da_pivo(layer_pai, camada_pivo):
    return [
        relation
        for relation in QgsProject.instance().relationManager().relations().values()
        if relation.isValid()
        and relation.referencedLayerId() == layer_pai.id()
        and relation.referencingLayerId() == camada_pivo.id()
    ]


def _ler_registros(cursor, schema, table, fields):
    query = sql.SQL("SELECT {} FROM {}").format(
        sql.SQL(", ").join(sql.Identifier(field) for field in fields),
        sql.Identifier(schema, table),
    )
    cursor.execute(query)
    return cursor.fetchall()


def _criar_backup(cursor, schema, table, campo, ids, nome_backup):
    if not ids:
        return None
    origem = sql.Identifier(schema, table)
    backup = sql.Identifier(schema, nome_backup)
    coluna = sql.Identifier(campo)
    cursor.execute(
        sql.SQL("CREATE TABLE {} AS SELECT * FROM {} WHERE FALSE").format(backup, origem)
    )
    for valor in ids:
        cursor.execute(
            sql.SQL("INSERT INTO {} SELECT * FROM {} WHERE {} = %s").format(
                backup,
                origem,
                coluna,
            ),
            (valor,),
        )
    return f"{schema}.{nome_backup}"


def _planejar_migracao(cursor, configuracao):
    cursor.execute(
        """
        SELECT is_nullable
        FROM information_schema.columns
        WHERE table_schema = %s AND table_name = %s AND column_name = %s
        """,
        (
            configuracao["legitimados"]["schema"],
            configuracao["legitimados"]["table"],
            "id_lote_reurb",
        ),
    )
    nullable = cursor.fetchone()
    if not nullable:
        raise RuntimeError("Não encontrei legitimados_reurb.id_lote_reurb no banco.")

    legit_rows = _ler_registros(
        cursor,
        configuracao["legitimados"]["schema"],
        configuracao["legitimados"]["table"],
        [
            configuracao["legitimados"]["pk"],
            "nome",
            "dados_proprietario",
            "id_lote_reurb",
        ],
    )
    lote_rows = _ler_registros(
        cursor,
        configuracao["lotes"]["schema"],
        configuracao["lotes"]["table"],
        [configuracao["lotes"]["pk"]],
    )
    pivo_rows = _ler_registros(
        cursor,
        configuracao["pivo"]["schema"],
        configuracao["pivo"]["table"],
        [configuracao["pivo"]["fk_lote"], configuracao["pivo"]["fk_legitimado"]],
    )

    lotes_por_chave = {}
    for (id_lote,) in lote_rows:
        chave = _chave_valor(id_lote)
        if chave in lotes_por_chave and lotes_por_chave[chave] != id_lote:
            raise RuntimeError(
                f"A chave do lote '{id_lote}' é ambígua após normalização; migração cancelada."
            )
        lotes_por_chave[chave] = id_lote

    legitimados_por_chave = {}
    grupos = defaultdict(list)
    for id_legitimado, nome, dados, id_lote_antigo in legit_rows:
        chave_legitimado = _chave_valor(id_legitimado)
        if chave_legitimado in legitimados_por_chave:
            raise RuntimeError("A chave primária de legitimado não é única.")
        legitimados_por_chave[chave_legitimado] = id_legitimado
        chave_pessoa = (_identificador(nome), _identificador(dados))
        if all(chave_pessoa):
            grupos[chave_pessoa].append((id_legitimado, nome, id_lote_antigo))

    sobrevivente_por_chave = {
        chave: id_legitimado
        for chave, id_legitimado in legitimados_por_chave.items()
    }
    duplicados = []
    grupos_duplicados = []
    for registros in grupos.values():
        if len(registros) < 2:
            continue
        registros.sort(key=lambda item: _ordenar_id(item[0]))
        sobrevivente = registros[0][0]
        removidos = [registro[0] for registro in registros[1:]]
        grupos_duplicados.append((registros[0][1], sobrevivente, removidos))
        duplicados.extend(removidos)
        for id_removido in removidos:
            sobrevivente_por_chave[_chave_valor(id_removido)] = sobrevivente

    pares_desejados = set()
    for id_legitimado, _nome, _dados, id_lote_antigo in legit_rows:
        if id_lote_antigo is None or not str(id_lote_antigo).strip():
            continue
        chave_lote = _chave_valor(id_lote_antigo)
        if chave_lote not in lotes_por_chave:
            raise RuntimeError(
                f"O legitimado {id_legitimado} referencia o lote '{id_lote_antigo}', "
                "que não foi encontrado pela chave primária da camada lotes_reurb. "
                "Nenhuma alteração foi feita."
            )
        id_lote = lotes_por_chave[chave_lote]
        id_legitimado_final = sobrevivente_por_chave[_chave_valor(id_legitimado)]
        pares_desejados.add((_chave_valor(id_lote), _chave_valor(id_legitimado_final), id_lote, id_legitimado_final))

    ids_validos = set(legitimados_por_chave)
    for id_lote, id_legitimado in pivo_rows:
        chave_legitimado = _chave_valor(id_legitimado)
        if chave_legitimado not in ids_validos:
            raise RuntimeError(
                f"A tabela pivô aponta para o legitimado inexistente '{id_legitimado}'. "
                "Nenhuma alteração foi feita."
            )
        chave_lote = _chave_valor(id_lote)
        if chave_lote not in lotes_por_chave:
            raise RuntimeError(
                f"A tabela pivô aponta para o lote inexistente '{id_lote}'. "
                "Nenhuma alteração foi feita."
            )
        id_lote_final = lotes_por_chave[chave_lote]
        id_legitimado_final = sobrevivente_por_chave[chave_legitimado]
        pares_desejados.add(
            (
                _chave_valor(id_lote_final),
                _chave_valor(id_legitimado_final),
                id_lote_final,
                id_legitimado_final,
            )
        )

    pares_existentes = {
        (_chave_valor(id_lote), _chave_valor(id_legitimado))
        for id_lote, id_legitimado in pivo_rows
    }
    pares_para_inserir = [
        (id_lote, id_legitimado)
        for chave_lote, chave_legitimado, id_lote, id_legitimado in pares_desejados
        if (chave_lote, chave_legitimado) not in pares_existentes
    ]
    return {
        "duplicados": duplicados,
        "grupos_duplicados": grupos_duplicados,
        "pares_para_inserir": pares_para_inserir,
        "tornar_legado_opcional": nullable[0] == "NO",
    }


def _configurar():
    lotes = _camada_por_tabela(NOME_LOTES)
    legitimados = _camada_por_tabela(NOME_LEGITIMADOS)
    if not lotes or not legitimados:
        raise RuntimeError(
            "Carregue exatamente uma camada PostgreSQL de lotes_reurb e uma de "
            "legitimados_reurb no projeto QGIS."
        )

    uri_lotes = QgsDataSourceUri(lotes.source())
    uri_legitimados = QgsDataSourceUri(legitimados.source())
    if not _mesma_conexao(uri_lotes, uri_legitimados):
        raise RuntimeError("As camadas de lotes e legitimados precisam usar a mesma conexão PostgreSQL.")

    relacao_lote = None
    camada_pivo = None
    for relation in QgsProject.instance().relationManager().relations().values():
        if not relation.isValid() or relation.referencedLayerId() != lotes.id():
            continue
        candidate = relation.referencingLayer()
        if candidate and _nome_tabela(candidate) == NOME_PIVO:
            relacao_lote = relation
            camada_pivo = candidate
            break
    if not relacao_lote or not camada_pivo:
        raise RuntimeError(
            "Não encontrei no projeto QGIS a relação de lotes_reurb com "
            "lotes_reurb_legitimados_reurb."
        )

    relacoes_legitimado = _relacoes_da_pivo(legitimados, camada_pivo)
    if len(relacoes_legitimado) != 1:
        raise RuntimeError(
            "Não encontrei uma relação QGIS válida entre legitimados_reurb e "
            "lotes_reurb_legitimados_reurb."
        )
    uri_pivo = QgsDataSourceUri(camada_pivo.source())
    if not _mesma_conexao(uri_lotes, uri_pivo):
        raise RuntimeError("A tabela pivô precisa estar na mesma conexão PostgreSQL das camadas REURB.")

    pares_lote = dict(relacao_lote.fieldPairs())
    pares_legitimado = dict(relacoes_legitimado[0].fieldPairs())
    if len(pares_lote) != 1 or len(pares_legitimado) != 1:
        raise RuntimeError("As relações da tabela pivô precisam ter uma única chave cada.")
    fk_lote, pk_lote = next(iter(pares_lote.items()))
    fk_legitimado, pk_legitimado = next(iter(pares_legitimado.items()))
    if pk_lote != _chave_primaria(lotes) or pk_legitimado != _chave_primaria(legitimados):
        raise RuntimeError("As relações do projeto não apontam para as chaves primárias esperadas.")

    campos_legitimado = {field.name() for field in legitimados.fields()}
    for campo in ("nome", "dados_proprietario", "id_lote_reurb"):
        if campo not in campos_legitimado:
            raise RuntimeError(f"A camada legitimados_reurb não possui o campo '{campo}'.")

    camadas = (lotes, legitimados, camada_pivo)
    if any(layer.isEditable() for layer in camadas):
        raise RuntimeError(
            "Finalize ou descarte a edição das camadas de lotes, legitimados e tabela pivô antes da migração."
        )

    return {
        "lotes_layer": lotes,
        "legitimados_layer": legitimados,
        "pivo_layer": camada_pivo,
        "lotes": {
            "schema": uri_lotes.schema() or "public",
            "table": uri_lotes.table(),
            "pk": pk_lote,
        },
        "legitimados": {
            "schema": uri_legitimados.schema() or "public",
            "table": uri_legitimados.table(),
            "pk": pk_legitimado,
        },
        "pivo": {
            "schema": uri_pivo.schema() or "public",
            "table": uri_pivo.table(),
            "fk_lote": fk_lote,
            "fk_legitimado": fk_legitimado,
        },
        "uri": uri_legitimados,
    }


def executar():
    try:
        configuracao = _configurar()
    except Exception as erro:
        QMessageBox.critical(None, "Migração de legitimados", str(erro))
        return

    uri = configuracao["uri"]
    usuario = uri.username()
    if not usuario:
        usuario, ok = QInputDialog.getText(
            None,
            "Conexão PostgreSQL",
            "Usuário do banco:",
            QLineEdit.Normal,
        )
        if not ok or not usuario:
            return
    senha, ok = QInputDialog.getText(
        None,
        "Conexão PostgreSQL",
        f"Senha do usuário '{usuario}':",
        QLineEdit.Password,
    )
    if not ok:
        return

    parametros = {
        "dbname": uri.database(),
        "user": usuario,
        "password": senha,
        "connect_timeout": 10,
    }
    if uri.service():
        parametros["service"] = uri.service()
    else:
        parametros["host"] = uri.host() or "localhost"
        parametros["port"] = uri.port() or "5432"

    conexao = None
    transacao_confirmada = False
    try:
        conexao = psycopg2.connect(**parametros)
        with conexao.cursor() as cursor:
            plano = _planejar_migracao(cursor, configuracao)

            if (
                not plano["duplicados"]
                and not plano["pares_para_inserir"]
                and not plano["tornar_legado_opcional"]
            ):
                QMessageBox.information(
                    None,
                    "Migração de legitimados",
                    "Nenhum legitimado duplicado ou vínculo antigo pendente foi encontrado.",
                )
                conexao.rollback()
                return

            linhas = [
                f"- {nome or '(sem nome)'}: mantém ID {mantido}; "
                f"remove {', '.join(map(str, removidos))}"
                for nome, mantido, removidos in plano["grupos_duplicados"][:12]
            ]
            if len(plano["grupos_duplicados"]) > 12:
                linhas.append(f"- ... e mais {len(plano['grupos_duplicados']) - 12} grupos.")
            resumo = (
                f"Grupos duplicados: {len(plano['grupos_duplicados'])}\n"
                f"Registros que serão removidos: {len(plano['duplicados'])}\n"
                f"Vínculos N:M novos: {len(plano['pares_para_inserir'])}\n\n"
                "Se houver duplicados, o script cria cópias das feições e dos vínculos "
                "antigos em tabelas de backup no mesmo schema.\n\n"
                + (
                    "O campo legado id_lote_reurb será tornado opcional para permitir "
                    "novos cadastros sem esse vínculo.\n\n"
                    if plano["tornar_legado_opcional"]
                    else ""
                )
                +
                "A identificação de duplicados exige nome e dados do proprietário iguais "
                "após normalizar caixa, acentos, espaços e pontuação. Em cada grupo, "
                "o registro com menor ID será mantido.\n\n"
                + ("\n".join(linhas) if linhas else "Nenhum grupo duplicado.")
                + "\n\nA operação altera legitimados e a tabela pivô em uma única transação PostgreSQL."
            )
            resposta = QMessageBox.question(
                None,
                "Confirmar migração de legitimados",
                resumo,
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if resposta != QMessageBox.Yes:
                conexao.rollback()
                return

            sufixo = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_legitimados = _criar_backup(
                cursor,
                configuracao["legitimados"]["schema"],
                configuracao["legitimados"]["table"],
                configuracao["legitimados"]["pk"],
                plano["duplicados"],
                f"backup_legitimados_{sufixo}",
            )
            backup_pivo = _criar_backup(
                cursor,
                configuracao["pivo"]["schema"],
                configuracao["pivo"]["table"],
                configuracao["pivo"]["fk_legitimado"],
                plano["duplicados"],
                f"backup_vinculos_legitimados_{sufixo}",
            )

            tabela_pivo = sql.Identifier(configuracao["pivo"]["schema"], configuracao["pivo"]["table"])
            coluna_lote = sql.Identifier(configuracao["pivo"]["fk_lote"])
            coluna_legitimado = sql.Identifier(configuracao["pivo"]["fk_legitimado"])
            inseridos = 0
            for id_lote, id_legitimado in plano["pares_para_inserir"]:
                cursor.execute(
                    sql.SQL(
                        "INSERT INTO {} ({}, {}) VALUES (%s, %s) ON CONFLICT DO NOTHING"
                    ).format(tabela_pivo, coluna_lote, coluna_legitimado),
                    (id_lote, id_legitimado),
                )
                inseridos += cursor.rowcount

            tabela_legitimados = sql.Identifier(
                configuracao["legitimados"]["schema"],
                configuracao["legitimados"]["table"],
            )
            coluna_pk_legitimado = sql.Identifier(configuracao["legitimados"]["pk"])
            removidos_pivo = 0
            for id_legitimado in plano["duplicados"]:
                cursor.execute(
                    sql.SQL("DELETE FROM {} WHERE {} = %s").format(
                        tabela_pivo,
                        coluna_legitimado,
                    ),
                    (id_legitimado,),
                )
                removidos_pivo += cursor.rowcount

            for id_legitimado in plano["duplicados"]:
                cursor.execute(
                    sql.SQL("DELETE FROM {} WHERE {} = %s").format(
                        tabela_legitimados,
                        coluna_pk_legitimado,
                    ),
                    (id_legitimado,),
                )
                if cursor.rowcount != 1:
                    raise RuntimeError(
                        f"Não foi possível remover exatamente um registro duplicado (ID {id_legitimado})."
                    )

            if plano["tornar_legado_opcional"]:
                cursor.execute(
                    sql.SQL("ALTER TABLE {} ALTER COLUMN {} DROP NOT NULL").format(
                        sql.Identifier(
                            configuracao["legitimados"]["schema"],
                            configuracao["legitimados"]["table"],
                        ),
                        sql.Identifier("id_lote_reurb"),
                    )
                )

        conexao.commit()
        transacao_confirmada = True
        try:
            configuracao["legitimados_layer"].reload()
            configuracao["pivo_layer"].reload()
        except Exception as erro:
            QMessageBox.warning(
                None,
                "Migração concluída",
                f"As alterações foram confirmadas no banco, mas não consegui atualizar "
                f"as camadas no QGIS. Recarregue-as manualmente.\n\n{erro}",
            )
            return
        QMessageBox.information(
            None,
            "Migração concluída",
            f"Registros duplicados removidos: {len(plano['duplicados'])}\n"
            f"Vínculos N:M inseridos: {inseridos}\n"
            f"Vínculos antigos dos duplicados substituídos: {removidos_pivo}\n\n"
            f"Backups: {backup_legitimados or 'nenhum'}; {backup_pivo or 'nenhum'}",
        )
    except Exception as erro:
        if conexao and not transacao_confirmada:
            conexao.rollback()
        QMessageBox.critical(
            None,
            "Falha na migração de legitimados",
            (
                f"As alterações já foram confirmadas no banco; atualize as camadas no QGIS. "
                f"Detalhes:\n{erro}"
                if transacao_confirmada
                else f"Nenhuma alteração foi confirmada. Detalhes:\n{erro}"
            ),
        )
    finally:
        if conexao:
            conexao.close()


executar()
