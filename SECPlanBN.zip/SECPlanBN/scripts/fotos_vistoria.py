import os
from qgis.core import (
    QgsProject,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox, QAction
from qgis.PyQt.QtGui import QIcon

from PIL import Image
try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except ImportError:
    pass


class PluginVistoriaFotos:

    def __init__(self, iface):
        self.iface = iface
        self.nome_camada = "VISTORIAS_FOTOS"
        self.action = None

    def initGui(self):
        """Cria o botão na barra de ferramentas e no menu do QGIS."""
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Importar Fotos de Vistoria (HEIC/JPG)", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        # Adiciona ao menu 'Vetor' e à barra de ferramentas do QGIS
        self.iface.addPluginToVectorMenu("Vistoria Fotos", self.action)
        self.iface.addVectorToolBarIcon(self.action)

    def unload(self):
        """Remove o botão do menu e da barra de ferramentas ao desativar o plugin."""
        self.iface.removePluginVectorMenu("Vistoria Fotos", self.action)
        self.iface.removeVectorToolBarIcon(self.action)

    def dms_para_decimal(self, dms, ref):
        """Converte a tupla Exif/PIL (Graus, Minutos, Segundos) em Graus Decimais."""
        try:
            d = float(dms[0])
            m = float(dms[1])
            s = float(dms[2])

            decimal = d + (m / 60.0) + (s / 3600.0)

            if str(ref).upper() in ['S', 'W']:
                decimal = -decimal

            return decimal
        except Exception:
            return None

    def extrair_gps_heic(self, caminho_arquivo):
        """Lê arquivos HEIC/JPG usando PIL e extrai as coordenadas EXIF."""
        try:
            with Image.open(caminho_arquivo) as img:
                exif_data = img.getexif()
                if not exif_data:
                    return None

                gps_info = exif_data.get_ifd(0x8825)
                if not gps_info:
                    return None

                lat_dms = gps_info.get(2)
                lat_ref = gps_info.get(1)
                lon_dms = gps_info.get(4)
                lon_ref = gps_info.get(3)

                if not lat_dms or not lon_dms:
                    return None

                lat = self.dms_para_decimal(lat_dms, lat_ref)
                lon = self.dms_para_decimal(lon_dms, lon_ref)

                return lat, lon

        except Exception as e:
            print(f"Erro ao extrair GPS de {os.path.basename(caminho_arquivo)}: {e}")
            return None

    def converter_para_jpeg(self, caminho_origem, pasta_destino):
        """Converte HEIC/outras imagens para JPEG e salva na pasta DCIM do projeto."""
        try:
            nome_base = os.path.splitext(os.path.basename(caminho_origem))[0]
            nome_jpeg = f"{nome_base}.jpg"
            caminho_destino = os.path.join(pasta_destino, nome_jpeg)

            with Image.open(caminho_origem) as img:
                img_rgb = img.convert("RGB")
                img_rgb.save(caminho_destino, "JPEG", quality=95)

            return caminho_destino, nome_jpeg
        except Exception as e:
            print(f"Erro ao converter imagem {os.path.basename(caminho_origem)}: {e}")
            return None, None

    def run(self):
        """Executa a lógica principal do plugin."""
        # 1. Validação do Projeto e Pasta DCIM
        caminho_projeto = QgsProject.instance().fileName()
        if not caminho_projeto:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Erro",
                "Salve o projeto do QGIS (.qgz / .qgs) antes de executar a importação."
            )
            return

        pasta_projeto = os.path.dirname(caminho_projeto)
        pasta_dcim = os.path.join(pasta_projeto, "DCIM")

        if not os.path.exists(pasta_dcim):
            os.makedirs(pasta_dcim)

        # 2. Validação da Camada
        camadas = QgsProject.instance().mapLayersByName(self.nome_camada)
        if not camadas:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Erro",
                f"A camada '{self.nome_camada}' não está aberta no projeto."
            )
            return

        camada = camadas[0]

        # 3. Seleção de Arquivos
        arquivos_selecionados, _ = QFileDialog.getOpenFileNames(
            self.iface.mainWindow(),
            "Selecione as fotos para importar",
            "",
            "Imagens (*.heic *.HEIC *.heif *.HEIF *.jpg *.jpeg *.JPG *.JPEG);;Todos os Arquivos (*)"
        )

        if not arquivos_selecionados:
            return

        # 4. Garante que o campo FOTO exista na camada
        camada.startEditing()
        fields = camada.fields()

        if fields.indexOf("FOTO") == -1:
            camada.addAttribute(QgsField("FOTO", QVariant.String))

        camada.updateFields()
        idx_foto = camada.fields().indexOf("FOTO")

        # Transformação de coordenadas (WGS84 para CRS da camada)
        crs_wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        crs_camada = camada.crs()
        transformador = QgsCoordinateTransform(crs_wgs84, crs_camada, QgsProject.instance())

        total_criados = 0
        sem_gps = 0

        # 5. Loop de Processamento
        for caminho_origem in arquivos_selecionados:
            coords = self.extrair_gps_heic(caminho_origem)

            if not coords or coords[0] is None or coords[1] is None:
                sem_gps += 1
                continue

            lat, lon = coords

            # Converte foto para JPEG na pasta DCIM
            caminho_jpeg, nome_jpeg = self.converter_para_jpeg(caminho_origem, pasta_dcim)
            if not caminho_jpeg:
                continue

            # Projeta coordenadas WGS84 para o CRS da camada
            ponto_wgs84 = QgsPointXY(lon, lat)
            ponto_reprojetado = transformador.transform(ponto_wgs84)

            # Calcula o caminho relativo nativo em relação à pasta do projeto
            caminho_relativo = os.path.relpath(caminho_jpeg, pasta_projeto).replace("\\", "/")

            # Adiciona feição na camada
            nova_feicao = QgsFeature(camada.fields())
            nova_feicao.setGeometry(QgsGeometry.fromPointXY(ponto_reprojetado))
            nova_feicao.setAttribute(idx_foto, caminho_relativo)

            camada.addFeature(nova_feicao)
            total_criados += 1

        camada.commitChanges()

        # Mensagem final para o utilizador
        QMessageBox.information(
            self.iface.mainWindow(),
            "Concluído",
            f"Importação finalizada!\n\n"
            f"• Pontos criados: {total_criados}\n"
            f"• Fotos sem GPS ignoradas: {sem_gps}\n"
            f"• Pasta das fotos: DCIM/"
        )