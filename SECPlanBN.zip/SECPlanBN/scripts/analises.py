# scripts/analises.py

import os
import re
import json
import math
import zipfile
import shutil
import subprocess
import sys
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import date, datetime, timedelta

from qgis.core import (
    QgsProject, QgsMapLayerType, QgsFeature, QgsApplication
)
from qgis.utils import iface
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QComboBox,
    QListWidget, QPushButton, QFormLayout, QMessageBox, QFileDialog,
    QDialogButtonBox, QTextEdit, QCheckBox, QTabWidget,
    QGroupBox, QScrollArea, QWidget, QRadioButton, QInputDialog
)

# ==============================================================================
# GESTÃO DE CAMINHOS E PASTAS DO USUÁRIO (PERFIL DO QGIS - MULTIPLATAFORMA)
# ==============================================================================
PASTA_PERFIL_QGIS = QgsApplication.qgisSettingsDirPath()
PASTA_DADOS_PLUGIN = os.path.join(PASTA_PERFIL_QGIS, "SECPlanBN_Data")

CONFIG_ANALISES_PATH = os.path.join(PASTA_DADOS_PLUGIN, "config_analises.txt")
PASTA_SESSIONS_ANALISE = os.path.join(PASTA_DADOS_PLUGIN, "sessoes_analise")
PASTA_CHECKLISTS = os.path.join(PASTA_DADOS_PLUGIN, "checklists")
PASTA_MODELOS_DOC = os.path.join(PASTA_DADOS_PLUGIN, "modelos_doc")
_CACHE_SERIE_INCC = {}

os.makedirs(PASTA_SESSIONS_ANALISE, exist_ok=True)
os.makedirs(PASTA_CHECKLISTS, exist_ok=True)
os.makedirs(PASTA_MODELOS_DOC, exist_ok=True)


# ==============================================================================
# CARREGAMENTO DINÂMICO DE DEPENDÊNCIAS
# ==============================================================================

def obter_docx_template():
    """Importa o DocxTemplate dinamicamente ou tenta instalar via pip caso não exista."""
    try:
        from docxtpl import DocxTemplate
        return DocxTemplate
    except ImportError:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "docxtpl"])
            from docxtpl import DocxTemplate
            return DocxTemplate
        except Exception as e:
            raise ImportError(
                "A biblioteca 'docxtpl' é necessária para gerar relatórios Word.\n"
                "Instale-a executando no terminal OSGeo4W:\n"
                "python -m pip install docxtpl"
            ) from e


def _sanitizar_nome_var(texto):
    """
    Remove acentos, caracteres especiais, espaços e converte '->' em '__'
    para garantir que a variável seja compatível com a sintaxe do Jinja2 e eval.
    """
    if not texto:
        return "item"
    texto = texto.replace("->", "__")
    nfkd = unicodedata.normalize('NFKD', texto)
    sem_acento = "".join([c for c in nfkd if not unicodedata.combining(c)])
    limpo = re.sub(r'[^a-zA-Z0-9_]', '_', sem_acento).lower()
    limpo = re.sub(r'_+', '_', limpo).strip('_')
    return limpo or "item"


def _limpar_quebras_linha(texto):
    """Converte quebras de linha e separadores de parágrafo em espaços."""
    return re.sub(r'[\r\n\t\v\f\x1c-\x1e\x85\u2028\u2029]+', ' ', str(texto)).strip()


class ErroCorrecaoINCC(Exception):
    pass


def _converter_decimal_incc(valor):
    texto = str(valor).strip().replace("R$", "").replace("\xa0", "").replace(" ", "")
    if not texto:
        raise ErroCorrecaoINCC("O valor a corrigir está vazio.")
    if "," in texto:
        texto = texto.replace(".", "").replace(",", ".")
    elif texto.count(".") > 1:
        partes = texto.split(".")
        texto = "".join(partes[:-1]) + "." + partes[-1]
    try:
        return float(texto)
    except ValueError as erro:
        raise ErroCorrecaoINCC(f"Valor inválido para correção: {valor}") from erro


def _converter_data_incc(valor):
    if isinstance(valor, datetime):
        return valor.date()
    if isinstance(valor, date):
        return valor
    texto = str(valor).strip()
    for formato in ("%d/%m/%Y", "%Y-%m-%d", "%m/%Y", "%m-%Y", "%Y-%m"):
        try:
            data = datetime.strptime(texto, formato).date()
            return data.replace(day=1)
        except ValueError:
            continue
    raise ErroCorrecaoINCC(
        f"Data-base inválida: '{valor}'. Use DD/MM/AAAA ou AAAA-MM-DD."
    )


def _obter_serie_incc(data_inicio, data_fim):
    dados = {}
    primeiro_ano = data_inicio.year
    while primeiro_ano <= data_fim.year:
        ultimo_ano = min(primeiro_ano + 8, data_fim.year)
        chave_cache = (
            primeiro_ano, ultimo_ano,
            data_inicio.year, data_inicio.month,
            data_fim.year, data_fim.month
        )
        entrada_cache = _CACHE_SERIE_INCC.get(chave_cache)
        if entrada_cache and datetime.now() - entrada_cache["consultado_em"] < timedelta(hours=12):
            dados.update(entrada_cache["dados"])
        else:
            inicio_trecho = date(primeiro_ano, 1, 1)
            fim_trecho = min(date(ultimo_ano, 12, 31), data_fim)
            parametros = urllib.parse.urlencode({
                "formato": "json",
                "dataInicial": inicio_trecho.strftime("%d/%m/%Y"),
                "dataFinal": fim_trecho.strftime("%d/%m/%Y")
            })
            url = (
                "https://api.bcb.gov.br/dados/serie/bcdata.sgs.192/dados?"
                f"{parametros}"
            )
            requisicao = urllib.request.Request(
                url,
                headers={"Accept": "application/json", "User-Agent": "SECPlanBN/QGIS"}
            )
            try:
                with urllib.request.urlopen(requisicao, timeout=10) as resposta:
                    registros = json.loads(resposta.read().decode("utf-8"))
            except (urllib.error.URLError, TimeoutError, OSError, UnicodeDecodeError, json.JSONDecodeError) as erro:
                raise ErroCorrecaoINCC(
                    f"Não foi possível consultar a série INCC do Banco Central: {erro}"
                ) from erro

            if not isinstance(registros, list):
                raise ErroCorrecaoINCC("A API do Banco Central retornou dados inválidos para o INCC.")

            dados_trecho = {}
            try:
                for registro in registros:
                    mes = datetime.strptime(registro["data"], "%d/%m/%Y").date()
                    dados_trecho[(mes.year, mes.month)] = float(registro["valor"])
            except (KeyError, TypeError, ValueError) as erro:
                raise ErroCorrecaoINCC(
                    "A resposta da API do Banco Central contém um registro INCC inválido."
                ) from erro

            _CACHE_SERIE_INCC[chave_cache] = {
                "consultado_em": datetime.now(),
                "dados": dados_trecho
            }
            dados.update(dados_trecho)
        primeiro_ano = ultimo_ano + 1
    return dados


def _corrigir_valor_incc(valor, data_base, variaveis=None, data_atual=None):
    if isinstance(valor, str) and variaveis is not None and valor.strip() in variaveis:
        valor = variaveis[valor.strip()]
    valor = _converter_decimal_incc(valor)
    if not math.isfinite(valor):
        raise ErroCorrecaoINCC("O valor a corrigir precisa ser um número finito.")
    data_base = _converter_data_incc(data_base)
    data_atual = data_atual or date.today()

    mes_base = (data_base.year, data_base.month)
    if data_base > data_atual:
        raise ErroCorrecaoINCC("A data-base não pode estar no futuro.")

    primeiro_mes = date(data_base.year + (data_base.month == 12), data_base.month % 12 + 1, 1)
    serie = _obter_serie_incc(primeiro_mes, data_atual)
    meses_validos = sorted(
        mes for mes in serie
        if (primeiro_mes.year, primeiro_mes.month) <= mes <= (data_atual.year, data_atual.month)
    )
    if not meses_validos:
        if (data_base.year, data_base.month) == (data_atual.year, data_atual.month):
            serie_mes_base = _obter_serie_incc(data_base.replace(day=1), data_atual)
            if mes_base in serie_mes_base:
                return round(valor, 2)
            raise ErroCorrecaoINCC(
                f"O índice INCC de {data_base.strftime('%m/%Y')} ainda não foi publicado; "
                "não é possível corrigir o valor até essa data."
            )
        raise ErroCorrecaoINCC("A API não retornou índices INCC para o período solicitado.")

    mes_esperado = primeiro_mes
    for ano, mes in meses_validos:
        data_mes = date(ano, mes, 1)
        if data_mes != mes_esperado:
            raise ErroCorrecaoINCC(
                f"A série INCC não possui o índice de {mes_esperado.strftime('%m/%Y')}."
            )
        mes_esperado = date(ano + (mes == 12), mes % 12 + 1, 1)

    ultimo_mes_publicado = date(*meses_validos[-1], 1)
    if ultimo_mes_publicado < date(data_atual.year, data_atual.month, 1):
        serie_atual = _obter_serie_incc(ultimo_mes_publicado, data_atual)
        meses_mais_recentes = [
            mes for mes in serie_atual
            if mes > meses_validos[-1]
            and mes <= (data_atual.year, data_atual.month)
        ]
        if meses_mais_recentes:
            raise ErroCorrecaoINCC(
                f"A série INCC está incompleta após {ultimo_mes_publicado.strftime('%m/%Y')}."
            )

    fator = 1.0
    for mes in meses_validos:
        fator *= 1 + serie[mes] / 100
    valor_corrigido = valor * fator
    if not math.isfinite(valor_corrigido):
        raise ErroCorrecaoINCC("O resultado da correção INCC é inválido.")
    return round(valor_corrigido, 2)


# ==============================================================================
# PERSISTÊNCIA DE CONFIGURAÇÕES E LEITURA DO CHECKLIST
# ==============================================================================

def carregar_config_analises():
    """Lê as configurações de análise salvas no arquivo TXT do plugin."""
    analises = []
    if not os.path.exists(CONFIG_ANALISES_PATH):
        return analises

    with open(CONFIG_ANALISES_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and "|" in line:
                partes = line.split("|")
                if len(partes) >= 8:
                    item = {
                        "titulo": partes[0].strip(),
                        "camada": partes[1].strip(),
                        "template_deferido": partes[2].strip(),
                        "template_indeferido": partes[3].strip(),
                        "checklist_path": partes[4].strip(),
                        "tecnico_nome": partes[5].strip(),
                        "tecnico_cargo": partes[6].strip(),
                        "tecnico_linha_add": partes[7].strip(),
                        "etapa": partes[8].strip() if len(partes) > 8 else "",
                        "rel_mestre": partes[9].strip() if len(partes) > 9 else ""
                    }
                    analises.append(item)
    return analises


def salvar_config_analises(analises):
    """Grava a lista de configurações de análise no arquivo TXT do plugin."""
    linhas = []
    for a in analises:
        linha = (
            f"{a['titulo']}|{a['camada']}|{a['template_deferido']}|"
            f"{a['template_indeferido']}|{a['checklist_path']}|"
            f"{a['tecnico_nome']}|{a['tecnico_cargo']}|"
            f"{a['tecnico_linha_add']}|{a.get('etapa', '')}|{a.get('rel_mestre', '')}"
        )
        linhas.append(linha)
    with open(CONFIG_ANALISES_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(linhas))


def ler_arquivo_checklist_txt(path_txt):
    """
    Lê o arquivo de checklist estruturado em seções.
    Suporta [CAMADA_PRINCIPAL], [ABA: Nome da Aba] e [RELACAO: ...]
    Tipos de campos:
    - * : Campo digitável simples.
    - + : Campo adicionável com colunas (ex: + APPs > Número, Área).
    - = : Campo calculado com fórmula (ex: = Área Útil | area_total - apps).
    - ^ : Campo de seleção de arquivo local (ex: ^ Projeto Urbanístico | DOC-01 - Projeto Urbanístico).
    """
    checklists = {
        "CAMADA_PRINCIPAL": [],
        "ABAS_CUSTOM": {},
        "RELACOES": {},
        "NOMES_ABAS": {},
        "CAMPOS_ROTULO": {}
    }
    if not os.path.exists(path_txt):
        return checklists

    secao_tipo = "CAMADA_PRINCIPAL"
    secao_chave = "CAMADA_PRINCIPAL"

    with open(path_txt, "r", encoding="utf-8") as f:
        for line in f:
            line_str = line.strip()
            if not line_str:
                continue

            if line_str.startswith("[") and line_str.endswith("]"):
                header = line_str[1:-1].strip()
                if header == "CAMADA_PRINCIPAL":
                    secao_tipo = "CAMADA_PRINCIPAL"
                    secao_chave = "CAMADA_PRINCIPAL"
                elif header.startswith("ABA:"):
                    secao_tipo = "ABA_CUSTOM"
                    nome_aba = header.split("ABA:")[1].strip()
                    secao_chave = nome_aba
                    if nome_aba not in checklists["ABAS_CUSTOM"]:
                        checklists["ABAS_CUSTOM"][nome_aba] = []
                elif header.startswith("RELACAO:"):
                    secao_tipo = "RELACAO"
                    conteudo_rel = header.split("RELACAO:")[1].strip()
                    
                    nome_custom = None
                    campo_custom = None

                    partes = [p.strip() for p in conteudo_rel.split("|")]
                    rel_nome_atual = partes[0]
                    secao_chave = rel_nome_atual

                    for param in partes[1:]:
                        if param.startswith("NOME:"):
                            nome_custom = param.split("NOME:")[1].strip()
                        elif param.startswith("CAMPO:"):
                            campo_custom = param.split("CAMPO:")[1].strip()

                    if rel_nome_atual not in checklists["RELACOES"]:
                        checklists["RELACOES"][rel_nome_atual] = []
                    
                    if nome_custom:
                        checklists["NOMES_ABAS"][rel_nome_atual] = nome_custom
                    if campo_custom:
                        checklists["CAMPOS_ROTULO"][rel_nome_atual] = campo_custom

            else:
                if line_str.startswith("# ") or line_str.startswith("## ") or line_str.startswith("### "):
                    item_dado = {"tipo": "titulo", "texto": line_str.lstrip("#").strip()}
                elif line_str.startswith("#"):
                    continue
                elif line_str.startswith("*"):
                    texto_campo = line_str.lstrip("*").strip().rstrip(";")
                    item_dado = {"tipo": "digitavel", "texto": texto_campo}
                elif line_str.startswith("+"):
                    partes_mais = line_str.lstrip("+").split(">")
                    nome_campo = partes_mais[0].strip().rstrip(";")
                    colunas = []
                    if len(partes_mais) > 1:
                        colunas = [c.strip().rstrip(";") for c in partes_mais[1].split(",") if c.strip()]
                    if not colunas:
                        colunas = ["Valor"]
                    item_dado = {"tipo": "adicionavel", "texto": nome_campo, "colunas": colunas}
                elif line_str.startswith("="):
                    partes_calc = line_str.lstrip("=").split("|")
                    nome_calc = partes_calc[0].strip().rstrip(";")
                    formula_def = partes_calc[1].strip().rstrip(";") if len(partes_calc) > 1 else "0"
                    item_dado = {"tipo": "calculado", "texto": nome_calc, "formula": formula_def}
                elif line_str.startswith("^"):
                    partes_file = line_str.lstrip("^").split("|")
                    nome_file = partes_file[0].strip().rstrip(";")
                    padrao_rename = partes_file[1].strip().rstrip(";") if len(partes_file) > 1 else nome_file
                    item_dado = {"tipo": "arquivo", "texto": nome_file, "padrao_renomear": padrao_rename}
                else:
                    item_dado = {"tipo": "item", "texto": line_str.rstrip(";")}

                if secao_tipo == "CAMADA_PRINCIPAL":
                    checklists["CAMADA_PRINCIPAL"].append(item_dado)
                elif secao_tipo == "ABA_CUSTOM":
                    checklists["ABAS_CUSTOM"][secao_chave].append(item_dado)
                elif secao_tipo == "RELACAO" and secao_chave:
                    checklists["RELACOES"][secao_chave].append(item_dado)

    return checklists


# ==============================================================================
# EXTRAÇÃO DE DADOS E HIERARQUIA DAS CAMADAS DO QGIS
# ==============================================================================

def _feature_para_dict(feat):
    if not feat or not feat.isValid():
        return {}
    dados = {}
    for field in feat.fields():
        val = feat.attribute(field.name())
        dados[field.name()] = str(val) if val is not None else ""
    return dados


def _obter_feicoes_relacionadas(feicao_origem, relacao):
    rel_manager = QgsProject.instance().relationManager()
    pivo_layer = relacao.referencingLayer()
    if not pivo_layer:
        return [], None

    pivo_features = list(relacao.getRelatedFeatures(feicao_origem))

    outras_rels_pivo = [
        r for r in rel_manager.relations().values() 
        if r.referencingLayerId() == pivo_layer.id() and r.id() != relacao.id()
    ]

    if outras_rels_pivo:
        segunda_rel = outras_rels_pivo[0]
        feats_destino = []
        for feat_pivo in pivo_features:
            feat_dest = segunda_rel.getReferencedFeature(feat_pivo)
            if feat_dest.isValid():
                feats_destino.append(feat_dest)
        return feats_destino, segunda_rel.referencedLayer()
    else:
        return pivo_features, pivo_layer


def _extrair_dados_estilo_django(layer_pai, feat_pai):
    rel_manager = QgsProject.instance().relationManager()
    contexto = _feature_para_dict(feat_pai)
    rel_data_dict_checklist = {}

    def _percorrer_recursivo(layer_atual, feat_atual, caminho_tags, dados_pai_dict, visitados_feats):
        if not layer_atual or not feat_atual or not feat_atual.isValid():
            return

        chave_visitado = (layer_atual.id(), feat_atual.id())
        if chave_visitado in visitados_feats:
            return

        novos_visitados = set(visitados_feats)
        novos_visitados.add(chave_visitado)

        relacoes = [r for r in rel_manager.relations().values() if r.referencedLayerId() == layer_atual.id()]

        for rel in relacoes:
            nome_rel = rel.name()
            novas_feats, camada_dest = _obter_feicoes_relacionadas(feat_atual, rel)
            
            if not novas_feats or not camada_dest:
                continue

            feats_validas = [f for f in novas_feats if f and f.isValid() and (camada_dest.id(), f.id()) not in novos_visitados]
            if not feats_validas:
                continue

            novo_caminho_list = caminho_tags + [nome_rel]
            tag_seta = " -> ".join(novo_caminho_list)
            tag_underline = "__".join(novo_caminho_list)

            for tag_chave in [tag_seta, tag_underline]:
                if tag_chave not in rel_data_dict_checklist:
                    rel_data_dict_checklist[tag_chave] = {
                        "layer": camada_dest,
                        "features": []
                    }
                rel_data_dict_checklist[tag_chave]["features"].extend(feats_validas)

            nome_sanitizado = _sanitizar_nome_var(nome_rel)
            lista_filhos_dados = []

            for feat_filha in feats_validas:
                dados_filha = _feature_para_dict(feat_filha)
                _percorrer_recursivo(camada_dest, feat_filha, novo_caminho_list, dados_filha, novos_visitados)
                lista_filhos_dados.append(dados_filha)

            dados_pai_dict[nome_sanitizado] = lista_filhos_dados

    _percorrer_recursivo(layer_pai, feat_pai, [], contexto, set())
    return contexto, rel_data_dict_checklist


# ==============================================================================
# GERADORES AUTOMÁTICOS DE ARQUIVOS MODELO (TXT E DOCX)
# ==============================================================================

def _obter_relacoes_recursivas(layer_pai, caminho_ancestrais=None, visitados_layers=None):
    if caminho_ancestrais is None:
        caminho_ancestrais = []
    if visitados_layers is None:
        visitados_layers = set()

    if not layer_pai or layer_pai.id() in visitados_layers:
        return []

    novos_visitados = set(visitados_layers)
    novos_visitados.add(layer_pai.id())

    rel_manager = QgsProject.instance().relationManager()
    relacoes_diretas = [r for r in rel_manager.relations().values() if r.referencedLayerId() == layer_pai.id()]
    
    hierarquia_relacoes = []

    for rel in relacoes_diretas:
        pivo_layer = rel.referencingLayer()
        if not pivo_layer:
            continue

        outras_rels_pivo = [
            r for r in rel_manager.relations().values() 
            if r.referencingLayerId() == pivo_layer.id() and r.id() != rel.id()
        ]

        if outras_rels_pivo:
            segunda_rel = outras_rels_pivo[0]
            camada_destino = segunda_rel.referencedLayer()
            nome_rel = rel.name()
        else:
            camada_destino = pivo_layer
            nome_rel = rel.name()

        if not camada_destino or camada_destino.id() in novos_visitados:
            continue

        novo_caminho = caminho_ancestrais + [nome_rel]
        tag_secao_seta = " -> ".join(novo_caminho)
        nivel_grau = len(novo_caminho)

        hierarquia_relacoes.append((tag_secao_seta, nome_rel, camada_destino, nivel_grau))

        sub_relacoes = _obter_relacoes_recursivas(camada_destino, novo_caminho, novos_visitados)
        hierarquia_relacoes.extend(sub_relacoes)

    return hierarquia_relacoes


def criar_modelo_checklist_padrao(nome_sugestao, nome_camada_principal=None):
    nome_limpo = re.sub(r'[\\/*?:"<>|]', "_", nome_sugestao).lower().replace(" ", "_")
    nome_arquivo = f"checklist_{nome_limpo}.txt"
    caminho_destino = os.path.join(PASTA_CHECKLISTS, nome_arquivo)

    conteudo_modelo = (
        "# ====================================================================\n"
        f"# CHECKLIST DE ANÁLISE TÉCNICA: {nome_sugestao.upper()}\n"
        "# - * : Campo digitável simples\n"
        "# - + : Campo adicionável com colunas (ex: + APPs > Número, Área)\n"
        "# - = : Campo calculado com fórmula (ex: = Área Útil | area_total - sum_apps__area)\n"
        "# - ^ : Campo de arquivo local (ex: ^ Projeto Urbanístico | DOC-01 - Projeto Urbanístico)\n"
        "# - [ABA: Nome da Aba] : Cria abas customizadas na interface\n"
        "# ====================================================================\n"
        "[CAMADA_PRINCIPAL]\n\n"
        "* Número do Processo ou Ofício;\n"
        "+ Proprietário > Nome, Sobrenome, Endereço;\n"
        "+ APPs > Número, Área;\n"
        "* Área Total;\n"
        "= Área Útil (calculada) | area_total - sum_apps__area;\n\n"
        "# Verificações Gerais\n"
        "REURB instaurada;\n\n"
        "[ABA: Documentos e Anexos]\n\n"
        "^ Projeto Urbanístico | DOC-01 - Projeto Urbanistico;\n"
        "^ Memorial Descritivo | DOC-02 - Memorial Descritivo;\n"
        "^ Anotação de Responsabilidade Técnica (ART/RRT) | DOC-03 - ART_RRT;\n"
    )

    if nome_camada_principal:
        camadas = QgsProject.instance().mapLayersByName(nome_camada_principal)
        if camadas:
            layer_raiz = camadas[0]
            todas_relacoes = _obter_relacoes_recursivas(layer_raiz)

            for tag_secao, nome_rel, camada_dest, nivel in todas_relacoes:
                nome_sugerido_aba = camada_dest.name()
                conteudo_modelo += (
                    f"\n\n[RELACAO: {tag_secao} | NOME: {nome_sugerido_aba}]\n\n"
                    f"# Grau {nivel}: Verificações para '{nome_rel}' ({camada_dest.name()})\n"
                    f"Documentação técnica e cadastral de {camada_dest.name()} conferida;\n"
                    f"Requisitos urbanísticos e legais de {camada_dest.name()} validados;\n"
                )

    with open(caminho_destino, "w", encoding="utf-8") as f:
        f.write(conteudo_modelo)

    return caminho_destino


def gerar_template_word_base(titulo_analise, tipo_resultado="DEFERIDO", nome_camada_principal=None):
    from docx import Document
    
    nome_limpo = re.sub(r'[\\/*?:"<>|]', "_", titulo_analise).lower().replace(" ", "_")
    nome_arquivo = f"modelo_{tipo_resultado.lower()}_{nome_limpo}.docx"
    caminho_destino = os.path.join(PASTA_MODELOS_DOC, nome_arquivo)

    doc = Document()

    p_titulo = doc.add_paragraph()
    run_t = p_titulo.add_run(f"PARECER TÉCNICO DE ANÁLISE - {tipo_resultado.upper()}")
    run_t.bold = True
    p_titulo.alignment = 1

    doc.add_paragraph(f"Análise: {titulo_analise}")
    doc.add_paragraph("Data de Emissão: {{ data_extenso }}")
    doc.add_paragraph("=" * 60)

    doc.add_paragraph("\n1. DADOS E CAMPOS DO PROCESSO")
    doc.add_paragraph("• Proprietários:")
    doc.add_paragraph("{% for p in proprietario %}")
    doc.add_paragraph("  - {{ p.nome }} {{ p.sobrenome }} - Endereço: {{ p.endereco }}")
    doc.add_paragraph("{% endfor %}")
    doc.add_paragraph("• Área Útil Calculada: {{ area_util }}")

    doc.add_paragraph("\n" + "=" * 60)
    doc.add_paragraph("2. JUSTIFICATIVA E PARECER TÉCNICO")
    doc.add_paragraph("{{ observacoes_analise }}")
    doc.add_paragraph("\n" + "=" * 60)

    p_ass = doc.add_paragraph()
    p_ass.add_run("\n\n___________________________________________\n")
    p_ass.add_run("{{ tecnico_nome }}\n").bold = True
    p_ass.add_run("{{ tecnico_cargo }}\n")
    p_ass.add_run("{{ tecnico_linha_add }}\n")

    doc.save(caminho_destino)
    return caminho_destino


# ==============================================================================
# DIÁLOGO DE EXECUÇÃO DA ANÁLISE (CHECKLIST INTERATIVO)
# ==============================================================================

class DialogoExecucaoAnalise(QDialog):
    def __init__(self, config_analise, feature_pai, relacoes_filho_dict, parent=None):
        super().__init__(parent)
        self.config = config_analise
        self.feature_pai = feature_pai
        self.relacoes_filho_dict = relacoes_filho_dict

        self.session_id = f"{config_analise['titulo']}_{feature_pai.id()}"
        self.session_file = os.path.join(PASTA_SESSIONS_ANALISE, f"{self._limpar_nome(self.session_id)}.json")

        self.checklists_def = ler_arquivo_checklist_txt(config_analise["checklist_path"])
        self._estado_progresso_salvo = {}
        if os.path.exists(self.session_file):
            try:
                with open(self.session_file, "r", encoding="utf-8") as f:
                    self._estado_progresso_salvo = json.load(f)
            except Exception as e:
                print(f"Erro ao carregar sessão anterior: {e}")
        if not isinstance(self._estado_progresso_salvo, dict):
            self._estado_progresso_salvo = {}
        arquivos_removidos = self._estado_progresso_salvo.get("checklist_arquivos_removidos", [])
        if not isinstance(arquivos_removidos, list):
            arquivos_removidos = []
        self.arquivos_checklist_removidos = set(
            item for item in arquivos_removidos
            if isinstance(item, str)
        )
        arquivos_adicionados = self._estado_progresso_salvo.get("checklist_arquivos_adicionados", {})
        self.arquivos_checklist_adicionados = (
            arquivos_adicionados if isinstance(arquivos_adicionados, dict) else {}
        )
        self.checkboxes_map = {}
        self.inputs_digitaveis_map = {}
        self.inputs_adicionaveis_map = {}  # {var_name: {"colunas": [...], "linhas": [...], "layout": ...}}
        self.inputs_calculados_map = {}   # {var_name: (QLineEdit_valor, formula_str)}
        self.calculos_com_erro = {}
        self.inputs_arquivos_map = {}     # {key: (var_name, QLineEdit, padrao_rename, rotulo_original)}
        self.inputs_arquivos_nome_exportacao = {}
        self.inputs_arquivos_nome_exportacao_resumo = {}
        self.widgets_campos_arquivo = {}
        self.layouts_campos_arquivo = {}
        self.resultado_analise = "DEFERIDO"
        self.observacoes_gerais = ""

        self.setWindowFlags(
            Qt.Window |
            Qt.WindowMinMaxButtonsHint |
            Qt.WindowCloseButtonHint
        )

        self.setWindowTitle(f"Análise: {config_analise['titulo']} - Objeto ID #{feature_pai.id()}")
        self.resize(1180, 750)
        self.init_ui()
        self.carregar_progresso_salvo()
        self.recalcular_campos()

    def _limpar_nome(self, texto):
        return re.sub(r'[\\/*?:"<>|]', "_", str(texto))

    def _obter_rotulo_feicao(self, child_feat, camada_dest=None, campo_preferencial=None):
        if not child_feat or not child_feat.isValid():
            return str(child_feat.id()) if child_feat else "N/A"

        if campo_preferencial:
            for field in child_feat.fields():
                if field.name().lower() == campo_preferencial.lower():
                    val = child_feat.attribute(field.name())
                    if val is not None and str(val).strip():
                        return f"{child_feat.id()} - {str(val).strip()}"

        if camada_dest:
            try:
                from qgis.core import QgsExpressionContext, QgsExpressionContextUtils
                context = QgsExpressionContext()
                context.appendScope(QgsExpressionContextUtils.globalScope())
                context.appendScope(QgsExpressionContextUtils.projectScope(QgsProject.instance()))
                context.appendScope(QgsExpressionContextUtils.layerScope(camada_dest))
                context.appendScope(QgsExpressionContextUtils.featureScope(child_feat))
                
                expr_str = camada_dest.displayExpression()
                if expr_str:
                    from qgis.core import QgsExpression
                    expr = QgsExpression(expr_str)
                    val_expr = expr.evaluate(context)
                    if val_expr is not None and str(val_expr).strip():
                        val_str = str(val_expr).strip()
                        if len(val_str) > 60:
                            val_str = val_str[:57] + "..."
                        return f"{child_feat.id()} - {val_str}"
            except Exception as e:
                print(f"Erro ao avaliar display expression: {e}")

        campos_prioritarios = [
            'n_lote', 'numero_lote', 'num_lote', 'lote', 'numero', 'num', 
            'nome', 'nm_nucleo', 'nome_nucleo', 'codigo', 'cod', 
            'identificador', 'id_lote'
        ]

        for nome_campo in campos_prioritarios:
            for field in child_feat.fields():
                if field.name().lower() == nome_campo:
                    val = child_feat.attribute(field.name())
                    if val is not None and str(val).strip():
                        return f"{child_feat.id()} - {str(val).strip()}"

        return str(child_feat.id())

    def _construir_elementos_da_lista(self, lista_itens, layout_destino, prefixo_chave):
        idx_item = 0
        idx_dig = 0
        idx_add = 0
        idx_calc = 0
        idx_arq = 0

        for elem in lista_itens:
            tipo = elem.get("tipo") if isinstance(elem, dict) else "item"
            texto = elem.get("texto", "") if isinstance(elem, dict) else str(elem)

            if tipo == "titulo":
                lbl_titulo = QLabel(f"<b>{texto}</b>")
                lbl_titulo.setStyleSheet("font-size: 13px; color: #1b5e20; margin-top: 10px; margin-bottom: 2px;")
                layout_destino.addWidget(lbl_titulo)
            
            elif tipo == "digitavel":
                lbl_dig = QLabel(f"<b>{texto}:</b>")
                txt_input = QLineEdit()
                txt_input.textChanged.connect(self.salvar_progresso_automatico)
                txt_input.textChanged.connect(self.recalcular_campos)
                
                var_name = _sanitizar_nome_var(texto)
                key = f"{prefixo_chave}_DIG_{var_name}_{idx_dig}"
                self.inputs_digitaveis_map[key] = (var_name, txt_input)

                layout_destino.addWidget(lbl_dig)
                layout_destino.addWidget(txt_input)
                idx_dig += 1

            elif tipo == "adicionavel":
                colunas = elem.get("colunas", ["Valor"])
                var_name = _sanitizar_nome_var(texto)
                
                lbl_add = QLabel(f"<b>{texto} (Múltiplos):</b>")
                layout_destino.addWidget(lbl_add)

                container_add_layout = QVBoxLayout()
                
                if var_name not in self.inputs_adicionaveis_map:
                    self.inputs_adicionaveis_map[var_name] = {"colunas": colunas, "linhas": [], "layout": container_add_layout}
                else:
                    self.inputs_adicionaveis_map[var_name]["colunas"] = colunas
                    self.inputs_adicionaveis_map[var_name]["layout"] = container_add_layout

                def criar_linha_adicionavel(valores_iniciais=None, vn=var_name, cols=colunas, cont_lay=container_add_layout):
                    row_w = QWidget()
                    row_l = QHBoxLayout(row_w)
                    row_l.setContentsMargins(0, 0, 0, 0)
                    row_l.setSpacing(6)
                    
                    inputs_linha = []
                    for i, col_nome in enumerate(cols):
                        val_ini = ""
                        if valores_iniciais and i < len(valores_iniciais):
                            val_ini = str(valores_iniciais[i])
                        
                        inp = QLineEdit(val_ini)
                        inp.setPlaceholderText(col_nome)
                        if "area" in col_nome.lower() or "num" in col_nome.lower() or "valor" in col_nome.lower():
                            inp.setMaximumWidth(150)

                        inp.textChanged.connect(self.salvar_progresso_automatico)
                        inp.textChanged.connect(self.recalcular_campos)
                        row_l.addWidget(inp)
                        inputs_linha.append(inp)
                    
                    btn_remover = QPushButton("🗑️")
                    btn_remover.setFixedWidth(35)
                    
                    def remover_esta_linha():
                        if inputs_linha in self.inputs_adicionaveis_map[vn]["linhas"]:
                            self.inputs_adicionaveis_map[vn]["linhas"].remove(inputs_linha)
                        row_w.setParent(None)
                        row_w.deleteLater()
                        self.salvar_progresso_automatico()
                        self.recalcular_campos()

                    btn_remover.clicked.connect(remover_esta_linha)
                    row_l.addWidget(btn_remover)
                    
                    cont_lay.addWidget(row_w)
                    self.inputs_adicionaveis_map[vn]["linhas"].append(inputs_linha)

                btn_mais = QPushButton(f"➕ Adicionar {texto}")
                btn_mais.clicked.connect(lambda _, f_fn=criar_linha_adicionavel: f_fn())
                
                # A linha automática inicial foi removida para começar zerada
                
                layout_destino.addLayout(container_add_layout)
                layout_destino.addWidget(btn_mais)
                idx_add += 1

            elif tipo == "calculado":
                formula_inicial = elem.get("formula", "0")
                var_name = _sanitizar_nome_var(texto)
                
                lbl_c = QLabel(f"<b>{texto}:</b>")
                layout_destino.addWidget(lbl_c)

                row_c = QHBoxLayout()
                txt_val = QLineEdit("0")
                txt_val.setReadOnly(True)
                txt_val.setStyleSheet("background-color: #f0f0f0; font-weight: bold;")
                
                btn_lapis = QPushButton("✏️")
                btn_lapis.setMaximumWidth(40)
                btn_lapis.setToolTip("Editar fórmula de cálculo e identificar variáveis disponíveis")

                self.inputs_calculados_map[var_name] = (txt_val, formula_inicial)

                def criar_edicao_formula(v_name=var_name, t_w=txt_val):
                    def editar_formula():
                        current_f = self.inputs_calculados_map[v_name][1]
                        ajuda_vars = []
                        
                        for _, (v_dig, _) in self.inputs_digitaveis_map.items():
                            ajuda_vars.append(f"• {v_dig}")
                            
                        for v_add, dados in self.inputs_adicionaveis_map.items():
                            ajuda_vars.append(f"• {v_add} (soma total da 1ª coluna)")
                            for col in dados["colunas"]:
                                ajuda_vars.append(f"• {v_add}__{_sanitizar_nome_var(col)}")
                        
                        for v_calc in self.inputs_calculados_map.keys():
                            if v_calc != v_name:
                                ajuda_vars.append(f"• {v_calc}")
                                if "__" in v_calc:
                                    v_curta = v_calc.split("__")[0]
                                    if v_curta != v_calc and f"• {v_curta} (alias)" not in ajuda_vars:
                                        ajuda_vars.append(f"• {v_curta} (alias)")

                        msg_ajuda = (
                            f"Fórmula para '{v_name}':\n\nVariáveis disponíveis:\n"
                            + "\n".join(ajuda_vars)
                            + "\n\nCorreção monetária: corrigir_incc(valor_ou_campo, 'DD/MM/AAAA')"
                            + "\nAplica os índices mensais após o mês-base até o último mês publicado (SGS/BCB 192)."
                        )
                        
                        nova_f, ok = QInputDialog.getText(self, "Editar Fórmula", msg_ajuda, QLineEdit.Normal, current_f)
                        if ok and nova_f.strip():
                            self.inputs_calculados_map[v_name] = (t_w, nova_f.strip())
                            self.recalcular_campos()
                            self.salvar_progresso_automatico()
                    return editar_formula

                btn_lapis.clicked.connect(criar_edicao_formula())

                row_c.addWidget(txt_val)
                row_c.addWidget(btn_lapis)
                layout_destino.addLayout(row_c)
                idx_calc += 1

            elif tipo == "arquivo":
                padrao_rename = elem.get("padrao_renomear", texto)
                var_name = _sanitizar_nome_var(texto)
                key = f"{prefixo_chave}_FILE_{var_name}_{idx_arq}"
                if key not in self.arquivos_checklist_removidos:
                    self._criar_campo_arquivo(
                        key, texto, padrao_rename, layout_destino
                    )
                widget_ancora = self.widgets_campos_arquivo.get(key)
                indice = (
                    layout_destino.indexOf(widget_ancora) + 1
                    if widget_ancora else layout_destino.count()
                )
                self._inserir_arquivos_adicionados(key, layout_destino, indice)
                idx_arq += 1

            else:
                cb = QCheckBox(texto)
                cb.stateChanged.connect(self.salvar_progresso_automatico)
                key = f"{prefixo_chave}_ITEM_{idx_item}"
                self.checkboxes_map[key] = cb
                layout_destino.addWidget(cb)
                idx_item += 1

    def _criar_campo_arquivo(self, key, texto, padrao_rename, layout_destino, indice=None):
        campo = QWidget()
        layout_campo = QVBoxLayout(campo)
        layout_campo.setContentsMargins(0, 3, 0, 3)
        layout_campo.setSpacing(3)

        linha_titulo = QHBoxLayout()
        lbl_file = QLabel(f"📁 {texto}:")
        lbl_file.setTextFormat(Qt.PlainText)
        lbl_file.setStyleSheet("font-weight: bold;")
        linha_titulo.addWidget(lbl_file)

        txt_nome_exportacao = QLineEdit(padrao_rename)
        txt_nome_exportacao.setPlaceholderText("Nome do arquivo no pacote/exportação...")
        txt_nome_exportacao.setVisible(False)
        txt_nome_exportacao.textChanged.connect(self.salvar_progresso_automatico)

        lbl_nome_exportacao = QLabel(padrao_rename)
        lbl_nome_exportacao.setTextFormat(Qt.PlainText)
        lbl_nome_exportacao.setStyleSheet("color: #888; font-size: 9pt;")
        txt_nome_exportacao.textChanged.connect(lbl_nome_exportacao.setText)

        btn_editar = QPushButton("✏️")
        btn_editar.setFixedWidth(35)
        btn_editar.setToolTip("Editar o nome de saída")

        def alternar_edicao_nome():
            editando = not txt_nome_exportacao.isVisible()
            txt_nome_exportacao.setVisible(editando)
            lbl_nome_exportacao.setVisible(not editando)
            btn_editar.setText("✓" if editando else "✏️")
            btn_editar.setToolTip("Concluir edição" if editando else "Editar o nome de saída")
            if editando:
                txt_nome_exportacao.setFocus()

        btn_editar.clicked.connect(alternar_edicao_nome)

        btn_adicionar = QPushButton("➕")
        btn_adicionar.setFixedWidth(35)
        btn_adicionar.setToolTip("Adicionar outro campo de arquivo após este")
        btn_adicionar.clicked.connect(
            lambda _, k=key, lay=layout_destino: self.adicionar_campo_arquivo(k, lay)
        )

        btn_excluir = QPushButton("🗑️")
        btn_excluir.setFixedWidth(35)
        btn_excluir.setToolTip("Excluir este campo somente desta análise")
        btn_excluir.clicked.connect(lambda _, k=key: self.excluir_campo_arquivo(k))

        layout_campo.addLayout(linha_titulo)

        linha_arquivo = QHBoxLayout()
        txt_file_path = QLineEdit()
        txt_file_path.setPlaceholderText("Caminho do arquivo local selecionado...")
        txt_file_path.textChanged.connect(self.salvar_progresso_automatico)

        btn_buscar_arq = QPushButton("📁 Buscar...")
        btn_buscar_arq.setFixedWidth(90)

        def buscar_arquivo():
            caminho, _ = QFileDialog.getOpenFileName(
                self, "Selecionar Arquivo para o Processo", "", "Todos os Arquivos (*.*)"
            )
            if caminho:
                txt_file_path.setText(caminho)

        btn_buscar_arq.clicked.connect(buscar_arquivo)

        btn_limpar_arq = QPushButton("✖")
        btn_limpar_arq.setFixedWidth(35)
        btn_limpar_arq.setToolTip("Limpar arquivo selecionado")
        btn_limpar_arq.clicked.connect(txt_file_path.clear)

        linha_arquivo.addWidget(txt_file_path)
        linha_arquivo.addWidget(btn_buscar_arq)
        linha_arquivo.addWidget(btn_limpar_arq)
        linha_arquivo.addWidget(btn_editar)
        linha_arquivo.addWidget(btn_adicionar)
        linha_arquivo.addWidget(btn_excluir)
        layout_campo.addLayout(linha_arquivo)
        layout_campo.addWidget(lbl_nome_exportacao)
        layout_campo.addWidget(txt_nome_exportacao)

        if indice is None:
            layout_destino.addWidget(campo)
        else:
            layout_destino.insertWidget(indice, campo)

        self.inputs_arquivos_map[key] = (
            _sanitizar_nome_var(texto), txt_file_path, padrao_rename, texto
        )
        self.inputs_arquivos_nome_exportacao[key] = txt_nome_exportacao
        self.inputs_arquivos_nome_exportacao_resumo[key] = lbl_nome_exportacao
        self.widgets_campos_arquivo[key] = campo
        self.layouts_campos_arquivo[key] = layout_destino

    def _inserir_arquivos_adicionados(self, chave_ancora, layout_destino, indice):
        adicionados = self.arquivos_checklist_adicionados.get(chave_ancora, [])
        if not isinstance(adicionados, list):
            return indice

        for campo in adicionados:
            if not isinstance(campo, dict):
                continue
            chave = campo.get("key")
            texto = campo.get("texto", "")
            if not isinstance(chave, str) or not isinstance(texto, str) or not texto.strip():
                continue
            texto = texto.strip()

            if chave not in self.arquivos_checklist_removidos:
                padrao = campo.get("padrao_renomear", texto)
                if not isinstance(padrao, str):
                    padrao = texto
                self._criar_campo_arquivo(chave, texto, padrao, layout_destino, indice)
                indice += 1

            indice = self._inserir_arquivos_adicionados(chave, layout_destino, indice)
        return indice

    def adicionar_campo_arquivo(self, chave_ancora, layout_destino):
        texto, ok = QInputDialog.getText(
            self, "Adicionar campo de arquivo", "Nome do novo campo de arquivo:"
        )
        texto = texto.strip()
        if not ok or not texto:
            return

        chave = f"{chave_ancora}_CUSTOM_{uuid.uuid4().hex}"
        campo = {"key": chave, "texto": texto, "padrao_renomear": texto}
        adicionados = self.arquivos_checklist_adicionados.setdefault(chave_ancora, [])
        if not isinstance(adicionados, list):
            adicionados = []
            self.arquivos_checklist_adicionados[chave_ancora] = adicionados
        adicionados.insert(0, campo)

        indice = layout_destino.indexOf(self.widgets_campos_arquivo[chave_ancora]) + 1
        self._criar_campo_arquivo(chave, texto, texto, layout_destino, indice)
        self.salvar_progresso_automatico()

    def excluir_campo_arquivo(self, chave):
        if chave not in self.widgets_campos_arquivo:
            return

        self.arquivos_checklist_removidos.add(chave)
        self.inputs_arquivos_map.pop(chave, None)
        self.inputs_arquivos_nome_exportacao.pop(chave, None)
        self.inputs_arquivos_nome_exportacao_resumo.pop(chave, None)
        campo = self.widgets_campos_arquivo.pop(chave)
        layout = self.layouts_campos_arquivo.pop(chave)
        layout.removeWidget(campo)
        campo.setParent(None)
        campo.deleteLater()
        self.salvar_progresso_automatico()

    def init_ui(self):
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()

        # ======================================================================
        # 1. ABA PRINCIPAL (CAMADA PAI)
        # ======================================================================
        tab_principal = QWidget()
        layout_p = QVBoxLayout(tab_principal)
        scroll_p = QScrollArea()
        scroll_p.setWidgetResizable(True)
        content_p = QWidget()
        self.layout_content_p = QVBoxLayout(content_p)

        itens_principal = self.checklists_def.get("CAMADA_PRINCIPAL", [])
        if itens_principal:
            self._construir_elementos_da_lista(itens_principal, self.layout_content_p, "PAI")

        self.layout_content_p.addStretch()
        scroll_p.setWidget(content_p)
        layout_p.addWidget(scroll_p)
        self.tabs.addTab(tab_principal, "Checklist Principal")

        # ======================================================================
        # 2. ABAS CUSTOMIZADAS CONFIGURADAS NO TXT ([ABA: Nome])
        # ======================================================================
        abas_custom_dict = self.checklists_def.get("ABAS_CUSTOM", {})
        for nome_aba_custom, lista_itens_custom in abas_custom_dict.items():
            if not lista_itens_custom:
                continue

            tab_custom = QWidget()
            layout_c = QVBoxLayout(tab_custom)
            scroll_c = QScrollArea()
            scroll_c.setWidgetResizable(True)
            content_c = QWidget()
            layout_content_c = QVBoxLayout(content_c)

            prefixo_aba = f"ABA_{_sanitizar_nome_var(nome_aba_custom)}"
            self._construir_elementos_da_lista(lista_itens_custom, layout_content_c, prefixo_aba)

            layout_content_c.addStretch()
            scroll_c.setWidget(content_c)
            layout_c.addWidget(scroll_c)

            self.tabs.addTab(tab_custom, nome_aba_custom)

        # ======================================================================
        # 3. ABAS DE RELAÇÕES / OBJETOS VINCULADOS (MUITOS PARA MUITOS / 1:N)
        # ======================================================================
        nomes_custom = self.checklists_def.get("NOMES_ABAS", {})
        campos_custom = self.checklists_def.get("CAMPOS_ROTULO", {})

        for rel_nome, info_rel in self.relacoes_filho_dict.items():
            if isinstance(info_rel, dict):
                camada_dest_obj = info_rel.get("layer")
                lista_filhos = info_rel.get("features", [])
            elif isinstance(info_rel, list):
                camada_dest_obj = None
                lista_filhos = info_rel
            else:
                continue

            if not lista_filhos:
                continue

            itens_rel = self.checklists_def.get("RELACOES", {}).get(rel_nome, [])
            nome_aba_custom = nomes_custom.get(rel_nome)
            campo_rotulo = campos_custom.get(rel_nome)
            
            if not itens_rel:
                nome_alt = rel_nome.replace(" -> ", "__") if " -> " in rel_nome else rel_nome.replace("__", " -> ")
                itens_rel = self.checklists_def.get("RELACOES", {}).get(nome_alt, [])
                if not nome_aba_custom:
                    nome_aba_custom = nomes_custom.get(nome_alt)
                if not campo_rotulo:
                    campo_rotulo = campos_custom.get(nome_alt)

            if not itens_rel:
                nome_simples = rel_nome.split("->")[-1].strip() if "->" in rel_nome else rel_nome.split("__")[-1].strip()
                itens_rel = self.checklists_def.get("RELACOES", {}).get(nome_simples, [])
                if not nome_aba_custom:
                    nome_aba_custom = nomes_custom.get(nome_simples)
                if not campo_rotulo:
                    campo_rotulo = campos_custom.get(nome_simples)

            if not itens_rel:
                continue

            titulo_aba = nome_aba_custom if nome_aba_custom else (rel_nome.split("->")[-1].strip() if "->" in rel_nome else rel_nome.split("__")[-1].strip())

            ja_existe = False
            for idx_t in range(self.tabs.count()):
                if self.tabs.tabText(idx_t) == titulo_aba:
                    ja_existe = True
                    break
            if ja_existe:
                continue

            tab_rel = QWidget()
            layout_r = QVBoxLayout(tab_rel)
            scroll_r = QScrollArea()
            scroll_r.setWidgetResizable(True)
            content_r = QWidget()
            layout_content_r = QVBoxLayout(content_r)

            ids_vistos = set()
            feats_unicas = []
            for f in lista_filhos:
                if isinstance(f, QgsFeature) and f.isValid():
                    if f.id() not in ids_vistos:
                        ids_vistos.add(f.id())
                        feats_unicas.append(f)

            if not feats_unicas:
                continue

            for child_idx, child_feat in enumerate(feats_unicas):
                lbl_obj = self._obter_rotulo_feicao(child_feat, camada_dest=camada_dest_obj, campo_preferencial=campo_rotulo)

                # Separa o ID do valor/rótulo extraído da feição
                if " - " in lbl_obj:
                    partes_lbl = lbl_obj.split(" - ", 1)
                    feat_id_str = partes_lbl[0].strip()
                    nome_obj_str = partes_lbl[1].strip()
                    titulo_grupo = f"{nome_obj_str} (#{feat_id_str})"
                else:
                    titulo_grupo = f"Objeto (#{lbl_obj})"

                grp = QGroupBox(titulo_grupo)
                
                # Aumenta a fonte, aplica negrito e destaca o título do QGroupBox
                grp.setStyleSheet("""
                    QGroupBox {
                        font-size: 14px;
                        font-weight: bold;
                        color: #0d47a1;
                        margin-top: 12px;
                        padding-top: 14px;
                    }
                    QGroupBox::title {
                        subcontrol-origin: margin;
                        subcontrol-position: top left;
                        padding: 2px 6px;
                    }
                """)

                grp_layout = QVBoxLayout()

                # Prefixo dinâmico que isola o formulário de cada feição filha (ex: Lote) pelo seu ID único
                prefixo_child = f"REL_{_sanitizar_nome_var(rel_nome)}_CHILD_{child_feat.id()}"

                # Constrói o formulário completo (suporta arquivos ^, texto *, adicionável +, calculado = e checkboxes)
                self._construir_elementos_da_lista(itens_rel, grp_layout, prefixo_child)

                grp.setLayout(grp_layout)
                layout_content_r.addWidget(grp)
            layout_content_r.addStretch()
            scroll_r.setWidget(content_r)
            layout_r.addWidget(scroll_r)
            
            self.tabs.addTab(tab_rel, titulo_aba)

        layout.addWidget(self.tabs)

        grp_resultado = QGroupBox("Resultado da Análise Técnica")
        lay_res = QHBoxLayout()
        self.rb_deferido = QRadioButton("DEFERIDO (Aprovado)")
        self.rb_indeferido = QRadioButton("INDEFERIDO (Reprovado/Ressalvas)")
        self.rb_deferido.setChecked(True)
        lay_res.addWidget(self.rb_deferido)
        lay_res.addWidget(self.rb_indeferido)
        lay_res.addStretch()
        grp_resultado.setLayout(lay_res)
        layout.addWidget(grp_resultado)

        layout.addWidget(QLabel("<b>Observações / Justificativa Técnica:</b>"))
        self.txt_obs = QTextEdit()
        self.txt_obs.setPlaceholderText("Descreva as justificativas ou observações técnicas...")
        self.txt_obs.textChanged.connect(self.salvar_progresso_automatico)
        layout.addWidget(self.txt_obs)

        # BARRA DE AÇÕES E BOTÕES INFERIORES
        btn_layout = QHBoxLayout()
        btn_salvar_fechar = QPushButton("💾 Salvar Rascunho")
        btn_salvar_fechar.clicked.connect(self.salvar_e_fechar)

        btn_limpar = QPushButton("🔄 Limpar / Reiniciar Análise")
        btn_limpar.setStyleSheet("color: #c62828;")
        btn_limpar.clicked.connect(self.limpar_e_reiniciar_analise)

        btn_empacotar = QPushButton("📦 Empacotar Processo (.zip)")
        btn_empacotar.setStyleSheet("font-weight: bold; color: #0d47a1;")
        btn_empacotar.setToolTip("Cria um arquivo ZIP com todos os documentos anexados renomeados no padrão configurado.")
        btn_empacotar.clicked.connect(self.empacotar_processo_zip)

        self.btn_toggle_max = QPushButton("🗖 Maximizar / Restaurar")
        self.btn_toggle_max.clicked.connect(self.alternar_maximizacao)

        btn_gerar_parecer = QPushButton("📄 Finalizar e Gerar Parecer")
        btn_gerar_parecer.setStyleSheet("font-weight: bold; background-color: #2e7d32; color: white;")
        btn_gerar_parecer.clicked.connect(self.concluir_e_gerar)

        btn_layout.addWidget(btn_salvar_fechar)
        btn_layout.addWidget(btn_limpar)
        btn_layout.addWidget(btn_empacotar)
        btn_layout.addWidget(self.btn_toggle_max)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_gerar_parecer)
        layout.addLayout(btn_layout)

    def recalcular_campos(self):
        ctx_calc = {}

        # 1. Alimenta contexto com campos digitáveis simples
        for _, (v_name, widget) in self.inputs_digitaveis_map.items():
            val_str = widget.text().strip().replace(',', '.')
            try:
                ctx_calc[v_name] = float(val_str) if val_str else 0.0
            except ValueError:
                ctx_calc[v_name] = widget.text().strip()

        # 2. Alimenta contexto com campos adicionáveis (+)
        for var_name, dados_rep in self.inputs_adicionaveis_map.items():
            colunas = dados_rep["colunas"]
            somas_colunas = {_sanitizar_nome_var(col): 0.0 for col in colunas}
            
            for inputs_linha in dados_rep["linhas"]:
                for i, col in enumerate(colunas):
                    if i < len(inputs_linha):
                        val_str = inputs_linha[i].text().strip().replace(',', '.')
                        col_var = _sanitizar_nome_var(col)
                        try:
                            val_float = float(val_str) if val_str else 0.0
                            somas_colunas[col_var] += val_float
                        except ValueError:
                            pass
            
            for col_var, soma_val in somas_colunas.items():
                ctx_calc[f"{var_name}__{col_var}"] = soma_val
                ctx_calc[f"sum_{var_name}__{col_var}"] = soma_val
            
            primeira_col_var = _sanitizar_nome_var(colunas[0]) if colunas else ""
            soma_principal = somas_colunas.get(primeira_col_var, 0.0) if primeira_col_var else 0.0
            ctx_calc[var_name] = soma_principal
            ctx_calc[f"sum_{var_name}"] = soma_principal

        # Funções do Excel e utilitários
        ctx_calc["se"] = lambda cond, a, b: a if cond else b
        ctx_calc["IF"] = lambda cond, a, b: a if cond else b
        ctx_calc["arred"] = lambda val, n=2: round(val, n)
        ctx_calc["ROUND"] = lambda val, n=2: round(val, n)
        ctx_calc["soma"] = sum
        ctx_calc["SUM"] = sum
        ctx_calc["abs"] = abs
        ctx_calc["max"] = max
        ctx_calc["min"] = min

        def corrigir_incc(valor_ou_campo, data_base):
            return _corrigir_valor_incc(valor_ou_campo, data_base, ctx_calc)

        ctx_calc["corrigir_incc"] = corrigir_incc
        ctx_calc["CORRIGIR_INCC"] = corrigir_incc

        def parse_formula_excel(formula_str):
            f = formula_str.strip()
            pattern = r'^\s*if\s+(.+?)\s+(?:then|:)\s+(.+?)\s+else\s+(.+?)\s*$'
            match = re.match(pattern, f, re.IGNORECASE)
            if match:
                cond, val_true, val_false = match.groups()
                return f"({val_true}) if ({cond}) else ({val_false})"
            return f

        # 3. Avalia em múltiplos ciclos para resolver dependências em cadeia
        self.calculos_com_erro.clear()
        max_passos = len(self.inputs_calculados_map) + 1
        for _ in range(max_passos):
            mudou_algo = False
            for var_calc, (txt_widget, formula) in self.inputs_calculados_map.items():
                try:
                    formula_tratada = parse_formula_excel(formula)
                    resultado = eval(formula_tratada, {"__builtins__": None}, ctx_calc)
                    self.calculos_com_erro.pop(var_calc, None)
                    
                    if isinstance(resultado, (int, float)):
                        resultado_num = round(resultado, 4)
                        ctx_calc[var_calc] = resultado_num
                        
                        if "__" in var_calc:
                            ctx_calc[var_calc.split("__")[0]] = resultado_num
                        elif "_" in var_calc:
                            partes = var_calc.split("_")
                            if len(partes) >= 2:
                                ctx_calc[f"{partes[0]}_{partes[1]}"] = resultado_num

                        mudou_algo = True
                        val_exibicao = str(round(resultado, 2)) if isinstance(resultado, float) else str(resultado)
                        txt_widget.setText(val_exibicao)
                    else:
                        ctx_calc[var_calc] = resultado
                        if "__" in var_calc:
                            ctx_calc[var_calc.split("__")[0]] = resultado
                        txt_widget.setText(str(resultado))
                except ZeroDivisionError:
                    ctx_calc[var_calc] = 0.0
                    txt_widget.setText("0.0")
                except ErroCorrecaoINCC as erro:
                    self.calculos_com_erro[var_calc] = str(erro)
                    txt_widget.setText(f"Erro INCC: {erro}")
                except Exception as erro:
                    if "corrigir_incc" in formula.lower():
                        self.calculos_com_erro[var_calc] = str(erro)
                        txt_widget.setText(f"Erro INCC: {erro}")
            
            if not mudou_algo:
                break
        self.salvar_progresso_automatico()

    def alternar_maximizacao(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def salvar_progresso_automatico(self):
        if getattr(self, "_carregando_progresso", False):
            return

        add_dados = {
            vn: [[_limpar_quebras_linha(inp.text()) for inp in linha] for linha in dados["linhas"]]
            for vn, dados in self.inputs_adicionaveis_map.items()
        }
        calc_dados = {
            vn: {
                "formula": form,
                "valor": "" if vn in self.calculos_com_erro else _limpar_quebras_linha(w.text())
            }
            for vn, (w, form) in self.inputs_calculados_map.items()
        }
        arq_dados = {
            key: _limpar_quebras_linha(txt.text())
            for key, (_, txt, _, _) in self.inputs_arquivos_map.items()
        }
        nomes_exportacao = {
            key: _limpar_quebras_linha(widget.text())
            for key, widget in self.inputs_arquivos_nome_exportacao.items()
        }

        estado = {
            "session_id": self.session_id,
            "data_atualizacao": datetime.now().isoformat(),
            "deferido": self.rb_deferido.isChecked(),
            "observacoes": self.txt_obs.toPlainText(),
            "checks": {k: cb.isChecked() for k, cb in self.checkboxes_map.items()},
            "digitaveis": {
                k: _limpar_quebras_linha(val.text())
                for k, (_, val) in self.inputs_digitaveis_map.items()
            },
            "adicionaveis": add_dados,
            "calculados": calc_dados,
            "arquivos": arq_dados,
            "nomes_exportacao_arquivos": nomes_exportacao,
            "checklist_arquivos_removidos": sorted(self.arquivos_checklist_removidos),
            "checklist_arquivos_adicionados": self.arquivos_checklist_adicionados
        }
        with open(self.session_file, "w", encoding="utf-8") as f:
            json.dump(estado, f, ensure_ascii=False, indent=2)

    def carregar_progresso_salvo(self):
        if not os.path.exists(self.session_file):
            return

        self._carregando_progresso = True
        try:
            estado = self._estado_progresso_salvo

            if estado.get("deferido", True):
                self.rb_deferido.setChecked(True)
            else:
                self.rb_indeferido.setChecked(True)

            self.txt_obs.setPlainText(estado.get("observacoes", ""))

            checks = estado.get("checks", {})
            for key, cb in self.checkboxes_map.items():
                if key in checks:
                    cb.setChecked(checks[key])

            digitaveis = estado.get("digitaveis", {})
            for key, val_texto in digitaveis.items():
                if key in self.inputs_digitaveis_map:
                    _, txt_widget = self.inputs_digitaveis_map[key]
                    txt_widget.setText(val_texto)

            # Restaura arquivos selecionados
            arquivos = estado.get("arquivos", {})
            for key, path_file in arquivos.items():
                if key in self.inputs_arquivos_map:
                    _, txt_file_w, _, _ = self.inputs_arquivos_map[key]
                    txt_file_w.setText(path_file)

            nomes_exportacao = estado.get("nomes_exportacao_arquivos", {})
            for key, nome in nomes_exportacao.items():
                if key in self.inputs_arquivos_nome_exportacao:
                    self.inputs_arquivos_nome_exportacao[key].setText(nome)

            # Restaura os campos adicionáveis (+) salvos
            adicionaveis = estado.get("adicionaveis", {})
            for var_name, linhas_valores in adicionaveis.items():
                if var_name in self.inputs_adicionaveis_map:
                    dados_rep = self.inputs_adicionaveis_map[var_name]
                    for linha_inputs in dados_rep["linhas"]:
                        if linha_inputs:
                            w_widget = linha_inputs[0].parent()
                            if w_widget:
                                w_widget.setParent(None)
                                w_widget.deleteLater()
                    dados_rep["linhas"] = []

                    container_layout = dados_rep["layout"]
                    colunas = dados_rep["colunas"]

                    for valores_iniciais in linhas_valores:
                        row_w = QWidget()
                        row_l = QHBoxLayout(row_w)
                        row_l.setContentsMargins(0, 0, 0, 0)
                        row_l.setSpacing(6)

                        inputs_linha = []
                        for i, col_nome in enumerate(colunas):
                            val_ini = ""
                            if valores_iniciais and i < len(valores_iniciais):
                                val_ini = str(valores_iniciais[i])

                            inp = QLineEdit(val_ini)
                            inp.setPlaceholderText(col_nome)
                            if "area" in col_nome.lower() or "num" in col_nome.lower() or "valor" in col_nome.lower():
                                inp.setMaximumWidth(150)

                            inp.textChanged.connect(self.salvar_progresso_automatico)
                            inp.textChanged.connect(self.recalcular_campos)
                            row_l.addWidget(inp)
                            inputs_linha.append(inp)

                        btn_remover = QPushButton("🗑️")
                        btn_remover.setFixedWidth(35)

                        def fazer_remover(rw=row_w, il=inputs_linha, vn=var_name):
                            def remover_esta_linha():
                                if il in self.inputs_adicionaveis_map[vn]["linhas"]:
                                    self.inputs_adicionaveis_map[vn]["linhas"].remove(il)
                                rw.setParent(None)
                                rw.deleteLater()
                                self.salvar_progresso_automatico()
                                self.recalcular_campos()
                            return remover_esta_linha

                        btn_remover.clicked.connect(fazer_remover())
                        row_l.addWidget(btn_remover)

                        container_layout.addWidget(row_w)
                        dados_rep["linhas"].append(inputs_linha)

            calculados = estado.get("calculados", {})
            for vn, info in calculados.items():
                if vn in self.inputs_calculados_map:
                    w, _ = self.inputs_calculados_map[vn]
                    self.inputs_calculados_map[vn] = (w, info.get("formula", "0"))
                    w.setText(info.get("valor", "0"))

        except Exception as e:
            print(f"Erro ao carregar sessão anterior: {e}")
        finally:
            self._carregando_progresso = False

    def empacotar_processo_zip(self):
        """Cria um pacote .ZIP contendo todos os arquivos selecionados, organizados por pastas de objetos vinculados."""
        arquivos_para_incluir = []

        for key, (var_name, txt_w, padrao_rename, rotulo) in self.inputs_arquivos_map.items():
            path_origem = txt_w.text().strip()
            if not path_origem or not os.path.exists(path_origem):
                continue
            nome_exportacao = self.inputs_arquivos_nome_exportacao[key].text().strip() or padrao_rename

            # Verifica se o campo pertence a um objeto vinculado (ex: Lote em REL_...)
            subpasta_obj = ""
            if key.startswith("REL_"):
                # Formato da chave: REL_{rel_nome}_CHILD_{child_id}_FILE_{var_name}_{idx}
                m = re.search(r'_CHILD_(\d+)_', key)
                if m:
                    child_id = int(m.group(1))
                    
                    # Procura a feição e a camada de destino para reconstruir o rótulo amigável
                    feat_obj = None
                    camada_dest_obj = None
                    rel_nome_encontrado = None

                    for rel_k, info_rel in self.relacoes_filho_dict.items():
                        feats = info_rel.get("features", []) if isinstance(info_rel, dict) else info_rel
                        for f in feats:
                            if hasattr(f, "id") and f.id() == child_id:
                                feat_obj = f
                                if isinstance(info_rel, dict):
                                    camada_dest_obj = info_rel.get("layer")
                                rel_nome_encontrado = rel_k
                                break
                        if feat_obj:
                            break

                    if feat_obj:
                        campo_rotulo = self.checklists_def.get("CAMPOS_ROTULO", {}).get(rel_nome_encontrado)
                        lbl_obj = self._obter_rotulo_feicao(feat_obj, camada_dest=camada_dest_obj, campo_preferencial=campo_rotulo)

                        # Trata rótulo para extrair ID e Nome Limpo
                        if " - " in lbl_obj:
                            partes_lbl = lbl_obj.split(" - ", 1)
                            feat_id_str = partes_lbl[0].strip()
                            nome_obj_str = partes_lbl[1].strip()
                            subpasta_obj = f"{nome_obj_str} (#{feat_id_str})"
                        else:
                            subpasta_obj = f"Objeto (#{lbl_obj})"

                        # Saneamento do nome da subpasta para evitar conflitos no sistema de arquivos
                        subpasta_obj = re.sub(r'[\\/*?:"<>|]', "_", subpasta_obj).strip()
                        subpasta_obj = re.sub(r'\s+', ' ', subpasta_obj)

            arquivos_para_incluir.append((path_origem, nome_exportacao, rotulo, subpasta_obj))

        if not arquivos_para_incluir:
            QMessageBox.warning(self, "Aviso", "Nenhum arquivo válido foi selecionado nos campos de anexo para empacotar.")
            return

        nome_zip_sugerido = f"Processo_{re.sub(r'[^a-zA-Z0-9_]', '_', self.config['titulo'])}_ID_{self.feature_pai.id()}.zip"
        caminho_zip, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar Pacote do Processo (.zip)",
            nome_zip_sugerido,
            "Arquivo Zip (*.zip)"
        )
        if not caminho_zip:
            return

        try:
            with zipfile.ZipFile(caminho_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for path_origem, padrao_rename, rotulo, subpasta_obj in arquivos_para_incluir:
                    _, ext = os.path.splitext(path_origem)
                    
                    # Saneamento do nome do arquivo
                    nome_limpo = re.sub(r'[\\/*?:"<>|]', "_", padrao_rename).strip()
                    nome_limpo = re.sub(r'\s+', ' ', nome_limpo)
                    
                    if not nome_limpo.lower().endswith(ext.lower()):
                        nome_arquivo_final = f"{nome_limpo}{ext}"
                    else:
                        nome_arquivo_final = nome_limpo

                    # Monta o caminho relativo dentro do ZIP (com ou sem a subpasta do objeto)
                    if subpasta_obj:
                        caminho_no_zip = os.path.join(subpasta_obj, nome_arquivo_final)
                    else:
                        caminho_no_zip = nome_arquivo_final

                    zipf.write(path_origem, arcname=caminho_no_zip)

                # Gera manifesto detalhando a estrutura do pacote
                manifesto_txt = "PACOTE DE DOCUMENTOS DO PROCESSO\n"
                manifesto_txt += f"Análise: {self.config['titulo']}\n"
                manifesto_txt += f"Objeto Principal ID: {self.feature_pai.id()}\n"
                manifesto_txt += f"Data do Empacotamento: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n"
                manifesto_txt += "=" * 60 + "\n\n"
                manifesto_txt += "ARQUIVOS INCLUÍDOS:\n"
                
                for path_origem, padrao_rename, rotulo, subpasta_obj in arquivos_para_incluir:
                    pasta_str = f"[{subpasta_obj}] " if subpasta_obj else "[Geral/Pai] "
                    manifesto_txt += f"• {pasta_str}{rotulo} -> {padrao_rename} (Original: {os.path.basename(path_origem)})\n"

                zipf.writestr("00_MANIFESTO_PROCESSO.txt", manifesto_txt)

            QMessageBox.information(
                self,
                "Empacotamento Concluído",
                f"Pacote .ZIP criado com sucesso contendo {len(arquivos_para_incluir)} arquivo(s) organizados por pasta:\n{caminho_zip}"
            )
        except Exception as e:
            QMessageBox.critical(self, "Erro no Empacotamento", f"Ocorreu uma falha ao empacotar os arquivos:\n{e}")
    def limpar_e_reiniciar_analise(self):
        resposta = QMessageBox.question(
            self,
            "Confirmar Reinício",
            "Deseja realmente apagar todos os dados digitados e checkboxes marcados desta análise?\n\nEsta ação excluirá o rascunho salvo.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if resposta != QMessageBox.Yes:
            return

        if os.path.exists(self.session_file):
            try:
                os.remove(self.session_file)
            except Exception as e:
                print(f"Erro ao remover arquivo de rascunho: {e}")

        for cb in self.checkboxes_map.values():
            cb.setChecked(False)

        for _, (_, txt) in self.inputs_digitaveis_map.items():
            txt.clear()

        for key, (_, txt_file_w, _, _) in self.inputs_arquivos_map.items():
            txt_file_w.clear()
            self.inputs_arquivos_nome_exportacao[key].setText(
                self.inputs_arquivos_map[key][2]
            )

        for var_name, dados_rep in self.inputs_adicionaveis_map.items():
            for linha_inputs in dados_rep["linhas"]:
                if linha_inputs:
                    w_widget = linha_inputs[0].parent()
                    if w_widget:
                        w_widget.setParent(None)
                        w_widget.deleteLater()
            dados_rep["linhas"] = []

        self.txt_obs.clear()
        self.rb_deferido.setChecked(True)

        self.recalcular_campos()
        QMessageBox.information(self, "Análise Reiniciada", "Os dados da análise foram zerados com sucesso.")

    def salvar_e_fechar(self):
        self.salvar_progresso_automatico()
        QMessageBox.information(self, "Progresso Salvo", "O rascunho da análise foi armazenado com sucesso.")
        self.reject()

    def concluir_e_gerar(self):
        self.recalcular_campos()
        if self.calculos_com_erro:
            detalhes = "\n".join(
                f"• {nome}: {erro}" for nome, erro in self.calculos_com_erro.items()
            )
            QMessageBox.warning(
                self,
                "Erro em campo calculado",
                "Corrija os erros antes de gerar o parecer:\n\n" + detalhes
            )
            return
        self.salvar_progresso_automatico()
        self.resultado_analise = "DEFERIDO" if self.rb_deferido.isChecked() else "INDEFERIDO"
        self.observacoes_gerais = self.txt_obs.toPlainText()
        self.accept()

# ==============================================================================
# EXPORTAÇÃO E IMPORTAÇÃO DE BACKUPS (.ZIP)
# ==============================================================================

def exportar_analises_zip(parent_widget=None):
    caminho_zip, _ = QFileDialog.getSaveFileName(
        parent_widget, "Salvar Pacote de Análises Exportadas", "", "Arquivo Zip (*.zip)"
    )
    if not caminho_zip:
        return

    try:
        with zipfile.ZipFile(caminho_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for pasta_nome, pasta_ref in [
                ("sessoes_analise", PASTA_SESSIONS_ANALISE),
                ("checklists", PASTA_CHECKLISTS),
                ("modelos_doc", PASTA_MODELOS_DOC)
            ]:
                if os.path.exists(pasta_ref):
                    for root, _, files in os.walk(pasta_ref):
                        for file in files:
                            full_p = os.path.join(root, file)
                            arcname = os.path.join(pasta_nome, os.path.relpath(full_p, pasta_ref))
                            zipf.write(full_p, arcname)

        QMessageBox.information(parent_widget, "Sucesso", f"Pacote exportado com sucesso para:\n{caminho_zip}")
    except Exception as e:
        QMessageBox.critical(parent_widget, "Erro", f"Ocorreu uma falha ao exportar o ZIP:\n{e}")


def importar_analises_zip(parent_widget=None):
    caminho_zip, _ = QFileDialog.getOpenFileName(
        parent_widget, "Importar Pacote de Análises", "", "Arquivo Zip (*.zip)"
    )
    if not caminho_zip:
        return

    try:
        with zipfile.ZipFile(caminho_zip, 'r') as zipf:
            zipf.extractall(PASTA_DADOS_PLUGIN)

        QMessageBox.information(parent_widget, "Sucesso", "Dados importados com sucesso para o perfil do plugin!")
    except Exception as e:
        QMessageBox.critical(parent_widget, "Erro", f"Ocorreu uma falha ao importar o ZIP:\n{e}")


# ==============================================================================
# EXECUÇÃO DA ANÁLISE E EMISSÃO DO PARECER VIA DOCXTPL
# ==============================================================================

def executar_analise_urbana(config_analise):
    nome_camada = config_analise["camada"]

    camadas = QgsProject.instance().mapLayersByName(nome_camada)
    if not camadas:
        QMessageBox.warning(iface.mainWindow(), "Erro", f"A camada '{nome_camada}' não foi encontrada.")
        return

    layer = camadas[0]
    feicoes_selecionadas = list(layer.selectedFeatures())

    if not feicoes_selecionadas:
        QMessageBox.warning(iface.mainWindow(), "Aviso", f"Selecione uma feição na camada '{nome_camada}' para analisar.")
        return

    feat_pai = feicoes_selecionadas[0]

    # 1. Extrai dados da feição espacial do QGIS e relações N:M / 1:N
    contexto, relacoes_filho_dict = _extrair_dados_estilo_django(layer, feat_pai)

    # Injeta explicitamente todos os atributos da feição geográfica no dicionário principal
    for field in feat_pai.fields():
        nome_campo = field.name()
        val_campo = feat_pai.attribute(nome_campo)
        val_str = str(val_campo).strip() if val_campo is not None else ""
        contexto[nome_campo] = val_str
        contexto[nome_campo.lower()] = val_str
        contexto[_sanitizar_nome_var(nome_campo)] = val_str

    dlg = DialogoExecucaoAnalise(config_analise, feat_pai, relacoes_filho_dict, iface.mainWindow())
    if dlg.exec_() != QDialog.Accepted:
        return

    # 2. Injeta campos digitáveis simples da checklist (* ...)
    for key, (var_name, txt_widget) in dlg.inputs_digitaveis_map.items():
        val = txt_widget.text().strip()
        contexto[var_name] = val
        contexto[var_name.lower()] = val

    # 3. Injeta campos de arquivos (^ ...) e cria a lista da Aba Alvará
    documentos_alvara = []
    for key, (var_name, txt_widget, padrao_rename, rotulo_orig) in dlg.inputs_arquivos_map.items():
        val = txt_widget.text().strip()
        contexto[var_name] = val
        contexto[var_name.lower()] = val
        nome_exportacao = dlg.inputs_arquivos_nome_exportacao[key].text().strip() or padrao_rename
        
        documentos_alvara.append({
            "var_name": var_name,
            "rotulo": rotulo_orig,
            "padrao_renomear": nome_exportacao,
            "caminho": val if val else None,
            "status": "OK" if val else "FALTANDO"
        })

    contexto["documentos_alvara"] = documentos_alvara

    # 4. Injeta campos adicionáveis (+ ...)
    for var_name, dados_rep in dlg.inputs_adicionaveis_map.items():
        colunas = dados_rep["colunas"]
        lista_estruturada = []
        for inputs_linha in dados_rep["linhas"]:
            item_dict = {}
            for i, col in enumerate(colunas):
                col_key = _sanitizar_nome_var(col)
                val = inputs_linha[i].text().strip() if i < len(inputs_linha) else ""
                item_dict[col_key] = val
            if any(item_dict.values()):
                lista_estruturada.append(item_dict)
        contexto[var_name] = lista_estruturada
        contexto[var_name.lower()] = lista_estruturada

    # 5. Injeta campos calculados (= ...)
    for var_name, (txt_widget, _) in dlg.inputs_calculados_map.items():
        val_txt = txt_widget.text().strip().replace(',', '.')
        try:
            val_final = float(val_txt) if "." in val_txt else int(val_txt)
        except ValueError:
            val_final = val_txt
            
        contexto[var_name] = val_final
        contexto[var_name.lower()] = val_final
        if "__" in var_name:
            contexto[var_name.split("__")[0]] = val_final

    # 6. Captura dos itens não atendidos da checklist (checkboxes desmarcados)
    itens_nao_atendidos = []
    itens_atendidos = []

    for key, cb in dlg.checkboxes_map.items():
        texto_item = cb.text().strip()
        aba_nome = "Checklist Principal"
        if key.startswith("ABA_"):
            partes_k = key.split("_ITEM_")
            aba_nome = partes_k[0].replace("ABA_", "").replace("_", " ").title()
        elif key.startswith("REL_"):
            partes_k = key.split("_ITEM_")
            aba_nome = partes_k[0].replace("REL_", "").replace("_", " ").title()

        item_info = {
            "chave": key,
            "texto": texto_item,
            "aba": aba_nome,
            "atendido": cb.isChecked()
        }

        if not cb.isChecked():
            itens_nao_atendidos.append(item_info)
        else:
            itens_atendidos.append(item_info)

    contexto["itens_nao_atendidos"] = itens_nao_atendidos
    contexto["itens_atendidos"] = itens_atendidos
    contexto["total_itens_nao_atendidos"] = len(itens_nao_atendidos)

    # 7. MAPEAMENTO DE ALIASES E NOMES AMIGÁVEIS PARA O TEMPLATE DOCX
    # Resolve divergências entre nomes de atributos da camada e nomes de tags no Jinja2
    def buscar_valor_multichaves(*chaves, padrao=""):
        for k in chaves:
            if k in contexto and contexto[k]:
                return contexto[k]
        return padrao

    # Mapeamentos diretos dos campos do cabeçalho
    contexto["processo"] = buscar_valor_multichaves("processo", "numero_do_processo_ou_oficio", "n_processo", "num_processo", "protocolo", padrao="")
    contexto["protocolo"] = buscar_valor_multichaves("protocolo", "numero_do_processo_ou_oficio", "n_protocolo", "processo", padrao="")
    
    # Tratamento para lista de proprietários ou campo único
    prop_val = buscar_valor_multichaves("proprietario", "contribuinte", "proprietarios", "nome_proprietario", padrao="")
    if isinstance(prop_val, list) and prop_val:
        nomes = [f"{p.get('nome', '')} {p.get('qualificacao', '')}".strip() for p in prop_val if isinstance(p, dict)]
        contexto["contribuinte"] = ", ".join(filter(None, nomes))
    else:
        contexto["contribuinte"] = str(prop_val)

    contexto["loteamento"] = buscar_valor_multichaves("loteamento", "nome_loteamento", "nm_loteamento", "titulo", "empreendimento", padrao=config_analise['titulo'])
    contexto["finalidade"] = buscar_valor_multichaves("finalidade", "uso", "tipo_uso", padrao="RESIDENCIAL MISTO")
    contexto["endereco"] = buscar_valor_multichaves("endereco", "rua", "logradouro", "localizacao", padrao="")
    contexto["matricula"] = buscar_valor_multichaves("matricula", "n_matricula", "num_matricula", padrao="")
    contexto["bairro"] = buscar_valor_multichaves("bairro", "nm_bairro", padrao="")
    contexto["zoneamento"] = buscar_valor_multichaves("zoneamento", "sigla_zoneamento", "zona", padrao="")
    contexto["coordenada_utm"] = buscar_valor_multichaves("coordenada_utm", "coordenada", "utm", "coords", padrao="")

    # Seleção do modelo Word
    template_path = config_analise["template_deferido"] if dlg.resultado_analise == "DEFERIDO" else config_analise["template_indeferido"]

    if not os.path.exists(template_path):
        QMessageBox.critical(iface.mainWindow(), "Erro", f"O modelo Word não foi localizado em:\n{template_path}")
        return

    pasta_destino = QFileDialog.getExistingDirectory(iface.mainWindow(), "Selecione a Pasta para Salvar o Parecer")
    if not pasta_destino:
        return

    contexto["resultado_analise"] = dlg.resultado_analise
    contexto["observacoes_analise"] = dlg.observacoes_gerais
    contexto["tecnico_nome"] = config_analise["tecnico_nome"]
    contexto["tecnico_cargo"] = config_analise["tecnico_cargo"]
    contexto["tecnico_linha_add"] = config_analise["tecnico_linha_add"]
    contexto["data_extenso"] = datetime.now().strftime('%d de %B de %Y')
    contexto["ano"] = datetime.now().year

    try:
        DocxTemplate = obter_docx_template()
        doc = DocxTemplate(template_path)
        doc.render(contexto)

        nome_saida = f"Parecer_{dlg.resultado_analise}_{config_analise['titulo']}_ID_{feat_pai.id()}.docx"
        caminho_final = os.path.join(pasta_destino, re.sub(r'[\\/*?:"<>|]', "-", nome_saida))
        doc.save(caminho_final)

        os.startfile(pasta_destino)
        QMessageBox.information(iface.mainWindow(), "Sucesso", f"Parecer gerado com sucesso em:\n{caminho_final}")
    except Exception as e:
        QMessageBox.critical(iface.mainWindow(), "Erro na Renderização do Template", f"Falha ao gerar o documento Word:\n{e}")

# ==============================================================================
# FORMULÁRIOS DE CONFIGURAÇÃO DO PLUGIN
# ==============================================================================

class FormEdicaoAnaliseDialog(QDialog):
    def __init__(self, analise_dados=None, parent=None):
        super().__init__(parent)
        self.analise_dados = analise_dados
        self.dados_resultado = None

        self.setWindowTitle("Editar Configuração de Análise" if analise_dados else "Nova Configuração de Análise")
        self.resize(760, 650)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        form_layout = QFormLayout()

        self.txt_titulo = QLineEdit()
        self.txt_titulo.textChanged.connect(self.atualizar_visibilidade_botoes)
        form_layout.addRow("Título da Análise:", self.txt_titulo)

        self.combo_camadas = QComboBox()
        form_layout.addRow("Camada Principal (Pai):", self.combo_camadas)

        self.txt_etapa_vinculada = QLineEdit()
        self.txt_etapa_vinculada.setPlaceholderText("Ex: DIAGNÓSTICO (Deixe em branco para todas)")
        form_layout.addRow("Etapa Vinculada:", self.txt_etapa_vinculada)

        # Template Deferido
        h_def = QHBoxLayout()
        self.txt_path_def = QLineEdit()
        self.txt_path_def.setReadOnly(True)
        self.txt_path_def.textChanged.connect(self.atualizar_visibilidade_botoes)

        btn_b_def = QPushButton("Buscar .docx...")
        btn_b_def.clicked.connect(lambda: self._buscar_arquivo(self.txt_path_def, "Word (*.docx)"))

        self.btn_edit_def = QPushButton("✏️")
        self.btn_edit_def.clicked.connect(lambda: self._abrir_arquivo_externo(self.txt_path_def.text()))

        self.btn_clear_def = QPushButton("🗑️")
        self.btn_clear_def.clicked.connect(self.txt_path_def.clear)

        self.btn_gen_def = QPushButton("📄 Gerar Modelo Deferimento")
        self.btn_gen_def.setStyleSheet("font-weight: bold; color: #2e7d32;")
        self.btn_gen_def.clicked.connect(lambda: self.gerar_modelo_doc_direto("DEFERIDO"))

        h_def.addWidget(self.txt_path_def)
        h_def.addWidget(btn_b_def)
        h_def.addWidget(self.btn_edit_def)
        h_def.addWidget(self.btn_clear_def)
        h_def.addWidget(self.btn_gen_def)
        form_layout.addRow("Modelo Deferimento:", h_def)

        # Template Indeferido
        h_indef = QHBoxLayout()
        self.txt_path_indef = QLineEdit()
        self.txt_path_indef.setReadOnly(True)
        self.txt_path_indef.textChanged.connect(self.atualizar_visibilidade_botoes)

        btn_b_indef = QPushButton("Buscar .docx...")
        btn_b_indef.clicked.connect(lambda: self._buscar_arquivo(self.txt_path_indef, "Word (*.docx)"))

        self.btn_edit_indef = QPushButton("✏️")
        self.btn_edit_indef.clicked.connect(lambda: self._abrir_arquivo_externo(self.txt_path_indef.text()))

        self.btn_clear_indef = QPushButton("🗑️")
        self.btn_clear_indef.clicked.connect(self.txt_path_indef.clear)

        self.btn_gen_indef = QPushButton("📄 Gerar Modelo Indeferimento")
        self.btn_gen_indef.setStyleSheet("font-weight: bold; color: #c62828;")
        self.btn_gen_indef.clicked.connect(lambda: self.gerar_modelo_doc_direto("INDEFERIDO"))

        h_indef.addWidget(self.txt_path_indef)
        h_indef.addWidget(btn_b_indef)
        h_indef.addWidget(self.btn_edit_indef)
        h_indef.addWidget(self.btn_clear_indef)
        h_indef.addWidget(self.btn_gen_indef)
        form_layout.addRow("Modelo Indeferimento:", h_indef)

        # Checklist TXT
        self.txt_path_chk = QLineEdit()
        self.txt_path_chk.setReadOnly(True)
        self.txt_path_chk.textChanged.connect(self.atualizar_visibilidade_botoes)

        self.btn_importar_chk = QPushButton("📥 Importar (.txt)")
        self.btn_importar_chk.clicked.connect(self.importar_checklist_para_plugin)

        self.btn_edit_chk = QPushButton("✏️")
        self.btn_edit_chk.clicked.connect(lambda: self._abrir_arquivo_externo(self.txt_path_chk.text()))

        self.btn_clear_chk = QPushButton("🗑️")
        self.btn_clear_chk.clicked.connect(self.txt_path_chk.clear)

        self.btn_gerar_modelo_chk = QPushButton("📄 Gerar Modelo TXT")
        self.btn_gerar_modelo_chk.setStyleSheet("font-weight: bold; color: #2e7d32;")
        self.btn_gerar_modelo_chk.clicked.connect(self.gerar_modelo_direto)

        h_chk_controls = QHBoxLayout()
        h_chk_controls.addWidget(self.txt_path_chk)
        h_chk_controls.addWidget(self.btn_importar_chk)
        h_chk_controls.addWidget(self.btn_edit_chk)
        h_chk_controls.addWidget(self.btn_clear_chk)
        h_chk_controls.addWidget(self.btn_gerar_modelo_chk)

        form_layout.addRow("Checklist (.txt):", h_chk_controls)

        grp_tec = QGroupBox("Dados da Assinatura Técnica / Responsável")
        lay_tec = QFormLayout()

        self.txt_tec_nome = QLineEdit()
        self.txt_tec_cargo = QLineEdit()
        self.txt_tec_linha_add = QLineEdit()
        lay_tec.addRow("Nome do Técnico:", self.txt_tec_nome)
        lay_tec.addRow("Cargo / Função:", self.txt_tec_cargo)
        lay_tec.addRow("Linha Adicional:", self.txt_tec_linha_add)
        grp_tec.setLayout(lay_tec)

        layout.addLayout(form_layout)
        layout.addWidget(grp_tec)

        self.popula_camadas()

        if self.analise_dados:
            self.txt_titulo.setText(self.analise_dados.get("titulo", ""))
            idx = self.combo_camadas.findText(self.analise_dados.get("camada", ""))
            if idx >= 0:
                self.combo_camadas.setCurrentIndex(idx)
            self.txt_etapa_vinculada.setText(self.analise_dados.get("etapa", ""))
            self.txt_path_def.setText(self.analise_dados.get("template_deferido", ""))
            self.txt_path_indef.setText(self.analise_dados.get("template_indeferido", ""))
            self.txt_path_chk.setText(self.analise_dados.get("checklist_path", ""))
            self.txt_tec_nome.setText(self.analise_dados.get("tecnico_nome", ""))
            self.txt_tec_cargo.setText(self.analise_dados.get("tecnico_cargo", ""))
            self.txt_tec_linha_add.setText(self.analise_dados.get("tecnico_linha_add", ""))

        self.atualizar_visibilidade_botoes()

        botoes = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        botoes.accepted.connect(self.salvar)
        botoes.rejected.connect(self.reject)
        layout.addWidget(botoes)

    def popula_camadas(self):
        self.combo_camadas.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayerType.VectorLayer:
                self.combo_camadas.addItem(layer.name())

    def _buscar_arquivo(self, campo_txt, filtro):
        caminho, _ = QFileDialog.getOpenFileName(self, "Selecione o Arquivo", "", filtro)
        if caminho:
            campo_txt.setText(caminho)

    def _abrir_arquivo_externo(self, caminho_arquivo):
        if caminho_arquivo and os.path.exists(caminho_arquivo):
            try:
                os.startfile(caminho_arquivo)
            except Exception as e:
                QMessageBox.critical(self, "Erro", f"Não foi possível abrir:\n{e}")

    def atualizar_visibilidade_botoes(self):
        has_def = bool(self.txt_path_def.text().strip())
        has_indef = bool(self.txt_path_indef.text().strip())
        has_chk = bool(self.txt_path_chk.text().strip())

        self.btn_gen_def.setVisible(not has_def)
        self.btn_edit_def.setVisible(has_def)
        self.btn_clear_def.setVisible(has_def)

        self.btn_gen_indef.setVisible(not has_indef)
        self.btn_edit_indef.setVisible(has_indef)
        self.btn_clear_indef.setVisible(has_indef)

        self.btn_gerar_modelo_chk.setVisible(not has_chk)
        self.btn_edit_chk.setVisible(has_chk)
        self.btn_clear_chk.setVisible(has_chk)

    def importar_checklist_para_plugin(self):
        caminho_origem, _ = QFileDialog.getOpenFileName(self, "Selecionar Checklist", PASTA_CHECKLISTS, "Texto (*.txt)")
        if not caminho_origem:
            return
        nome_arquivo = os.path.basename(caminho_origem)
        caminho_destino = os.path.join(PASTA_CHECKLISTS, nome_arquivo)
        if os.path.abspath(caminho_origem) != os.path.abspath(caminho_destino):
            shutil.copy2(caminho_origem, caminho_destino)
        self.txt_path_chk.setText(caminho_destino)

    def gerar_modelo_direto(self):
        titulo = self.txt_titulo.text().strip() or "Nova Análise"
        caminho_criado = criar_modelo_checklist_padrao(titulo, self.combo_camadas.currentText())
        self.txt_path_chk.setText(caminho_criado)
        QMessageBox.information(self, "Sucesso", f"Checklist criado em:\n{caminho_criado}")

    def gerar_modelo_doc_direto(self, tipo_resultado):
        titulo = self.txt_titulo.text().strip() or "Nova Análise"
        caminho_doc = gerar_template_word_base(titulo, tipo_resultado, self.combo_camadas.currentText())
        if tipo_resultado == "DEFERIDO":
            self.txt_path_def.setText(caminho_doc)
        else:
            self.txt_path_indef.setText(caminho_doc)
        QMessageBox.information(self, "Sucesso", f"Modelo criado em:\n{caminho_doc}")

    def salvar(self):
        if not self.txt_titulo.text().strip() or not self.txt_path_def.text() or not self.txt_path_chk.text():
            QMessageBox.warning(self, "Aviso", "Preencha o título, modelos Word e o checklist!")
            return

        self.dados_resultado = {
            "titulo": self.txt_titulo.text().strip(),
            "camada": self.combo_camadas.currentText(),
            "template_deferido": self.txt_path_def.text(),
            "template_indeferido": self.txt_path_indef.text(),
            "checklist_path": self.txt_path_chk.text(),
            "tecnico_nome": self.txt_tec_nome.text().strip(),
            "tecnico_cargo": self.txt_tec_cargo.text().strip(),
            "tecnico_linha_add": self.txt_tec_linha_add.text().strip(),
            "etapa": self.txt_etapa_vinculada.text().strip().upper()
        }
        self.accept()


class GerenciadorAnalisesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configurar Análises e Checklists")
        self.resize(650, 400)
        self.analises = carregar_config_analises()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("<b>Análises Técnicas Cadastradas:</b>"))
        self.list_widget = QListWidget()
        self.atualizar_lista()
        layout.addWidget(self.list_widget)

        btn_layout = QHBoxLayout()
        btn_add = QPushButton("➕ Adicionar Análise")
        btn_add.clicked.connect(self.adicionar)
        btn_edit = QPushButton("✏️ Editar")
        btn_edit.clicked.connect(self.editar)
        btn_del = QPushButton("❌ Remover")
        btn_del.clicked.connect(self.remover)
        btn_layout.addWidget(btn_add)
        btn_layout.addWidget(btn_edit)
        btn_layout.addWidget(btn_del)
        layout.addLayout(btn_layout)

        botoes = QDialogButtonBox(QDialogButtonBox.Close)
        botoes.rejected.connect(self.accept)
        layout.addWidget(botoes)

    def atualizar_lista(self):
        self.list_widget.clear()
        for a in self.analises:
            etapa_str = f" [Etapa: {a['etapa']}]" if a.get('etapa') else ""
            self.list_widget.addItem(f"{a['titulo']}{etapa_str}  --->  Camada: {a['camada']}")

    def adicionar(self):
        dlg = FormEdicaoAnaliseDialog(parent=self)
        if dlg.exec_() == QDialog.Accepted and dlg.dados_resultado:
            self.analises.append(dlg.dados_resultado)
            salvar_config_analises(self.analises)
            self.atualizar_lista()

    def editar(self):
        row = self.list_widget.currentRow()
        if row < 0:
            return
        dlg = FormEdicaoAnaliseDialog(analise_dados=self.analises[row], parent=self)
        if dlg.exec_() == QDialog.Accepted and dlg.dados_resultado:
            self.analises[row] = dlg.dados_resultado
            salvar_config_analises(self.analises)
            self.atualizar_lista()

    def remover(self):
        row = self.list_widget.currentRow()
        if row >= 0:
            del self.analises[row]
            salvar_config_analises(self.analises)
            self.atualizar_lista()


def abrir_gerenciador_analises():
    dlg = GerenciadorAnalisesDialog(iface.mainWindow())
    dlg.exec_()