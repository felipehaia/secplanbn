import os
import re
import locale
from datetime import datetime
from docx import Document
from docx.shared import Inches
from PyQt5.QtWidgets import (
    QMessageBox, QDialog, QFormLayout, QLineEdit, 
    QComboBox, QDialogButtonBox
)
from qgis.core import (
    QgsProject, QgsRectangle, QgsLayoutExporter
)

def run():
    print("Executando Gerar Parecer Parcelamento do Solo...")
    
    # Pasta de saída
    output_folder = r"C:\temp\lotes_docx"
    os.makedirs(output_folder, exist_ok=True)
    
    # Camada de entrada no QGIS
    layer_name = "VIABILIDADE-PARCELAMENTO-DO-SOLO"
    layers = QgsProject.instance().mapLayersByName(layer_name)
    
    if not layers:
        QMessageBox.warning(None, "SECPlanBN", f"A camada '{layer_name}' não foi localizada.")
        return
    layer = layers[0]

    if not layer.selectedFeatures():
        QMessageBox.warning(None, "SECPlanBN", "Selecione pelo menos um elemento na camada para gerar o parecer.")
        return

    # Caixa de diálogo para seleções e revisões
    class RevisaoModeloDialog(QDialog):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Informar Revisões e Modelo de Parecer")
            layout = QFormLayout(self)

            self.revisao_projeto = QLineEdit(self)
            layout.addRow("Nº Revisão do Projeto:", self.revisao_projeto)

            self.revisao_memorial = QLineEdit(self)
            layout.addRow("Nº Revisão do Memorial:", self.revisao_memorial)

            self.modelo_combo = QComboBox(self)
            self.modelo_combo.addItems([
                "Loteamento - Anteprojeto",
                "Loteamento - Urbanístico",
                "Loteamento - Complementares",
                "Desmembramento - Urbanístico",
                "Desmembramento - Infraestrutura"
            ])
            layout.addRow("Modelo de Parecer:", self.modelo_combo)

            buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            layout.addWidget(buttons)

    dlg = RevisaoModeloDialog()
    if dlg.exec_() != QDialog.Accepted:
        return

    revisao_projeto = dlg.revisao_projeto.text().strip()
    revisao_memorial = dlg.revisao_memorial.text().strip()
    modelo_parecer = dlg.modelo_combo.currentText()

    # Mapeamento do item selecionado para o nome do arquivo .docx
    template_map = {
        "Loteamento - Anteprojeto": "TEMPLATE_LOTEAMENTO_ANTEPROJETO",
        "Loteamento - Urbanístico": "TEMPLATE_LOTEAMENTO_URBANISTICO",
        "Loteamento - Complementares": "TEMPLATE_LOTEAMENTO_COMPLEMENTARES",
        "Desmembramento - Urbanístico": "TEMPLATE_DESMEMBRAMENTO_URBANISTICO",
        "Desmembramento - Infraestrutura": "TEMPLATE_DESMEMBRAMENTO_INFRAESTRUTURA"
    }
    
    template_name = template_map[modelo_parecer]
    plugin_dir = os.path.dirname(__file__)
    template_path = os.path.join(plugin_dir, "modelos", f"{template_name}.docx")

    if not os.path.exists(template_path):
        QMessageBox.warning(None, "Arquivo não encontrado", f"O modelo não foi localizado em:\n{template_path}")
        return

    # Substituição de tags mantendo os 'runs' e imagens intactos
    def processar_paragrafos(paragraphs, context, imagem_croqui=None):
        for paragraph in paragraphs:
            texto_completo = "".join([run.text for run in paragraph.runs])
            
            if "{{ croqui }}" in texto_completo and imagem_croqui:
                paragraph.clear()
                paragraph.add_run().add_picture(imagem_croqui, width=Inches(5))
            else:
                for run in paragraph.runs:
                    if "{" in run.text:
                        for chave, valor in context.items():
                            tag = f"{{{{ {chave} }}}}"
                            if tag in run.text:
                                run.text = run.text.replace(tag, str(valor))

    def processar_tabelas(tables, context, imagem_croqui=None):
        for table in tables:
            for row in table.rows:
                for cell in row.cells:
                    processar_paragrafos(cell.paragraphs, context, imagem_croqui)
                    processar_tabelas(cell.tables, context, imagem_croqui)

    def obter_data_por_extenso():
        try:
            locale.setlocale(locale.LC_TIME, 'pt_BR.utf8')
        except locale.Error:
            try:
                locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil.1252')
            except locale.Error:
                pass
        return datetime.now().strftime('%d de %B de %Y')

    # Processamento dos registros selecionados
    for feature in layer.selectedFeatures():
        qualificacao_contribuinte = " ".join((feature["qualificacao_contribuinte"] or "").split())
        qualificacao_procurador = " ".join((feature["qualificacao_procurador"] or "").split())

        lista_original = feature["lotes_desmembrados"]
        lista_join = "\n".join(map(str, lista_original)) if isinstance(lista_original, list) else str(lista_original or "")

        context = {
            "contribuinte": feature["proprieta"],
            "protocolo": feature["protocolo"],
            "bairro": feature["bairro"],
            "matricula": feature["matricula(s)"],
            "rua": feature["rua"],
            "denominacao": feature["nome"],
            "coordenadas": feature["coorde"],
            "zoneamento": feature["zoneamento"],
            "qualificacao_contribuinte": qualificacao_contribuinte,
            "qualificacao_procurador": qualificacao_procurador,
            "numero_lotes": feature["n_lotes"],
            "processo": feature["n_processo"],
            "inscricao": feature["inscricao"],
            "area_total": feature["area_total"],
            "revisao_projeto": revisao_projeto,
            "revisao_memorial": revisao_memorial,
            "lista": lista_join,
            "data_extenso": obter_data_por_extenso()
        }

        # Exportação do croqui caso o layout exista
        imagem_croqui = r"C:\temp\croqui_imagem.png"
        layout = QgsProject.instance().layoutManager().layoutByName('VIABILIDADE CONSTRUÇÃO')

        if layout:
            map_item = layout.itemById('Mapa 1')
            if map_item:
                extent = feature.geometry().boundingBox()
                map_item.setExtent(QgsRectangle(
                    extent.xMinimum() - 100,
                    extent.yMinimum() - 100,
                    extent.xMaximum() + 100,
                    extent.yMaximum() + 100
                ))
                map_item.setScale(map_item.scale() * 1.05)
                map_item.refresh()

                exporter = QgsLayoutExporter(layout)
                exporter.exportToImage(imagem_croqui, QgsLayoutExporter.ImageExportSettings())

        # Carrega o modelo Word
        doc = Document(template_path)

        # 1. Processa estritamente o corpo principal do documento e tabelas
        processar_paragrafos(doc.paragraphs, context, imagem_croqui)
        processar_tabelas(doc.tables, context, imagem_croqui)

        # 2. Processa o cabeçalho e rodapé SOMENTE se houver variáveis {{ }} contidas neles
        for section in doc.sections:
            # Cabeçalho
            texto_cabecalho = "".join([p.text for p in section.header.paragraphs])
            if "{{" in texto_cabecalho:
                for p in section.header.paragraphs:
                    if "{{" in p.text:
                        processar_paragrafos([p], context, imagem_croqui)
                for t in section.header.tables:
                    processar_tabelas([t], context, imagem_croqui)

            # Rodapé
            texto_rodape = "".join([p.text for p in section.footer.paragraphs])
            if "{{" in texto_rodape:
                for p in section.footer.paragraphs:
                    if "{{" in p.text:
                        processar_paragrafos([p], context, imagem_croqui)
                for t in section.footer.tables:
                    processar_tabelas([t], context, imagem_croqui)

        # Salvar o documento final
        nome_limpo = re.sub(r'[\\/*?:"<>|]', "-", f"{feature['protocolo']}_{feature['proprieta']}")
        output_path = os.path.join(output_folder, f"{nome_limpo}.docx")
        
        doc.save(output_path)
        QMessageBox.information(None, "SECPlanBN", f"Parecer gerado com sucesso:\n{output_path}")
        os.startfile(output_path)