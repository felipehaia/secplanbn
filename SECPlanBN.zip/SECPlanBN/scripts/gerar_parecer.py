from qgis.core import *
from PyQt5.QtWidgets import *
import os, re, locale
from datetime import datetime
from docx import Document
from docx.shared import Inches
from PyQt5.QtWidgets import QMessageBox

def run():
    # código original adaptado
    print("Rodando Gerar Parecer Parcelamento do Solo...")
    import os
    import re
    from docx import Document
    from qgis.core import (
        QgsProject, Qgis, QgsLayoutItemMap, QgsRectangle,
        QgsVectorFileWriter, QgsFeature, QgsFields, QgsField, QgsVectorLayer
    )
    from qgis.utils import iface
    from datetime import datetime
    from docx.shared import Inches
    from PyQt5.QtCore import QVariant
    import locale
    from PyQt5.QtWidgets import QInputDialog, QDialog, QFormLayout, QLineEdit, QDialogButtonBox
    
    # Caminhos
    output_folder = r"C:\temp\lotes_docx"
    os.makedirs(output_folder, exist_ok=True)
    
    # Parâmetros
    layer_name = "VIABILIDADE-PARCELAMENTO-DO-SOLO"
    
    # Carrega a camada principal
    layers = QgsProject.instance().mapLayersByName(layer_name)
    if not layers:
        QMessageBox.warning(None, "SECPlanBN", "Não foi possível localizar a layer")
    layer = layers[0]
    
    # Função para substituir {{ chave }} pelas variáveis do context
    def substituir_variaveis(texto, context):
        for chave, valor in context.items():
            texto = texto.replace(f"{{{{ {chave} }}}}", str(valor))
        return texto
    
    # Função para processar parágrafos
    def processar_paragrafos(paragraphs, context):
        for paragraph in paragraphs:
            texto_completo = "".join([run.text for run in paragraph.runs])
            novo_texto = substituir_variaveis(texto_completo, context)
            
            if "{{ croqui }}" in novo_texto:
                paragraph.clear()
                paragraph.add_run().add_picture(imagem_croqui, width=Inches(5))
            else:
                for run in paragraph.runs:
                    run.text = ""
                if paragraph.runs:
                    paragraph.runs[0].text = novo_texto
    
    # Função para processar tabelas (incluindo tabelas aninhadas)
    def processar_tabelas(tables, context):
        for table in tables:
            for row in table.rows:
                for cell in row.cells:
                    processar_paragrafos(cell.paragraphs, context)
                    processar_tabelas(cell.tables, context)
    
    # Função para limpar o nome do arquivo
    def limpar_nome_arquivo(texto):
        return re.sub(r'[\\/*?:"<>|]', "-", texto)
    
    # Define idioma da localização
    locale.setlocale(locale.LC_TIME, 'Portuguese_Brazil.1252')
    
    # Função para obter a data por extenso
    def obter_data_por_extenso():
        data_atual = datetime.now()
        return data_atual.strftime('%d de %B de %Y')
    
    
    # Executa a geração de documentos
    # Pede o número da revisão
    
    class RevisaoDialog(QDialog):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Informar Revisões")
    
            layout = QFormLayout(self)
    
            # Campo 1 - Revisão do Projeto
            self.revisao_projeto = QLineEdit(self)
            layout.addRow("Nº Revisão do Projeto:", self.revisao_projeto)
    
            # Campo 2 - Revisão do Memorial
            self.revisao_memorial = QLineEdit(self)
            layout.addRow("Nº Revisão do Memorial:", self.revisao_memorial)
    
            # Botões OK / Cancelar
            buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            layout.addWidget(buttons)
    
    # --- Uso no script ---
    from PyQt5.QtWidgets import QDialog, QFormLayout, QLineEdit, QDialogButtonBox, QComboBox
    
    class RevisaoModeloDialog(QDialog):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Informar Revisões e Modelo de Parecer")
    
            layout = QFormLayout(self)
    
            # Campo 1 - Revisão do Projeto
            self.revisao_projeto = QLineEdit(self)
            layout.addRow("Nº Revisão do Projeto:", self.revisao_projeto)
    
            # Campo 2 - Revisão do Memorial
            self.revisao_memorial = QLineEdit(self)
            layout.addRow("Nº Revisão do Memorial:", self.revisao_memorial)
    
            # Campo 3 - Seleção do Modelo
            self.modelo_combo = QComboBox(self)
            self.modelo_combo.addItems([
                "Loteamento - Anteprojeto",
                "Loteamento - Urbanístico",
                "Loteamento - Complementares",
                "Desmembramento - Urbanístico",
                "Desmembramento - Infraestrutura"
            ])
            layout.addRow("Modelo de Parecer:", self.modelo_combo)
    
            # Botões OK / Cancelar
            buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            layout.addWidget(buttons)
    
    
    dlg = RevisaoModeloDialog()
    if dlg.exec_() == QDialog.Accepted:
        revisao_projeto = dlg.revisao_projeto.text().strip()
        revisao_memorial = dlg.revisao_memorial.text().strip()
        modelo_parecer = dlg.modelo_combo.currentText()
        # Dicionário de mapeamento
        template_map = {
            "Loteamento - Anteprojeto": "TEMPLATE_LOTEAMENTO_ANTEPROJETO",
            "Loteamento - Urbanístico": "TEMPLATE_LOTEAMENTO_URBANISTICO",
            "Loteamento - Complementares": "TEMPLATE_LOTEAMENTO_COMPLEMENTARES",
            "Desmembramento - Urbanístico": "TEMPLATE_DESMEMBRAMENTO_URBANISTICO",
            "Desmembramento - Infraestrutura": "TEMPLATE_DESMEMBRAMENTO_INFRAESTRUTURA"
        }
        
        # Pega a opção escolhida no combo
        modelo_parecer = dlg.modelo_combo.currentText()
    
        # Usa o mapeamento para pegar o nome do arquivo
        template_name = template_map[modelo_parecer]
        plugin_dir = os.path.dirname(__file__)
        template_path = os.path.join(plugin_dir, "modelos", f"{template_name}.docx")
        if revisao_projeto:  # Só continua se o usuário não cancelou e preencheu
            if not layer.selectedFeatures():
                QMessageBox.warning(None, "SECPlanBN", "Selecione um elemento na camada para gerar o parecer.")
            else:
                for feature in layer.selectedFeatures():
                    
                    if not os.path.exists(template_path):
                        QMessageBox.warning(None, "Arquivo não encontrado",
                            f"O arquivo de template\n\n{template_path}\n\nnão foi encontrado. Verifique o caminho e tente novamente.")
                        # Aqui você pode decidir:
                        # - interromper o processamento
                        # - ou pular esse feature
                    else:
                        # Código para gerar o doc com docxtpl usando template_path
                        pass
                    
    
                    # Pega o valor do campo, garantindo que não seja None
                    qualificacao_contribuinte = feature["qualificacao_contribuinte"] or ""
                    # Remove quebras de linha e espaços extras
                    qualificacao_contribuinte = " ".join(qualificacao_contribuinte.split())
                    # Pega o valor do campo, garantindo que não seja None
                    qualificacao_procurador = feature["qualificacao_procurador"] or ""
                    # Remove quebras de linha e espaços extras
                    qualificacao_procurador = " ".join(qualificacao_procurador.split())

                    # Recupera a lista do QGIS
                    lista_original = feature["lotes_desmembrados"]

                    # Garante que é uma lista e une com quebras de linha
                    if isinstance(lista_original, list):
                        lista_join = "\n".join(map(str, lista_original))
                    else:
                        lista_join = str(lista_original)

                    # Agora você insere no seu dicionário context
                    context = {
                        "contribuinte": feature["proprieta"],
                        "protocolo": feature["protocolo"],
                        "bairro": feature["bairro"],
                        "matricula": feature["matricula(s)"],
                        "rua": feature["rua"],
                        "denominacao": feature["nome"],
                        "coordenadas": feature["coorde"],
                        "zoneamento": feature["zoneamento"],
                        "qualificacao_contribuinte": qualificacao_contribuinte,
                        "qualificacao_procurador": qualificacao_procurador,
                        "numero_lotes": feature["n_lotes"],
                        "processo": feature["n_processo"],
                        "inscricao": feature["inscricao"],
                        "area_total": feature["area_total"],
                        "revisao_projeto": revisao_projeto,
                        "revisao_memorial": revisao_memorial,
                        "lista": lista_join  # Variável criada acima
                    }
    
        
    
    
    
    
    
            context["data_extenso"] = obter_data_por_extenso()
    
            def copiar_para_area_de_estudo(feicao):
                area_de_estudo_layer = QgsProject.instance().mapLayersByName("ÁREA DE ESTUDO")[0]
                geom = feicao.geometry()
                novo_objeto = QgsFeature()
                novo_objeto.setGeometry(geom)
                area_de_estudo_layer.dataProvider().addFeatures([novo_objeto])
                print("Feição copiada para a camada ÁREA DE ESTUDO com a geometria.")
    
            copiar_para_area_de_estudo(feature)
    
            layout_name = 'VIABILIDADE CONSTRUÇÃO'
            map_item_id = 'Mapa 1'
    
            layout = QgsProject.instance().layoutManager().layoutByName(layout_name)
    
            if layout and feature:
                map_item = layout.itemById(map_item_id)
    
                if map_item:
                    extent = feature.geometry().boundingBox()
                    extent_buffered = QgsRectangle(
                        extent.xMinimum() - 100,
                        extent.yMinimum() - 100,
                        extent.xMaximum() + 100,
                        extent.yMaximum() + 100
                    )
    
                    map_item.setExtent(extent_buffered)
                    map_item.setRect(map_item.rect().x(), map_item.rect().y(), 180, 150)
                    map_item.setScale(map_item.scale() * 1.05)
                    map_item.refresh()
    
                    imagem_croqui = r"C:\temp\croqui_imagem.png"
                    exporter = QgsLayoutExporter(layout)
                    exporter.exportToImage(imagem_croqui, QgsLayoutExporter.ImageExportSettings())
                    print(f"Croqui exportado para {imagem_croqui}")
                else:
                    QMessageBox.warning(None, "Erro", "Item de mapa '{map_item_id}' não encontrado no layout.")
            else:
                QMessageBox.warning(None, "Erro", "Layout '{layout_name}' não encontrado ou feição inválida.")
    
            doc = Document(template_path)
    
            processar_paragrafos(doc.paragraphs, context)
            processar_tabelas(doc.tables, context)
    
            for section in doc.sections:
                processar_paragrafos(section.header.paragraphs, context)
                processar_tabelas(section.header.tables, context)
                processar_paragrafos(section.footer.paragraphs, context)
                processar_tabelas(section.footer.tables, context)
    
            nome_arquivo = limpar_nome_arquivo(str(feature["protocolo"]) + "_" + str(feature["proprieta"]))
            output_path = os.path.join(output_folder, f"{nome_arquivo}.docx")
            doc.save(output_path)
            QMessageBox.warning(None, "SECPlanBN", "Arquivo criado com sucesso.")
    
    
            os.startfile(output_path)
    
    
