import psycopg2
from qgis.core import QgsProject, QgsRelation, QgsVectorLayer, QgsDataSourceUri, QgsEditorWidgetSetup
from qgis.PyQt.QtWidgets import (
    QInputDialog, QLineEdit, QMessageBox, QListWidget, QDialog, 
    QVBoxLayout, QLabel, QDialogButtonBox, QAbstractItemView, QPushButton
)

TABELA_GESTORA_SCHEMA = "public"
TABELA_GESTORA_NAME = "qgis_migrations"

def inicializar_tabela_gestora(conn):
    """Cria a tabela gestora de histórico de migrações no PostgreSQL se não existir."""
    sql = f"""
    CREATE TABLE IF NOT EXISTS {TABELA_GESTORA_SCHEMA}.{TABELA_GESTORA_NAME} (
        id SERIAL PRIMARY KEY,
        nome_relacao VARCHAR(150) NOT NULL UNIQUE,
        tabela_pai_1 VARCHAR(100) NOT NULL,
        tabela_pai_2 VARCHAR(100) NOT NULL,
        tabela_pivo VARCHAR(100) NOT NULL,
        ddl_executado TEXT NOT NULL,
        executado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        executado_por VARCHAR(100) DEFAULT CURRENT_USER
    );
    """
    with conn.cursor() as cur:
        cur.execute(sql)

def vincular_ja_existe(conn, pivo_table):
    """Verifica se a relação N:M já foi cadastrada anteriormente."""
    sql = f"SELECT id FROM {TABELA_GESTORA_SCHEMA}.{TABELA_GESTORA_NAME} WHERE tabela_pivo = %s;"
    with conn.cursor() as cur:
        cur.execute(sql, (pivo_table,))
        return cur.fetchone() is not None

def definir_expressao_exibicao_padrao(layer):
    """Procura o primeiro campo textual da camada para definir como Expressão de Exibição nativa."""
    for field in layer.fields():
        if field.typeName().lower() in ['varchar', 'text', 'string'] and field.name().lower() not in ['id', 'fid']:
            layer.setDisplayExpression(f'"{field.name()}"')
            return field.name()
    return None

def deletar_vinculo_existente(project, host, port, db_selected, user, password):
    """Lê a tabela gestora, permite escolher um vínculo N:M e apaga a tabela pivô no banco + relações no QGIS."""
    try:
        conn = psycopg2.connect(host=host, port=port, user=user, password=password, dbname=db_selected)
        conn.autocommit = False
        
        inicializar_tabela_gestora(conn)
        
        with conn.cursor() as cur:
            cur.execute(f"SELECT id, nome_relacao, tabela_pivo FROM {TABELA_GESTORA_SCHEMA}.{TABELA_GESTORA_NAME};")
            vinculos = cur.fetchall()

        if not vinculos:
            QMessageBox.information(None, "Sem Vínculos", f"Não há vínculos N:M registrados na tabela gestora do banco '{db_selected}'.")
            conn.close()
            return

        opcoes = [f"{v[1]} (Tabela: {v[2]})" for v in vinculos]
        item_sel, ok = QInputDialog.getItem(
            None, "Remover Vínculo N:M", "Selecione o vínculo que deseja APAGAR permanentemente:", opcoes, 0, False
        )
        
        if not ok or not item_sel:
            conn.close()
            return

        idx = opcoes.index(item_sel)
        id_reg, nome_rel, tabela_pivo = vinculos[idx]

        confirm = QMessageBox.question(
            None, "Confirmar Exclusão",
            f"Tem certeza que deseja apagar o vínculo '{nome_rel}'?\n\n"
            f"Isso irá:\n"
            f"1. Apagar a tabela pivô `{tabela_pivo}` no PostgreSQL (dados de associação serão perdidos).\n"
            f"2. Remover o registro em `{TABELA_GESTORA_NAME}`.\n"
            f"3. Remover a camada e as Relações no projeto QGIS.\n\n"
            f"As tabelas originais NÃO serão afetadas.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if confirm != QMessageBox.Yes:
            conn.close()
            return

        schema_pivo, tab_pivo = tabela_pivo.split('.') if '.' in tabela_pivo else ('public', tabela_pivo)

        # 1. Executa DDL no Banco (DROP TABLE + DELETE LOG)
        drop_sql = f'DROP TABLE IF EXISTS "{schema_pivo}"."{tab_pivo}" CASCADE;'
        del_log_sql = f'DELETE FROM {TABELA_GESTORA_SCHEMA}.{TABELA_GESTORA_NAME} WHERE id = %s;'

        with conn.cursor() as cur:
            cur.execute(drop_sql)
            cur.execute(del_log_sql, (id_reg,))

        conn.commit()
        conn.close()

        # 2. Remove Relações do QGIS
        rel_mgr = project.relationManager()
        rels_para_remover = [r.id() for r in rel_mgr.relations().values() if tab_pivo.lower() in r.id().lower()]
        for rel_id in rels_para_remover:
            rel_mgr.removeRelation(rel_id)

        # 3. Remove a Camada Pivô do Painel de Camadas do QGIS
        for lyr in project.mapLayers().values():
            if isinstance(lyr, QgsVectorLayer) and lyr.providerType() == 'postgres':
                uri = QgsDataSourceUri(lyr.source())
                if uri.table().lower() == tab_pivo.lower():
                    project.removeMapLayer(lyr.id())

        QMessageBox.information(None, "Sucesso", f"O vínculo '{nome_rel}' foi removido com sucesso do banco e do projeto QGIS!")

    except Exception as e:
        if 'conn' in locals() and conn:
            conn.rollback()
            conn.close()
        QMessageBox.critical(None, "Erro ao Remover", f"Falha ao apagar o vínculo:\n{e}")

def executar_migracao_nm():
    project = QgsProject.instance()

    # 1. Mapeia os bancos de dados presentes nas camadas do projeto
    bancos_do_projeto = {}
    for layer in project.mapLayers().values():
        if layer.providerType() == 'postgres':
            uri = QgsDataSourceUri(layer.source())
            dbname = uri.database()
            if dbname and dbname not in bancos_do_projeto:
                bancos_do_projeto[dbname] = {
                    'host': uri.host() or 'localhost',
                    'port': uri.port() or '5432'
                }

    if not bancos_do_projeto:
        QMessageBox.warning(None, "Aviso", "Nenhuma camada PostGIS/PostgreSQL ativa encontrada no projeto.")
        return

    # 2. Seleciona o banco alvo
    lista_bancos = list(bancos_do_projeto.keys())
    if len(lista_bancos) == 1:
        db_selected = lista_bancos[0]
    else:
        db_selected, ok = QInputDialog.getItem(
            None, "Seleção de Banco", "Selecione o Banco de Dados do Projeto:", lista_bancos, 0, False
        )
        if not ok or not db_selected:
            return

    host = bancos_do_projeto[db_selected]['host']
    port = bancos_do_projeto[db_selected]['port']

    # 3. Solicitante de credenciais
    user, ok1 = QInputDialog.getText(
        None, "Autenticação PostgreSQL", f"Usuário do banco '{db_selected}':", QLineEdit.Normal, "postgres"
    )
    if not ok1 or not user:
        return

    password, ok2 = QInputDialog.getText(
        None, "Autenticação PostgreSQL", f"Senha para '{user}':", QLineEdit.Password, ""
    )
    if not ok2:
        return

    # DIÁLOGO DE ESCOLHA DA AÇÃO: CRIAR OU DELETAR
    dialog_acao = QDialog()
    dialog_acao.setWindowTitle(f"Gestor de Vínculos N:M — [{db_selected}]")
    layout_acao = QVBoxLayout()
    layout_acao.addWidget(QLabel("Escolha a ação que deseja realizar:"))

    btn_criar = QPushButton(" Criar Novo Vínculo N:M")
    btn_criar.setStyleSheet("font-weight: bold; padding: 10px; background-color: #2b8cbe; color: white;")
    btn_deletar = QPushButton(" Apagar Vínculo N:M Existente")
    btn_deletar.setStyleSheet("padding: 10px; background-color: #e41a1c; color: white;")

    layout_acao.addWidget(btn_criar)
    layout_acao.addWidget(btn_deletar)
    dialog_acao.setLayout(layout_acao)

    acao_escolhida = [None]

    def selecionar_criar():
        acao_escolhida[0] = 'CRIAR'
        dialog_acao.accept()

    def selecionar_deletar():
        acao_escolhida[0] = 'DELETAR'
        dialog_acao.accept()

    btn_criar.clicked.connect(selecionar_criar)
    btn_deletar.clicked.connect(selecionar_deletar)

    if not dialog_acao.exec_() or not acao_escolhida[0]:
        return

    # Redireciona para deleção se selecionado
    if acao_escolhida[0] == 'DELETAR':
        deletar_vinculo_existente(project, host, port, db_selected, user, password)
        return

    # 4. Filtra apenas as camadas do banco selecionado para CRIAÇÃO
    vector_layers = []
    for lyr in project.mapLayers().values():
        if isinstance(lyr, QgsVectorLayer) and lyr.providerType() == 'postgres':
            uri = QgsDataSourceUri(lyr.source())
            if uri.database() == db_selected:
                vector_layers.append(lyr)

    if len(vector_layers) < 2:
        QMessageBox.warning(
            None, "Camadas Insuficientes", f"O banco '{db_selected}' possui menos de 2 camadas carregadas no projeto."
        )
        return

    layer_names = [lyr.name() for lyr in vector_layers]

    # Interface de seleção das 2 camadas
    dialog = QDialog()
    dialog.setWindowTitle(f"Seleção de Camadas — [{db_selected}]")
    layout = QVBoxLayout()
    layout.addWidget(QLabel(f"Selecione EXATAMENTE 2 camadas do banco '{db_selected}' para vincular:"))
    
    list_widget = QListWidget()
    list_widget.addItems(layer_names)
    list_widget.setSelectionMode(QAbstractItemView.MultiSelection)
    layout.addWidget(list_widget)

    buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    buttons.accepted.connect(dialog.accept)
    buttons.rejected.connect(dialog.reject)
    layout.addWidget(buttons)
    dialog.setLayout(layout)

    if not dialog.exec_() or len(list_widget.selectedItems()) != 2:
        QMessageBox.warning(None, "Seleção Inválida", "É necessário selecionar exatamente duas camadas.")
        return

    selected_names = [item.text() for item in list_widget.selectedItems()]
    layer1 = next(l for l in vector_layers if l.name() == selected_names[0])
    layer2 = next(l for l in vector_layers if l.name() == selected_names[1])

    uri1 = QgsDataSourceUri(layer1.source())
    uri2 = QgsDataSourceUri(layer2.source())

    schema1 = uri1.schema() if uri1.schema() else 'public'
    table1 = uri1.table()
    pk1 = uri1.keyColumn() if uri1.keyColumn() else f"id_{table1.lower()}"

    schema2 = uri2.schema() if uri2.schema() else 'public'
    table2 = uri2.table()
    pk2 = uri2.keyColumn() if uri2.keyColumn() else f"id_{table2.lower()}"

    pivo_table = f"{table1.lower()}_{table2.lower()}"
    pivo_schema = schema1
    nome_relacao = f"rel_nm_{table1.lower()}_{table2.lower()}"

    col_fk1 = f"fk_{table1.lower()}"
    col_fk2 = f"fk_{table2.lower()}"

    # 5. Execução DDL no PostgreSQL
    try:
        conn = psycopg2.connect(host=host, port=port, user=user, password=password, dbname=db_selected)
        conn.autocommit = False
        
        inicializar_tabela_gestora(conn)

        if vincular_ja_existe(conn, pivo_table):
            QMessageBox.information(
                None, "Vínculo Existente", 
                f"A relação N:M entre '{table1}' e '{table2}' já está registrada na tabela gestora `{TABELA_GESTORA_NAME}`."
            )
            conn.close()
            return

        ddl_sql = f"""
        CREATE TABLE IF NOT EXISTS "{pivo_schema}"."{pivo_table}" (
            "{col_fk1}" INT NOT NULL REFERENCES "{schema1}"."{table1}"("{pk1}") ON DELETE CASCADE ON UPDATE CASCADE,
            "{col_fk2}" INT NOT NULL REFERENCES "{schema2}"."{table2}"("{pk2}") ON DELETE CASCADE ON UPDATE CASCADE,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            observacao TEXT,
            PRIMARY KEY ("{col_fk1}", "{col_fk2}")
        );

        CREATE INDEX IF NOT EXISTS "idx_{pivo_table}_{col_fk1}" ON "{pivo_schema}"."{pivo_table}"("{col_fk1}");
        CREATE INDEX IF NOT EXISTS "idx_{pivo_table}_{col_fk2}" ON "{pivo_schema}"."{pivo_table}"("{col_fk2}");
        """

        with conn.cursor() as cur:
            cur.execute(ddl_sql)
            insert_log = f"""
            INSERT INTO {TABELA_GESTORA_SCHEMA}.{TABELA_GESTORA_NAME} 
            (nome_relacao, tabela_pai_1, tabela_pai_2, tabela_pivo, ddl_executado)
            VALUES (%s, %s, %s, %s, %s);
            """
            cur.execute(insert_log, (nome_relacao, f"{schema1}.{table1}", f"{schema2}.{table2}", f"{pivo_schema}.{pivo_table}", ddl_sql.strip()))

        conn.commit()
        conn.close()

    except Exception as e:
        if 'conn' in locals() and conn:
            conn.rollback()
            conn.close()
        QMessageBox.critical(None, "Erro de Migração", f"Falha ao criar o vínculo no banco '{db_selected}':\n{e}")
        return

    # 6. Carrega a Tabela Pivô e Configura Relações + Form Widgets no QGIS
    uri_pivo = QgsDataSourceUri()
    uri_pivo.setConnection(host, port, db_selected, user, password)
    uri_pivo.setDataSource(pivo_schema, pivo_table, None, "", f"{col_fk1},{col_fk2}")
    
    pivo_layer = QgsVectorLayer(uri_pivo.uri(), pivo_table, "postgres")
    if not pivo_layer.isValid():
        QMessageBox.warning(None, "Aviso", f"Vínculo criado no banco, mas a camada {pivo_table} não pôde ser carregada no QGIS.")
        return

    project.addMapLayer(pivo_layer)

    # Criação das Relações 1:N no Projeto
    rel1 = QgsRelation()
    rel1.setId(f"rel_{table1.lower()}_{pivo_table}")
    rel1.setName(f"{table1.capitalize()} -> {pivo_table}")
    rel1.setReferencedLayer(layer1.id())
    rel1.setReferencingLayer(pivo_layer.id())
    rel1.addFieldPair(col_fk1, pk1)

    rel2 = QgsRelation()
    rel2.setId(f"rel_{table2.lower()}_{pivo_table}")
    rel2.setName(f"{table2.capitalize()} -> {pivo_table}")
    rel2.setReferencedLayer(layer2.id())
    rel2.setReferencingLayer(pivo_layer.id())
    rel2.addFieldPair(col_fk2, pk2)

    rel_mgr = project.relationManager()
    if rel1.isValid(): rel_mgr.addRelation(rel1)
    if rel2.isValid(): rel_mgr.addRelation(rel2)

    # Configuração de Expressões de Exibição
    definir_expressao_exibicao_padrao(layer1)
    definir_expressao_exibicao_padrao(layer2)
    pivo_layer.setDisplayExpression(f'represent_value("{col_fk2}")')

    # Configuração dos Widgets de Formulário com 'Relation Reference'
    pivo_layer.setEditorWidgetSetup(
        pivo_layer.fields().indexOf(col_fk1),
        QgsEditorWidgetSetup('RelationReference', {'Relation': rel1.id(), 'ShowForm': False, 'ReadOnly': False})
    )
    pivo_layer.setEditorWidgetSetup(
        pivo_layer.fields().indexOf(col_fk2),
        QgsEditorWidgetSetup('RelationReference', {'Relation': rel2.id(), 'ShowForm': False, 'ReadOnly': False})
    )

    QMessageBox.information(
        None, "Sucesso", 
        f"Vínculo criado e registrado com sucesso!\n\n"
        f"• Banco: {db_selected}\n"
        f"• Tabela Pivô: \"{pivo_schema}\".\"{pivo_table}\"\n"
        f"• Relações configuradas no QGIS com menus suspensos de referência."
    )

# Executa o script
executar_migracao_nm()