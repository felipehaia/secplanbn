from qgis.core import QgsProject, QgsGeometry

# 1. Definição dos nomes das camadas
nome_camada_lotes = 'LOTES-BASE-PLANEJAMENTO'
nome_camada_nucleos = 'IDENTIFICAÇÃO-PARCELAMENTOS'

# 2. Resgatar as camadas do projeto atual
camada_lotes = QgsProject.instance().mapLayersByName(nome_camada_lotes)
camada_nucleos = QgsProject.instance().mapLayersByName(nome_camada_nucleos)

if not camada_lotes or not camada_nucleos:
    print(f"Erro: Verifique se as camadas '{nome_camada_lotes}' e '{nome_camada_nucleos}' estão abertas no QGIS.")
else:
    layer_lotes = camada_lotes[0]
    layer_nucleos = camada_nucleos[0]

    print("Unificando a geometria dos núcleos urbanos...")
    # Une todos os polígonos de núcleos em uma única geometria base
    # Isso garante precisão caso um lote esteja na divisa de dois núcleos
    geometrias_nucleos = [f.geometry() for f in layer_nucleos.getFeatures() if f.geometry()]
    uniao_nucleos = QgsGeometry.unaryUnion(geometrias_nucleos)

    ids_para_selecionar = []
    
    print("Analisando a sobreposição dos lotes (limiar de 90%)...")
    # Loop para checar cada lote
    for lote in layer_lotes.getFeatures():
        geom_lote = lote.geometry()
        
        if geom_lote and not geom_lote.isEmpty():
            area_total = geom_lote.area()
            
            # Atalho de desempenho: só calcula interseção se houver algum contato
            if geom_lote.intersects(uniao_nucleos):
                intersecao = geom_lote.intersection(uniao_nucleos)
                area_intersecao = intersecao.area()
                
                # Calcula a proporção de área interna
                proporcao = area_intersecao / area_total
                
                if proporcao >= 0.90:
                    ids_para_selecionar.append(lote.id())

    # Aplica a seleção de ID's na camada de lotes
    layer_lotes.selectByIds(ids_para_selecionar)
    print(f"Sucesso! {len(ids_para_selecionar)} lotes foram selecionados.")