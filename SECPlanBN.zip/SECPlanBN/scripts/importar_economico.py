import csv
import json
import re
import unicodedata
from difflib import SequenceMatcher
from qgis.core import (
    QgsProject,
    QgsFeature,
    QgsGeometry
)

# ==========================================
# CONFIGURAÇÕES E PARÂMETROS
# ==========================================
NOME_CAMADA_LOTES = "LOTES-BASE-PLANEJAMENTO"
NOME_CAMADA_PONTOS = "economia"
CAMPO_RUA_LOTE = "imoveis_Rua"
CAMPO_NUM_LOTE = "imoveis_Numero"

# Campos que serão convertidos de 'Item 1 | Item 2' para JSON Array '["Item 1", "Item 2"]'
CAMPOS_PARA_JSON = ["cnaes_secundarios", "cnaes_secundar", "lista_servicos", "lista_de_servicos"]

# Limiar de similaridade para o nome da rua (0.0 a 1.0)
LIMIAR_SIMILARIDADE_RUA = 0.72


def remover_acentos(texto):
    """
    Remove acentos e caracteres diacríticos de uma string.
    Exemplo: 'código' -> 'codigo' | 'Endereço' -> 'endereco'
    """
    if not texto:
        return ""
    str_normalizada = unicodedata.normalize('NFD', str(texto))
    return ''.join(c for c in str_normalizada if unicodedata.category(c) != 'Mn')


def texto_para_snake_case(texto):
    """
    Converte nomes de colunas do CSV para o padrão snake_case do PostgreSQL.
    Exemplo: 'CNAE principal' -> 'cnae_principal'
             'Data de inicio da atividade' -> 'data_de_inicio_da_atividade'
             'Código' / 'Codigo' -> 'codigo'
    """
    if not texto:
        return ""
    txt = remover_acentos(texto).strip().lower()
    txt = re.sub(r'[^a-z0-9_]+', '_', txt)
    txt = re.sub(r'_+', '_', txt).strip('_')
    return txt


def texto_para_json_lista(texto):
    """
    Converte uma string contendo valores separados por '|' em um Array JSON.
    Exemplo:
      '4530705 - Pneumáticos | 4751201 - Informática'
      -> '["4530705 - Pneumáticos", "4751201 - Informática"]'
    """
    if not texto:
        return json.dumps([])
    
    itens = [item.strip() for item in str(texto).split('|') if item.strip()]
    return json.dumps(itens, ensure_ascii=False)


def normalizar_nome_rua(texto):
    """
    Padroniza o nome da rua para comparação fuzzy.
    Remove prefixos (R., Rua, Av., Avenida, etc.) e caracteres especiais.
    """
    if not texto:
        return ""
    txt = remover_acentos(texto).upper().strip()
    txt = re.sub(r'^(RUA|R\.|AVENIDA|AV\.|RODOVIA|ROD\.|TRAVESSA|TRV\.|ALAMEDA|AL\.|SERVIDAO|SERV\.|PRACA|PRC\.)\s+', '', txt)
    txt = re.sub(r'^(RUA|R\.)\s+', '', txt)
    txt = re.sub(r'[^\w\s]', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return txt.lower()


def extrair_numero_limpo(texto_bruto):
    """
    Captura e limpa a primeira sequência numérica (remove zeros à esquerda).
    Exemplo: '02797' -> '2797' | 'S/N' -> 'SN'
    """
    if not texto_bruto:
        return ""
    
    txt = str(texto_bruto).strip().upper()
    if re.search(r'\b(S/N|SN|SEM N[ÚU]MERO)\b', txt):
        return "SN"
    
    match = re.search(r'\b\d+\b', txt)
    if match:
        num_str = match.group(0)
        return str(int(num_str)) if num_str.isdigit() else num_str
    return ""


def extrair_rua_e_numero_endereco(endereco_completo, imovel_val=""):
    """
    Trata endereços formatados com '-' ou ',', incluindo suporte a rodovias (ex: SC 108, BR 101).
    """
    if not endereco_completo:
        return "", ""

    # Remove o CEP para não poluir
    end_limpo = re.sub(r'CEP:?\s*\d{5}-?\d{3}', '', str(endereco_completo), flags=re.IGNORECASE).strip()
    end_limpo = re.sub(r'\b\d{5}-\d{3}\b', '', end_limpo).strip()

    primeiro_bloco = re.split(r'[-,]', end_limpo)[0].strip()

    # Verifica se começa por sigla de Rodovia + número (Ex: SC 108, BR-101, SC108)
    match_rodovia = re.match(r'^(SC|BR|PR|RS|SP|MG|RJ|GO|MS|MT|PE|BA|CE|PA|AM|BRN)\s*[-_]?\s*\d+', primeiro_bloco, re.IGNORECASE)

    if match_rodovia:
        fim_rodovia = match_rodovia.end()
        # Procura o número do imóvel SOMENTE APÓS o nome da rodovia
        resto_bloco = primeiro_bloco[fim_rodovia:]
        match_num = re.search(r'\b\d+\b', resto_bloco)
        
        if match_num:
            numero = str(int(match_num.group(0)))
            rua = primeiro_bloco[:fim_rodovia + match_num.start()].strip()
        else:
            rua = primeiro_bloco[:fim_rodovia].strip()
            numero = extrair_numero_limpo(imovel_val) or extrair_numero_limpo(end_limpo[fim_rodovia:])
    else:
        match_num = re.search(r'\b\d+\b', primeiro_bloco)
        if match_num:
            numero = str(int(match_num.group(0)))
            rua = primeiro_bloco[:match_num.start()].strip()
        else:
            rua = primeiro_bloco
            numero = extrair_numero_limpo(imovel_val) or extrair_numero_limpo(end_limpo)

    return rua, numero

def similaridade_texto(a, b):
    """Calcula a taxa de similaridade entre os nomes das ruas."""
    str1 = normalizar_nome_rua(a)
    str2 = normalizar_nome_rua(b)
    if not str1 or not str2:
        return 0.0
    return SequenceMatcher(None, str1, str2).ratio()


def executar_processamento():
    # 1. Selecionar o arquivo CSV
    from qgis.PyQt.QtWidgets import QFileDialog
    caminho_csv, _ = QFileDialog.getOpenFileName(
        None, "Selecione o arquivo CSV", "", "Arquivos CSV (*.csv);;Todos os arquivos (*)"
    )
    if not caminho_csv:
        print("[AVISO] Seleção de arquivo cancelada.")
        return

    # 2. Obter camada de lotes
    camada_lotes_list = QgsProject.instance().mapLayersByName(NOME_CAMADA_LOTES)
    if not camada_lotes_list:
        print(f"[ERRO] A camada '{NOME_CAMADA_LOTES}' não foi encontrada no projeto atual.")
        return
    camada_lotes = camada_lotes_list[0]

    # 3. Obter camada de pontos 'economia' (PostgreSQL)
    camada_pontos_list = QgsProject.instance().mapLayersByName(NOME_CAMADA_PONTOS)
    if not camada_pontos_list:
        print(f"[ERRO] A camada PostgreSQL '{NOME_CAMADA_PONTOS}' precisa estar aberta no painel do QGIS.")
        return
    camada_pontos = camada_pontos_list[0]

    camada_pontos.startEditing()

    # Mapeamento rigoroso dos campos REAIS da tabela no PostgreSQL
    fields_pg = camada_pontos.fields()
    mapa_indices_pg = {}
    for idx_field, f in enumerate(fields_pg):
        nome_real = f.name()
        nome_snake = texto_para_snake_case(nome_real)
        mapa_indices_pg[nome_snake] = idx_field

    print(f"[INFO] Camada PostgreSQL '{NOME_CAMADA_PONTOS}' identificada com {len(fields_pg)} campos.")

    # Prepara o cache dos lotes
    lotes_cache = []
    for feat in camada_lotes.getFeatures():
        rua_lote = str(feat[CAMPO_RUA_LOTE] or '').strip()
        num_lote_raw = str(feat[CAMPO_NUM_LOTE] or '').strip()
        num_lote_clean = extrair_numero_limpo(num_lote_raw)
        
        lotes_cache.append({
            'feature': feat,
            'rua_original': rua_lote,
            'numero': num_lote_clean,
            'geometry': feat.geometry()
        })

    print(f"[INFO] {len(lotes_cache)} lotes carregados da camada gráfica.")

    # 4. Leitura do CSV
    sucessos = 0
    falhas = 0

    with open(caminho_csv, mode='r', encoding='utf-8-sig') as f:
        primeira_linha = f.readline()
        delimitador = ';' if ';' in primeira_linha else ','
        f.seek(0)

        leitor = csv.reader(f, delimiter=delimitador)

        try:
            cabecalho_bruto = next(leitor)
            cabecalho_snake = [texto_para_snake_case(c) for c in cabecalho_bruto]
        except StopIteration:
            print("[ERRO] Arquivo CSV vazio.")
            return

        for idx, linha in enumerate(leitor, start=2):
            if not linha or len(linha) < 5:
                continue

            codigo_csv = linha[0].strip()                       # 1ª Coluna (Código)
            endereco_csv = linha[4].strip()                     # 5ª Coluna (Endereço)
            imovel_csv = linha[5].strip() if len(linha) > 5 else "" # 6ª Coluna (Imóvel)

            rua_csv, num_csv = extrair_rua_e_numero_endereco(endereco_csv, imovel_csv)

            if not rua_csv or not num_csv:
                print(f"[ALERT] Linha {idx}: Dados insuficientes no endereço: '{endereco_csv}'")
                falhas += 1
                continue

            melhor_lote = None
            maior_similaridade = 0.0

            # Procura por lote com o número idêntico e maior similaridade de rua
            for item in lotes_cache:
                if item['numero'] == num_csv:
                    sim = similaridade_texto(rua_csv, item['rua_original'])
                    if sim >= LIMIAR_SIMILARIDADE_RUA and sim > maior_similaridade:
                        maior_similaridade = sim
                        melhor_lote = item

            # Se encontrou o lote correspondente
            if melhor_lote:
                geom_lote = melhor_lote['geometry']
                if geom_lote and not geom_lote.isEmpty():
                    centroide = geom_lote.centroid()

                    nova_feature = QgsFeature(fields_pg)
                    nova_feature.setGeometry(centroide)
                    
                    # Preenche os atributos combinando com o mapeamento
                    for col_idx, valor in enumerate(linha):
                        if col_idx < len(cabecalho_snake):
                            col_nome_snake = cabecalho_snake[col_idx]
                            
                            if col_nome_snake in mapa_indices_pg:
                                idx_pg = mapa_indices_pg[col_nome_snake]
                                valor_str = valor.strip()
                                
                                # Converte para JSON Array caso seja um dos campos de lista
                                if col_nome_snake in CAMPOS_PARA_JSON:
                                    valor_str = texto_para_json_lista(valor_str)
                                
                                nova_feature.setAttribute(idx_pg, valor_str)

                    camada_pontos.addFeature(nova_feature)
                    sucessos += 1
                    print(f"[OK] Linha {idx}: Código {codigo_csv} -> Lote (Rua Lote: '{melhor_lote['rua_original']}', Nº: '{num_csv}', Sim: {maior_similaridade:.2f})")
            else:
                print(f"[FALHA] Linha {idx}: Lote não localizado para Código {codigo_csv} (Rua CSV: '{rua_csv}', Nº: '{num_csv}')")
                falhas += 1

    # Grava as inserções diretamente no PostgreSQL
    camada_pontos.commitChanges()
    camada_pontos.triggerRepaint()

    print("\n==========================================")
    print("RESUMO DO PROCESSAMENTO (POSTGRESQL)")
    print("==========================================")
    print(f"Pontos criados com sucesso no banco: {sucessos}")
    print(f"Registros não vinculados: {falhas}")
    print("==========================================")


# Executar
executar_processamento()