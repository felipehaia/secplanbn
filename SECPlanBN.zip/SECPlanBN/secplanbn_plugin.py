import os
import subprocess
import sys
from qgis.core import Qgis
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu, QMessageBox, QToolButton

# Importação dos scripts
from .scripts import (
    buscas,
    cadastro_num,
    consulta_previa,
    exportar_pdf,
    fotos_vistoria,
    gerar_parecer,
    puxar_id_betha,
    relatorio_infraestrutura,
    reurb_crf,
)


class SecPlanBNPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.toolbar = None
        self.actions = []
        self.widgets = []

    def verificar_heif_disponivel(self):
        """Verifica se a biblioteca pillow-heif está pronta para uso."""
        try:
            from PIL import Image
            import pillow_heif
            pillow_heif.register_heif_opener()
            return True
        except ImportError:
            return False

    def verificar_e_executar_fotos(self):
        """Valida a presença da biblioteca pillow-heif antes de executar o script de fotos."""
        if not self.verificar_heif_disponivel():
            resposta = QMessageBox.question(
                self.iface.mainWindow(),
                "Dependência Necessária",
                "A biblioteca 'pillow-heif' é necessária para ler metadados de fotos HEIC.\n\n"
                "Deseja tentar instalá-la agora no Python do QGIS?",
                QMessageBox.Yes | QMessageBox.No,
            )

            if resposta == QMessageBox.Yes:
                sucesso = self.instalar_dependencia()
                if sucesso:
                    self.iface.messageBar().pushMessage(
                        "Sucesso",
                        "Biblioteca instalada! Executando a ferramenta...",
                        level=Qgis.Success,
                        duration=4,
                    )
                    fotos_vistoria.run()
                else:
                    self.iface.messageBar().pushMessage(
                        "Erro",
                        "Falha na instalação. Tente executar o QGIS como Administrador.",
                        level=Qgis.Critical,
                        duration=6,
                    )
        else:
            fotos_vistoria.run()

    def instalar_dependencia(self):
        """Tenta instalar pillow-heif e pillow via pip silenciosamente."""
        try:
            creationflags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            
            subprocess.check_call(
                [
                    sys.executable,
                    "-m",
                    "pip",
                    "install",
                    "--no-warn-script-location",
                    "pillow",
                    "pillow-heif",
                ],
                creationflags=creationflags
            )
            
            import pillow_heif
            pillow_heif.register_heif_opener()
            return True
        except Exception as e:
            print(f"Erro ao instalar dependência via pip: {e}")
            return False

    def initGui(self):
        self.toolbar = self.iface.addToolBar("SECPlanBN")

        # ============================================================
        # 1. BOTÃO "BUSCAR" (ÍCONE: lupa.svg)
        # ============================================================
        btn_buscar = QToolButton()
        btn_buscar.setText("Buscar")

        caminho_icone_busca = os.path.join(
            os.path.dirname(__file__), "icons", "lupa.svg"
        )
        if os.path.exists(caminho_icone_busca):
            btn_buscar.setIcon(QIcon(caminho_icone_busca))

        btn_buscar.setToolTip("Ferramentas de Busca")
        btn_buscar.setPopupMode(QToolButton.InstantPopup)

        menu_buscar = QMenu(btn_buscar)

        action_buscar_rua = QAction("Rua", self.iface.mainWindow())
        action_buscar_rua.triggered.connect(buscas.buscar_rua)
        menu_buscar.addAction(action_buscar_rua)

        action_buscar_lote = QAction("Lote", self.iface.mainWindow())
        action_buscar_lote.triggered.connect(buscas.buscar_lote)
        menu_buscar.addAction(action_buscar_lote)

        btn_buscar.setMenu(menu_buscar)

        action_btn_buscar = self.toolbar.addWidget(btn_buscar)
        self.widgets.append(action_btn_buscar)
        self.actions.extend([action_buscar_rua, action_buscar_lote])

        # ============================================================
        # 2. BOTÃO "GERAR DOCUMENTO" (ÍCONE: parecer.svg)
        # ============================================================
        btn_documento = QToolButton()
        btn_documento.setText("Gerar Documento")

        caminho_icone_doc = os.path.join(
            os.path.dirname(__file__), "icons", "parecer.svg"
        )
        if os.path.exists(caminho_icone_doc):
            btn_documento.setIcon(QIcon(caminho_icone_doc))
            
        btn_documento.setToolTip("Gerar Documentos REURB")
        btn_documento.setPopupMode(QToolButton.InstantPopup)

        menu_documentos = QMenu(btn_documento)

        action_parecer = QAction(
            "Gerar Parecer Loteamento", self.iface.mainWindow()
        )
        action_parecer.triggered.connect(gerar_parecer.run)
        menu_documentos.addAction(action_parecer)

        action_crf = QAction("Gerar CRF", self.iface.mainWindow())
        action_crf.triggered.connect(reurb_crf.run)
        menu_documentos.addAction(action_crf)

        action_infra = QAction(
            "Gerar Relatório de Infraestrutura", self.iface.mainWindow()
        )
        action_infra.triggered.connect(relatorio_infraestrutura.run)
        menu_documentos.addAction(action_infra)

        btn_documento.setMenu(menu_documentos)

        action_btn_doc = self.toolbar.addWidget(btn_documento)
        self.widgets.append(action_btn_doc)
        self.actions.extend([action_parecer, action_crf, action_infra])

        # ============================================================
        # 3. DEMAIS BOTÕES DA TOOLBAR (MAPEIADOS PARA OS SVG)
        # ============================================================
        outros_botoes = [
            (
                "Importar Fotos HEIC",
                "foto.svg",
                self.verificar_e_executar_fotos,
            ),
            (
                "Exportar Selecionados em PDF",
                "exportar.svg",
                exportar_pdf.run,
            ),
            ("Puxar ID Betha", "id.svg", puxar_id_betha.run),
            (
                "Consulta Prévia Construção",
                "viabilidade.svg",
                consulta_previa.run,
            ),
            ("Cadastro Número Endereço", "cadastro_numero.svg", cadastro_num.run),
        ]

        for texto, icone, funcao in outros_botoes:
            caminho_icone = os.path.join(
                os.path.dirname(__file__), "icons", icone
            )
            action = QAction(
                QIcon(caminho_icone), texto, self.iface.mainWindow()
            )
            action.triggered.connect(funcao)
            self.toolbar.addAction(action)
            self.actions.append(action)

    def unload(self):
        for widget_action in self.widgets:
            self.toolbar.removeAction(widget_action)

        for action in self.actions:
            self.iface.removeToolBarIcon(action)

        if self.toolbar:
            del self.toolbar