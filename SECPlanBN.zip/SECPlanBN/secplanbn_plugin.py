import os
from qgis.PyQt.QtWidgets import QAction, QMenu, QToolButton, QMessageBox
from qgis.PyQt.QtGui import QIcon

# Importação dos scripts, incluindo o novo reurb_crf
from .scripts import (
    gerar_parecer, 
    reurb_crf, 
    exportar_pdf, 
    puxar_id_betha, 
    consulta_previa, 
    cadastro_num, 
    relatorio_infraestrutura
)

class SecPlanBNPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.toolbar = None
        self.actions = []
        self.widgets = []  # Guarda referência dos widgets inseridos na toolbar (ex: QToolButton)

    def initGui(self):
        self.toolbar = self.iface.addToolBar("SECPlanBN")

        # ============================================================
        # 1. BOTÃO "GERAR DOCUMENTO" COM MENU DE SUBOPÇÕES
        # ============================================================
        btn_documento = QToolButton()
        btn_documento.setText("Gerar Documento")
        
        caminho_icone_doc = os.path.join(os.path.dirname(__file__), "icons", "parecer.png")
        btn_documento.setIcon(QIcon(caminho_icone_doc))
        btn_documento.setToolTip("Gerar Documentos REURB")
        
        # Define o estilo do botão com a setinha para abrir o menu
        btn_documento.setPopupMode(QToolButton.InstantPopup)

        # Criando o Menu Suspenso
        menu_documentos = QMenu(btn_documento)

        # Ação 1: Gerar Parecer
        action_parecer = QAction("Gerar Parecer Loteamento", self.iface.mainWindow())
        action_parecer.triggered.connect(gerar_parecer.run)
        menu_documentos.addAction(action_parecer)

        # Ação 2: Gerar CRF
        action_crf = QAction("Gerar CRF", self.iface.mainWindow())
        action_crf.triggered.connect(reurb_crf.run)
        menu_documentos.addAction(action_crf)

        # Ação 3: Gerar Parecer Infraestrutura
        action_infra = QAction("Gerar Relatório de Infraestrutura", self.iface.mainWindow())
        action_infra.triggered.connect(relatorio_infraestrutura.run)
        menu_documentos.addAction(action_infra)

        btn_documento.setMenu(menu_documentos)

        # Adiciona o botão com subopções na toolbar
        action_btn_doc = self.toolbar.addWidget(btn_documento)
        self.widgets.append(action_btn_doc)
        self.actions.extend([action_parecer, action_crf, action_infra])

        # ============================================================
        # 2. DEMAIS BOTÕES PADRÃO DA TOOLBAR
        # ============================================================
        outros_botoes = [
            ("Exportar Selecionados em PDF", "exportar_pdf.png", exportar_pdf.run),
            ("Puxar ID Betha", "puxar_id.png", puxar_id_betha.run),
            ("Consulta Prévia Construção", "consulta_previa.png", consulta_previa.run),
            ("Cadastro Número Endereço", "cadastro_num.png", cadastro_num.run),
        ]

        for texto, icone, funcao in outros_botoes:
            caminho_icone = os.path.join(os.path.dirname(__file__), "icons", icone)
            action = QAction(QIcon(caminho_icone), texto, self.iface.mainWindow())
            action.triggered.connect(funcao)
            self.toolbar.addAction(action)
            self.actions.append(action)

    def unload(self):
        # Remove ações e widgets customizados da toolbar
        for widget_action in self.widgets:
            self.toolbar.removeAction(widget_action)

        for action in self.actions:
            self.iface.removeToolBarIcon(action)

        if self.toolbar:
            del self.toolbar