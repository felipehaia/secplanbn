def classFactory(iface):
    from .main import SecPlanBNPlugin
    return SecPlanBNPlugin(iface)
