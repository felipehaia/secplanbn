import os
import sys

plugin_path = os.path.dirname(__file__)
libs_path = os.path.join(plugin_path, "libs")

if libs_path not in sys.path:
    sys.path.insert(0, libs_path)

def classFactory(iface):
    from .secplanbn_plugin import SecPlanBNPlugin
    return SecPlanBNPlugin(iface)
