# Relações entre camadas REURB no QGIS

Este documento descreve como interpretar e manter as relações muitos-para-muitos (N:M) entre as camadas REURB deste projeto. O modelo abaixo foi inferido do gestor de vínculos do plugin e dos nomes/campos visíveis nas capturas do QGIS; confirme sempre o esquema real no PostgreSQL e no projeto QGIS antes de alterar dados.

## Modelo conceitual

Uma tabela pivô representa cada associação entre duas entidades. No PostgreSQL, as duas chaves estrangeiras são também a chave primária composta:

```text
Camada A (1) ───< tabela pivô >─── (1) Camada B
                       │
                       ├── fk_<tabela_a> → PK da Camada A
                       └── fk_<tabela_b> → PK da Camada B
```

Uma feição da Camada A pode ter várias linhas na pivô e uma feição da Camada B também. Assim, a relação conceitual entre A e B é N:M, embora o QGIS represente o caminho como duas relações 1:N: A→pivô e B→pivô. A pivô não substitui nem duplica as entidades originais; ela armazena os pares associados e os atributos próprios do vínculo.

## Vínculos REURB identificados

As capturas do painel de camadas mostram duas tabelas associativas:

| Tabela pivô | Camadas relacionadas | Campos vistos / esperados |
|---|---|---|
| `lotes_reurb_legitimados_reurb` | `lotes_reurb` ↔ `legitimados_reurb` | Confirmados na captura: `fk_lotes_reurb`, `fk_legitimados_reurb`, `criado_em`, `observacao`. |
| `processos_reurb_nucleos_urbanos_informais` | `PROCESSOS_REURB` ↔ camada do núcleo urbano informal (aparece como `Núcleo Urbano Informal Consolidado`) | Pelo padrão do gestor, espera-se uma FK para cada tabela-pai, além de `criado_em` e `observacao`. Os nomes exatos das FKs e as PKs referenciadas precisam ser conferidos no banco. |

O nome exibido no painel do QGIS pode ser um alias, não o nome da tabela PostgreSQL. Em particular, confirme se a camada exibida como `Núcleo Urbano Informal Consolidado` realmente vem da tabela `nucleos_urbanos_informais`; o nome da pivô sugere isso, mas não prova.

As capturas não mostram schema, constraints, tipos, PKs das camadas-pai nem conteúdo das tabelas. Não conclua, só pelo nome, que a PK de uma camada é `id`, `id_0` ou `id_<tabela>`.

## Convenções criadas pelo gestor do plugin

O código em `scripts/gestor_vinculos/vinculador.py` cria o vínculo a partir de duas camadas PostGIS carregadas no projeto:

- Nome da tabela pivô: `<tabela_1_em_minúsculas>_<tabela_2_em_minúsculas>`.
- Colunas FK: `fk_<tabela_1_em_minúsculas>` e `fk_<tabela_2_em_minúsculas>`.
- Cada FK referencia a coluna chave da camada, obtida do URI da fonte QGIS; se não houver uma chave informada, o código presume `id_<nome_da_tabela>`.
- As FKs são `INT NOT NULL`, com `ON DELETE CASCADE` e `ON UPDATE CASCADE`.
- A PK da pivô é composta pelas duas FKs. Portanto, o mesmo par não pode ser inserido duas vezes, mas cada FK pode aparecer em vários pares.
- A tabela também tem `criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP` e `observacao TEXT`.
- São criados índices individuais para as duas FKs.
- A tabela pivô fica no schema da primeira camada selecionada. A ordem das camadas escolhidas pode afetar esse schema e a ordem do nome da tabela/colunas.
- O gestor registra o DDL e os nomes das tabelas em `public.qgis_migrations`.

No projeto QGIS, o gestor carrega a tabela pivô como camada e cria duas `QgsRelation`: a camada-pai é `referencedLayer`, e a pivô é `referencingLayer`. Também configura widgets `RelationReference` para as duas FKs. Para usar relações criadas pelo gestor, confirme que as camadas e relações continuam carregadas e válidas; salvar a conexão/banco não substitui salvar o projeto QGIS.

## Como percorrer os dados

### PostgreSQL

Para inspecionar sem alterar dados, consulte as FKs e constraints no catálogo do banco (ajuste schema/tabela conforme a fonte QGIS):

```sql
SELECT
    tc.constraint_name,
    tc.constraint_type,
    kcu.column_name,
    ccu.table_schema AS tabela_referenciada_schema,
    ccu.table_name AS tabela_referenciada,
    ccu.column_name AS coluna_referenciada
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_schema = kcu.constraint_schema
 AND tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
  ON tc.constraint_schema = ccu.constraint_schema
 AND tc.constraint_name = ccu.constraint_name
WHERE tc.table_schema = 'public'
  AND tc.table_name = 'lotes_reurb_legitimados_reurb'
ORDER BY tc.constraint_type, kcu.ordinal_position;
```

Para obter os pares associados, faça `JOIN` da pivô com cada tabela-pai usando a FK correspondente. Não associe registros por nome ou geometria quando já existir uma FK válida. Para manter ou auditar associações, preserve o par de FKs como unidade lógica.

### QGIS/PyQGIS

- `QgsProject.instance().relationManager().relations()` contém as relações configuradas no projeto atual; a tabela do banco, sozinha, não garante que as relações estejam declaradas no projeto.
- Em cada relação, `referencedLayer()` é a camada-pai e `referencingLayer()` é a camada-filha (a pivô).
- `rel.getRelatedFeatures(feicao_pai)` retorna as linhas da pivô ligadas à feição-pai.
- Para chegar à outra entidade, localize a segunda relação cujo `referencingLayer` é a mesma pivô e use `getReferencedFeature()` em cada linha da pivô.

As rotinas de análises em `scripts/analises.py` e de documentos em `scripts/documentos.py` já percorrem esse padrão de duas relações para tratar uma pivô como vínculo N:M. O código procura a outra relação da pivô; evite configurar relações extras apontando para a mesma pivô sem revisar essa lógica, pois alguns percursos usam a primeira relação encontrada.

## Ações de vínculos na Gestão REURB

O botão **Vínculos REURB** na gestão exige um único processo selecionado na tabela:

- **Núcleos:** lista os núcleos associados, permite vincular núcleos existentes ou iniciar a criação de um novo núcleo pela ferramenta nativa do QGIS. O novo núcleo é associado ao processo pela tabela pivô.
- **Lotes:** ao cadastrar ou associar um lote, solicita primeiro um núcleo já vinculado ao processo, exceto quando há apenas um — nesse caso, usa-o diretamente. A opção de listar mostra todos os lotes dos núcleos vinculados ao processo, com o núcleo indicado em cada rótulo; lotes existentes sem núcleo podem ser associados, e lotes novos são criados pela ferramenta nativa com `nucleo_urbano` pré-preenchido e bloqueado durante a digitalização.
- **Legitimados:** solicita um lote entre todos os lotes dos núcleos do processo (sem pedir o núcleo novamente). Permite listar os legitimados do lote, vincular legitimados existentes ou criar um novo pelo formulário padrão de atributos do QGIS. O cadastro omite a PK, os campos de vínculo e os editores de relações N:M; a associação lote–legitimado é gravada exclusivamente na tabela pivô após a inclusão da feição. A coluna antiga `id_lote_reurb` não é preenchida nem usada pela gestão.
- As listas de seleção incluem busca sem distinção entre maiúsculas/minúsculas ou acentos, pesquisando no rótulo, no identificador e nos atributos da feição.
- Todas as listas de feições têm o botão **Aproximar feição**, que seleciona o registro e ajusta a extensão do mapa à geometria. Registros sem geometria exibem um aviso.
- As janelas de listagem de registros também têm **Abrir formulário de edição**, que abre o formulário nativo do QGIS para a feição selecionada e pergunta se as alterações devem ser salvas ou descartadas.

Ao concluir uma ação de vínculo ou sair da ferramenta nativa de digitalização, a gestão pergunta se deve salvar ou descartar. A decisão se aplica ao buffer inteiro das camadas envolvidas, inclusive edições anteriores ainda não salvas nessas camadas. Se o salvamento falhar, a camada com erro pode continuar em edição; confira a mensagem do QGIS. Ao sair da digitalização, o padrão temporário e o bloqueio do campo `nucleo_urbano` são restaurados. Se o provedor ainda não disponibilizar a chave primária de um núcleo/legitimado novo, a associação pela pivô é recusada com aviso; salve essa feição primeiro e use a opção de vincular registro existente.

No cadastro de legitimado, o formulário temporário também é restaurado ao terminar ou cancelar. Ao aceitar, a confirmação para salvar/descartar inclui a camada de legitimados e a tabela pivô.

## Migração única dos legitimados antigos

O script `scripts/adequacoes/migrar_legitimados_duplicados.py` consolida os cadastros antigos e preenche a relação N:M com base no campo legado `legitimados_reurb.id_lote_reurb` e nos vínculos já existentes na tabela pivô. Execute-o uma vez pela janela Python do QGIS, com as camadas PostgreSQL `lotes_reurb`, `legitimados_reurb` e `lotes_reurb_legitimados_reurb` carregadas e as duas relações da pivô válidas no projeto. Finalize a edição dessas camadas antes da execução; o script solicita a senha do banco e mostra um resumo para confirmação.

Dois registros são considerados duplicados somente quando `nome` e `dados_proprietario` coincidem após normalizar caixa, acentos, espaços e pontuação. O menor ID é mantido. Antes de excluir qualquer registro, o script valida que as referências legadas resolvem para a chave primária de um lote; em caso de inconsistência, cancela sem gravar. As inserções de vínculos e exclusões ocorrem numa única transação PostgreSQL, com cópias dos registros removidos e de seus vínculos antigos em tabelas de backup. Se `id_lote_reurb` estiver `NOT NULL`, o script também o torna opcional, sem apagar a coluna nem seus valores existentes. A coluna antiga deixa de ser usada na gestão e na geração da CRF; a CRF consulta a tabela pivô.

## Relações que não são a tabela pivô

`scripts/associar_lote_reurb_ao_nucleo.py` usa outro modelo: grava o identificador do núcleo diretamente no campo `nucleo_urbano` de `lotes_reurb`, selecionando o núcleo por sobreposição geométrica mínima de 90%. Esse é um vínculo direto lote→núcleo, e não a relação N:M com uma tabela pivô. Não misture os dois mecanismos nem presuma que atualizar um atualiza o outro.

## Verificações antes de modificar ou escrever código

1. Confirme a fonte de dados de cada camada no QGIS: provider, banco, schema, tabela e coluna chave (`QgsDataSourceUri`).
2. Confira no PostgreSQL as colunas, tipos, PK composta e FKs reais da pivô; compare com os nomes acima.
3. No gerenciador de relações do projeto, verifique se existem exatamente as duas relações esperadas para a pivô, com pai e filha configurados na direção correta.
4. Teste o percurso em ambos os sentidos: uma feição-pai deve retornar suas linhas da pivô; cada linha deve resolver a feição do outro pai.
5. Ao apagar um vínculo, apague apenas a linha da pivô para desfazer uma associação. Não remova uma camada-pai para esse fim: as FKs usam `ON DELETE CASCADE`, então apagar uma feição-pai pode apagar suas associações.
6. O comando de remoção do gestor apaga a tabela pivô no banco. É uma operação destrutiva para todas as associações daquela relação; não a use para remover apenas um par.
7. Após criar ou remover relações/tabelas, valide a camada no QGIS e salve o projeto quando necessário.

## Referências no código

- `scripts/gestor_vinculos/vinculador.py`: criação da tabela pivô, constraints e relações 1:N no QGIS.
- `scripts/analises.py`: leitura de feições por uma relação direta ou por uma pivô N:M.
- `scripts/documentos.py`: geração de documentos com atributos de pais, filhos e relações N:M.
- `scripts/associar_lote_reurb_ao_nucleo.py`: associação alternativa por campo direto e sobreposição geométrica.
