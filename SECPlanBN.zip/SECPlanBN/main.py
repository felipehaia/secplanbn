import os
import subprocess
import sys
import importlib
import sip
from qgis.core import Qgis
from qgis.PyQt.QtCore import Qt, QSize
from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtWidgets import (
    QTabWidget, QToolBar, QWidget, QHBoxLayout, QVBoxLayout, QGroupBox,
    QToolButton, QAction, QMenu, QScrollArea, QMessageBox, QFrame,
    QLabel, QGraphicsOpacityEffect
)

class SecPlanBNPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.main_window = iface.mainWindow()
        self.ribbon_toolbar = None

    def initGui(self):
        self.apply_qss_style()
        self.create_ribbon()

    def apply_qss_style(self):
        qss_path = os.path.join(os.path.dirname(__file__), 'style.qss')
        if os.path.exists(qss_path):
            with open(qss_path, 'r', encoding='utf-8') as f:
                self.main_window.setStyleSheet(f.read())

    def get_safe_action(self, attr_name):
        if hasattr(self.iface, attr_name):
            try:
                method = getattr(self.iface, attr_name)
                return method() if callable(method) else method
            except Exception:
                return None
        return None

    def find_action_by_name(self, names):
        if isinstance(names, str):
            names = [names]
        for name in names:
            act = self.get_safe_action(name)
            if act:
                return act
        for act in self.main_window.findChildren(QAction):
            for name in names:
                if act.objectName() == name or act.objectName() == f"m{name}":
                    return act
        return None

    def _safe_set_btn_text(self, btn, custom_text):
        """Atualiza o texto do botão apenas se o objeto C++ ainda for válido na memória."""
        try:
            if btn and not sip.isdeleted(btn):
                btn.setText(custom_text)
        except RuntimeError:
            pass

    def build_btn(self, item, size=20, icon_under_text=True, preserve_icon=False, icon_only=False, custom_text=None):
        if not item:
            return None

        action = None
        menu_to_set = None

        if isinstance(item, QAction):
            action = item
            menu_to_set = action.menu()
        elif isinstance(item, QMenu):
            action = item.menuAction()
            menu_to_set = item
        elif isinstance(item, tuple):
            action, menu_to_set = item

        if not action:
            return None

        btn = QToolButton()
        btn.setDefaultAction(action)

        if custom_text:
            btn.setText(custom_text)
            action.changed.connect(lambda: self._safe_set_btn_text(btn, custom_text))
            btn.setToolTip(action.text().replace('&', ''))

        if icon_only:
            btn.setToolButtonStyle(Qt.ToolButtonIconOnly)
        elif icon_under_text:
            btn.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        else:
            btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            btn.setObjectName("ClipboardSmallBtn")

        btn.setIconSize(QSize(size, size))

        if menu_to_set:
            btn.setMenu(menu_to_set)
            btn.setPopupMode(QToolButton.MenuButtonPopup)

        return btn

    def add_group(self, layout_parent, title, items, preserve_icon=False):
        """Cria os QGroupBox das abas SecPlanBN, Inserir, Mapa, Análise e Compartilhar."""
        group = QGroupBox(title)
        layout_group = QHBoxLayout(group)
        layout_group.setContentsMargins(2, 2, 2, 2)
        layout_group.setSpacing(2)

        has_content = False
        for item in items:
            if item:
                btn = self.build_btn(item, preserve_icon=preserve_icon)
                if btn:
                    layout_group.addWidget(btn)
                    has_content = True

        if has_content:
            layout_parent.addWidget(group)

    def create_quick_access_panel(self):
        """Painel de Acesso Rápido com 3 ícones pequenos na VERTICAL."""
        fixed_widget = QWidget()
        v_layout = QVBoxLayout(fixed_widget)
        v_layout.setContentsMargins(4, 4, 4, 4)
        v_layout.setSpacing(3)
        v_layout.setAlignment(Qt.AlignCenter)

        act_save = self.find_action_by_name(['actionSaveProject', 'SaveProject', 'mActionSaveProject'])
        if act_save:
            btn_save = self.build_btn(act_save, size=16, icon_only=True)
            if btn_save:
                btn_save.setToolTip("Salvar Projeto")
                v_layout.addWidget(btn_save)

        act_select = self.find_action_by_name(['actionSelect', 'actionSelectFeatures', 'SelectFeatures', 'mActionSelect'])
        if act_select:
            btn_sel = self.build_btn(act_select, size=16, icon_only=True)
            if btn_sel:
                btn_sel.setToolTip("Selecionar Feições")
                v_layout.addWidget(btn_sel)

        act_identify = self.find_action_by_name(['actionIdentify', 'Identify', 'mActionIdentify'])
        if act_identify:
            btn_id = self.build_btn(act_identify, size=16, icon_only=True)
            if btn_id:
                btn_id.setToolTip("Identificar Feições")
                v_layout.addWidget(btn_id)

        v_layout.addStretch()

        wrapper = QWidget()
        w_layout = QHBoxLayout(wrapper)
        w_layout.setContentsMargins(0, 0, 0, 0)
        w_layout.setSpacing(0)
        w_layout.addWidget(fixed_widget)

        line = QFrame()
        line.setFrameShape(QFrame.VLine)
        line.setFrameShadow(QFrame.Sunken)
        line.setStyleSheet("QFrame { color: #d0d0d0; margin-left: 2px; margin-right: 2px; }")
        w_layout.addWidget(line)

        return wrapper

    def build_clipboard_group(self, layout_parent):
        """Área de Transferência: Colar Grande + Recortar e Copiar Empilhados."""
        group = QGroupBox("Área de Transferência")
        layout_group = QHBoxLayout(group)
        layout_group.setContentsMargins(2, 2, 2, 2)
        layout_group.setSpacing(2)

        act_paste = self.find_action_by_name(['actionPasteFeatures', 'PasteFeatures'])
        btn_paste = self.build_btn(act_paste, size=22, icon_under_text=True, custom_text="Colar feições")

        act_cut = self.find_action_by_name(['actionCutFeatures', 'CutFeatures'])
        act_copy = self.find_action_by_name(['actionCopyFeatures', 'CopyFeatures'])

        right_layout = QVBoxLayout()
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        if act_cut:
            btn_cut = self.build_btn(act_cut, size=14, icon_under_text=False, custom_text="Recortar")
            if btn_cut: right_layout.addWidget(btn_cut)

        if act_copy:
            btn_copy = self.build_btn(act_copy, size=14, icon_under_text=False, custom_text="Copiar")
            if btn_copy: right_layout.addWidget(btn_copy)

        if btn_paste: layout_group.addWidget(btn_paste)
        if right_layout.count() > 0: layout_group.addLayout(right_layout)

        layout_parent.addWidget(group)

    def build_complete_selection_group(self):
        """Bandeja de seleções com ações nativas."""
        select_action = self.find_action_by_name(['actionSelect', 'actionSelectFeatures', 'SelectFeatures', 'mActionSelect'])
        menu_geom = QMenu("Seleção de Feição", self.main_window)
        for act in [
            select_action,
            self.find_action_by_name('actionSelectPolygon'),
            self.find_action_by_name('actionSelectFreehand'),
            self.find_action_by_name('actionSelectRadius')
        ]:
            if act: menu_geom.addAction(act)
        btn_geom = (select_action, menu_geom) if select_action else None

        select_by_expr = self.find_action_by_name(['actionSelectByExpression', 'SelectByExpression', 'mActionSelectByExpression'])
        act_val = self.find_action_by_name(['actionSelectByForm', 'SelectByForm', 'mActionSelectByForm'])
        act_all = self.find_action_by_name(['actionSelectAll', 'SelectAll', 'mActionSelectAll'])
        act_inv = self.find_action_by_name(['actionInvertSelection', 'InvertSelection', 'mActionInvertSelection'])

        menu_expr = QMenu("Atributos", self.main_window)
        if act_val: menu_expr.addAction(act_val)
        if select_by_expr: menu_expr.addAction(select_by_expr)
        if act_all: menu_expr.addAction(act_all)
        if act_inv: menu_expr.addAction(act_inv)

        btn_expr = (select_by_expr, menu_expr) if select_by_expr else None

        deselect_all = self.find_action_by_name(['actionDeselectAll', 'DeselectAll', 'mActionDeselectAll'])
        menu_deselect = QMenu("Des-selecionar", self.main_window)
        if deselect_all: menu_deselect.addAction(deselect_all)
        if act_inv: menu_deselect.addAction(act_inv)
        btn_deselect = (deselect_all, menu_deselect) if deselect_all else None

        return [btn_geom, btn_expr, btn_deselect]

    def build_node_tool_item(self):
        """Ferramenta Vértice."""
        act_vertex = self.find_action_by_name([
            'actionVertexToolActiveLayer', 'mActionVertexToolActiveLayer',
            'actionVertexTool', 'mActionVertexTool',
            'actionNodeTool', 'mActionNodeTool',
            'NodeTool'
        ])
        
        act_vertex_all = self.find_action_by_name([
            'actionVertexTool', 'mActionVertexTool',
            'actionNodeTool', 'mActionNodeTool'
        ])

        act_panel = self.find_action_by_name([
            'actionVertexPanel', 'mActionVertexPanel', 'VertexPanel'
        ])

        if not act_vertex and not act_vertex_all:
            return None

        main_act = act_vertex if act_vertex else act_vertex_all

        menu_vertex = QMenu("Ferramenta Vértice", self.main_window)
        if act_vertex_all and act_vertex_all != main_act:
            menu_vertex.addAction(act_vertex_all)
        if main_act:
            menu_vertex.addAction(main_act)
        if act_panel:
            menu_vertex.addAction(act_panel)

        return (main_act, menu_vertex) if menu_vertex.actions() else main_act

    def build_all_advanced_digitizing_tools(self):
        """Retorna TODAS as ferramentas de Vetorização Avançada + Mesclar/Costurar Feições do QGIS."""
        adv_action_names = [
            'actionMoveFeature', 'actionRotateFeature', 'actionScaleFeature', 'actionSimplifyFeature',
            'actionAddRing', 'actionAddPart', 'actionFillRing', 'actionDeleteRing', 'actionDeletePart',
            'actionReshapeFeatures', 'actionOffsetCurve', 'actionReverseLine', 'actionSplitFeatures',
            'actionSplitParts',
            'actionMergeFeatures', 'mActionMergeFeatures', 'MergeFeatures',
            'actionMergeFeatureAttributes', 'mActionMergeFeatureAttributes'
        ]
        actions = []
        for name in adv_action_names:
            act = self.find_action_by_name(name)
            if act and act not in actions:
                actions.append(act)
        return actions

    def build_tab_edit(self):
        """Monta a aba Edição com rótulos compactos e Vetorização Avançada em 2 linhas empilhadas."""
        tab_edit = QWidget()
        lay_edit = QHBoxLayout(tab_edit)
        lay_edit.setContentsMargins(2, 2, 2, 2)
        lay_edit.setSpacing(2)

        # 1. Área de Transferência
        self.build_clipboard_group(lay_edit)

        # 2. Gerenciar Edição
        act_toggle = self.find_action_by_name('actionToggleEditing')
        act_save_edits = self.find_action_by_name('actionSaveEdits')
        act_open_table = self.find_action_by_name([
            'actionOpenTable', 'OpenTable', 'mActionOpenTable', 
            'actionShowAttributeTable', 'ShowAttributeTable', 'mActionShowAttributeTable'
        ])
        
        btn_toggle = self.build_btn(act_toggle, size=20, custom_text="Alternar Edição")
        btn_save_edits = self.build_btn(act_save_edits, size=20, custom_text="Salvar Camadas")
        btn_open_table = self.build_btn(act_open_table, size=20, custom_text="Tabela de Atributos")

        grp_manage = QGroupBox("Gerenciar Edição")
        lay_manage = QHBoxLayout(grp_manage)
        lay_manage.setContentsMargins(2, 2, 2, 2)
        lay_manage.setSpacing(2)
        if btn_toggle: lay_manage.addWidget(btn_toggle)
        if btn_save_edits: lay_manage.addWidget(btn_save_edits)
        if btn_open_table: lay_manage.addWidget(btn_open_table)
        lay_edit.addWidget(grp_manage)

        # 3. Bandeja de Seleção
        grp_sel = QGroupBox("Bandeja de Seleção")
        lay_sel = QHBoxLayout(grp_sel)
        lay_sel.setContentsMargins(2, 2, 2, 2)
        lay_sel.setSpacing(2)

        selection_items = self.build_complete_selection_group()
        if selection_items[0]:
            b0 = self.build_btn(selection_items[0], size=20, custom_text="Feição(s)")
            if b0: lay_sel.addWidget(b0)
        if selection_items[1]:
            b1 = self.build_btn(selection_items[1], size=20, custom_text="Expressão")
            if b1: lay_sel.addWidget(b1)
        if selection_items[2]:
            b2 = self.build_btn(selection_items[2], size=20, custom_text="Desfazer Seleção")
            if b2: lay_sel.addWidget(b2)
        lay_edit.addWidget(grp_sel)

        # 4. Criar / Deletar Feição
        grp_create = QGroupBox("Criar / Deletar Feição")
        lay_create = QHBoxLayout(grp_create)
        lay_create.setContentsMargins(2, 2, 2, 2)
        lay_create.setSpacing(2)

        act_add = self.find_action_by_name('actionAddFeature')
        act_del = self.find_action_by_name('actionDeleteSelected')
        node_tool_item = self.build_node_tool_item()

        b_add = self.build_btn(act_add, size=20, custom_text="Adicionar")
        b_del = self.build_btn(act_del, size=20, custom_text="Excluir")
        b_node = self.build_btn(node_tool_item, size=20, custom_text="Ferramenta Vértice")

        if b_add: lay_create.addWidget(b_add)
        if b_del: lay_create.addWidget(b_del)
        if b_node: lay_create.addWidget(b_node)
        lay_edit.addWidget(grp_create)

        # 5. Vetorização Avançada em 2 linhas empilhadas
        grp_adv = QGroupBox("Vetorização Avançada")
        lay_adv_v = QVBoxLayout(grp_adv)
        lay_adv_v.setContentsMargins(2, 2, 2, 2)
        lay_adv_v.setSpacing(1)

        lay_adv_row1 = QHBoxLayout()
        lay_adv_row1.setContentsMargins(0, 0, 0, 0)
        lay_adv_row1.setSpacing(1)

        lay_adv_row2 = QHBoxLayout()
        lay_adv_row2.setContentsMargins(0, 0, 0, 0)
        lay_adv_row2.setSpacing(1)

        adv_tools = self.build_all_advanced_digitizing_tools()
        half = (len(adv_tools) + 1) // 2

        for idx, t in enumerate(adv_tools):
            btn_t = self.build_btn(t, size=16, icon_only=True)
            if btn_t:
                btn_t.setToolTip(t.text().replace('&', ''))
                if idx < half:
                    lay_adv_row1.addWidget(btn_t)
                else:
                    lay_adv_row2.addWidget(btn_t)

        lay_adv_v.addLayout(lay_adv_row1)
        lay_adv_v.addLayout(lay_adv_row2)
        lay_edit.addWidget(grp_adv)

        lay_edit.addStretch()
        return tab_edit

    def safe_run_script(self, module_name, function_name="run"):
        try:
            full_module_name = f"{__package__}.scripts.{module_name}"
            if full_module_name in sys.modules:
                mod = importlib.reload(sys.modules[full_module_name])
            else:
                mod = importlib.import_module(full_module_name)
                
            func = getattr(mod, function_name, None)
            if func and callable(func):
                func()
            else:
                self.iface.messageBar().pushMessage("SecPlanBN", f"A função '{function_name}' não foi encontrada em '{module_name}.py'.", level=Qgis.Warning, duration=5)
        except Exception as e:
            self.iface.messageBar().pushMessage("SecPlanBN Error", f"Erro ao executar '{module_name}.py': {e}", level=Qgis.Critical, duration=6)

    def build_secplanbn_tab(self):
        tab_secplan = QWidget()
        lay_secplan = QHBoxLayout(tab_secplan)
        lay_secplan.setContentsMargins(4, 2, 4, 4)
        lay_secplan.setSpacing(4)

        icons_path = os.path.join(os.path.dirname(__file__), "icons")
        def get_icon(name):
            path = os.path.join(icons_path, name)
            return QIcon(path) if os.path.exists(path) else QIcon()

        act_select = self.find_action_by_name(['actionSelect', 'actionSelectFeatures', 'SelectFeatures', 'mActionSelect'])
        if act_select:
            self.add_group(lay_secplan, "Seleção", [act_select])

        # 1. Pesquisas Dinâmicas
        from .scripts.buscas import carregar_config_buscas, _executar_busca_generica, abrir_gerenciador_buscas

        menu_buscar = QMenu("Buscar", self.main_window)
        buscas_salvas = carregar_config_buscas()

        for b in buscas_salvas:
            act_b = QAction(b["titulo"], self.main_window)
            act_b.triggered.connect(lambda checked, busca=b: _executar_busca_generica(busca))
            menu_buscar.addAction(act_b)

        menu_buscar.addSeparator()

        act_gerenciar = QAction("⚙️ Gerenciar / Adicionar Buscas...", self.main_window)
        act_gerenciar.triggered.connect(abrir_gerenciador_buscas)
        menu_buscar.addAction(act_gerenciar)

        act_main_buscar = QAction(get_icon("lupa.svg"), "Buscar", self.main_window)
        self.add_group(lay_secplan, "Pesquisas", [(act_main_buscar, menu_buscar)], preserve_icon=True)

        # 2. Documentos REURB
        act_parecer = QAction("Gerar Parecer Loteamento", self.main_window)
        act_parecer.triggered.connect(lambda: self.safe_run_script("gerar_parecer"))
        act_crf = QAction("Gerar CRF", self.main_window)
        act_crf.triggered.connect(lambda: self.safe_run_script("reurb_crf"))
        act_infra = QAction("Gerar Relatório de Infraestrutura", self.main_window)
        act_infra.triggered.connect(lambda: self.safe_run_script("relatorio_infraestrutura"))
        menu_doc = QMenu("Gerar Documento", self.main_window)
        menu_doc.addAction(act_parecer)
        menu_doc.addAction(act_crf)
        menu_doc.addAction(act_infra)
        act_main_doc = QAction(get_icon("parecer.svg"), "Documentos", self.main_window)
        self.add_group(lay_secplan, "REURB e Pareceres", [(act_main_doc, menu_doc)], preserve_icon=True)

        # 3. Integração Betha
        act_puxar_id = QAction("Importar ID Betha", self.main_window)
        act_puxar_id.triggered.connect(lambda: self.safe_run_script("puxar_id_betha"))
        act_atualizar_banco = QAction("Atualizar Banco de Dados Betha", self.main_window)
        act_atualizar_banco.triggered.connect(lambda: self.safe_run_script("atualizar_banco_betha"))
        menu_betha = QMenu("Ferramentas Betha", self.main_window)
        menu_betha.addAction(act_puxar_id)
        menu_betha.addAction(act_atualizar_banco)
        act_main_betha = QAction(get_icon("id.svg"), "Betha ID", self.main_window)
        self.add_group(lay_secplan, "Integração Betha", [(act_main_betha, menu_betha)], preserve_icon=True)

        # 4. Numeração Predial
        act_cad_interativo = QAction("Cadastrar Número", self.main_window)
        act_cad_interativo.triggered.connect(lambda: self.safe_run_script("cadastro_num_tool", "ativar_modo_cadastro"))
        act_gerar_certidao = QAction("Gerar Certidão (Lote)", self.main_window)
        act_gerar_certidao.triggered.connect(lambda: self.safe_run_script("cadastro_num"))
        menu_num = QMenu("Cadastro de Números", self.main_window)
        menu_num.addAction(act_cad_interativo)
        menu_num.addAction(act_gerar_certidao)
        act_main_num = QAction(get_icon("cadastro_numero.svg"), "Numeração", self.main_window)
        self.add_group(lay_secplan, "Numeração Predial", [(act_main_num, menu_num)], preserve_icon=True)

        # 5. Utilitários
        act_foto = QAction(get_icon("foto.svg"), "Importar Fotos HEIC", self.main_window)
        act_foto.triggered.connect(lambda: self.safe_run_script("fotos_vistoria"))
        act_pdf = QAction(get_icon("exportar.svg"), "Exportar PDF", self.main_window)
        act_pdf.triggered.connect(lambda: self.safe_run_script("exportar_pdf"))
        act_viab = QAction(get_icon("viabilidade.svg"), "Consulta Prévia", self.main_window)
        act_viab.triggered.connect(lambda: self.safe_run_script("consulta_previa"))
        self.add_group(lay_secplan, "Utilitários Vistoria & Mapa", [act_foto, act_pdf, act_viab])

        lay_secplan.addStretch()
        return tab_secplan

    def build_insert_tab(self):
        tab = QWidget()
        lay = QHBoxLayout(tab)
        lay.setContentsMargins(4, 2, 4, 4)
        lay.setSpacing(4)

        self.add_group(lay, "Adicionar Camadas", [
            self.find_action_by_name(['actionAddOgrLayer', 'AddOgrLayer']),
            self.find_action_by_name(['actionAddRasterLayer', 'AddRasterLayer']),
            self.find_action_by_name(['actionAddPgisLayer', 'AddPgisLayer']),
            self.find_action_by_name(['actionAddWmsLayer', 'AddWmsLayer']),
            self.find_action_by_name(['actionAddXyzLayer', 'AddXyzLayer'])
        ])
        
        self.add_group(lay, "Criar Camadas", [
            self.find_action_by_name(['actionNewVectorLayer', 'NewVectorLayer']),
            self.find_action_by_name(['actionNewGeoPackageLayer', 'NewGeoPackageLayer']),
            self.find_action_by_name(['actionNewMemoryLayer', 'NewMemoryLayer'])
        ])

        lay.addStretch()
        return tab

    def build_analysis_tab(self):
        tab = QWidget()
        lay = QHBoxLayout(tab)
        lay.setContentsMargins(4, 2, 4, 4)
        lay.setSpacing(4)

        self.add_group(lay, "Geoprocessamento", [
            self.find_action_by_name(['actionBuffer', 'Buffer']),
            self.find_action_by_name(['actionClip', 'Clip']),
            self.find_action_by_name(['actionDissolve', 'Dissolve']),
            self.find_action_by_name(['actionIntersect', 'Intersect'])
        ])

        self.add_group(lay, "Investigação & Medição", [
            self.find_action_by_name(['actionMeasure', 'Measure']),
            self.find_action_by_name(['actionMeasureArea', 'MeasureArea']),
            self.find_action_by_name(['actionShowAttributeTable', 'ShowAttributeTable'])
        ])

        lay.addStretch()
        return tab

    def build_share_tab(self):
        tab = QWidget()
        lay = QHBoxLayout(tab)
        lay.setContentsMargins(4, 2, 4, 4)
        lay.setSpacing(4)

        self.add_group(lay, "Exportar Mapa", [
            self.find_action_by_name(['actionSaveMapAsImage', 'SaveMapAsImage']),
            self.find_action_by_name(['actionExportMapToPdf', 'ExportMapToPdf']),
            self.find_action_by_name(['actionNewLayout', 'NewLayout']),
            self.find_action_by_name(['actionShowLayoutManager', 'ShowLayoutManager'])
        ])

        self.add_group(lay, "Projeto & Estilos", [
            self.find_action_by_name(['actionSaveProject', 'SaveProject']),
            self.find_action_by_name(['actionSaveProjectAs', 'SaveProjectAs']),
            self.find_action_by_name(['actionStyleManager', 'StyleManager'])
        ])

        lay.addStretch()
        return tab

    def create_ribbon(self):
        ribbon_container = QWidget()
        container_layout = QHBoxLayout(ribbon_container)
        container_layout.setContentsMargins(0, 0, 0, 0)
        container_layout.setSpacing(0)

        quick_panel = self.create_quick_access_panel()
        container_layout.addWidget(quick_panel)

        ribbon_widget = QTabWidget()
        ribbon_widget.setFixedHeight(128)

        tab_edit = self.build_tab_edit()
        tab_secplan = self.build_secplanbn_tab()

        tab_map = QWidget()
        lay_map = QHBoxLayout(tab_map)
        lay_map.setContentsMargins(4, 2, 4, 4)
        self.add_group(lay_map, "Navegação", [
            self.find_action_by_name('actionPan'),
            self.find_action_by_name('actionZoomIn'),
            self.find_action_by_name('actionZoomOut'),
            self.find_action_by_name('actionZoomFullExtent'),
            self.find_action_by_name('actionZoomToSelected')
        ])
        self.add_group(lay_map, "Camada e Identificação", [
            self.find_action_by_name('actionAddLayer'),
            self.find_action_by_name('actionIdentify')
        ])
        self.add_group(lay_map, "Consultas e Medição", [
            self.find_action_by_name('actionMeasure'),
            self.find_action_by_name('actionMeasureArea')
        ])
        lay_map.addStretch()

        tab_insert = self.build_insert_tab()
        tab_analysis = self.build_analysis_tab()
        tab_share = self.build_share_tab()

        # Marca d'água da logo no corpo inferior direito das abas
        logo_path = os.path.join(os.path.dirname(__file__), "icons", "LOGO - simplificada.jpg")
        
        def adicionar_logo_na_aba(tab_widget):
            if not os.path.exists(logo_path):
                return
            lay = tab_widget.layout()
            if lay:
                lbl_logo = QLabel()
                pixmap = QPixmap(logo_path)
                pixmap_scaled = pixmap.scaledToHeight(85, Qt.SmoothTransformation)
                lbl_logo.setPixmap(pixmap_scaled)
                lbl_logo.setAlignment(Qt.AlignCenter)
                lbl_logo.setStyleSheet("background: transparent; padding-left: 10px; padding-right: 8px;")

                opacity = QGraphicsOpacityEffect(lbl_logo)
                opacity.setOpacity(0.35)
                lbl_logo.setGraphicsEffect(opacity)

                lay.addWidget(lbl_logo)

        for tab in [tab_edit, tab_secplan, tab_map, tab_insert, tab_analysis, tab_share]:
            adicionar_logo_na_aba(tab)

        ribbon_widget.addTab(tab_edit, "Edição")
        ribbon_widget.addTab(tab_secplan, "SecPlanBN")
        ribbon_widget.addTab(tab_map, "Mapa")
        ribbon_widget.addTab(tab_insert, "Inserir")
        ribbon_widget.addTab(tab_analysis, "Análise")
        ribbon_widget.addTab(tab_share, "Compartilhar")

        container_layout.addWidget(ribbon_widget)

        self.ribbon_toolbar = QToolBar("ArcGIS Ribbon")
        self.ribbon_toolbar.setObjectName("ArcGISRibbonToolBar")
        self.ribbon_toolbar.setMovable(False)
        self.ribbon_toolbar.addWidget(ribbon_container)

        existing_toolbars = [
            tb for tb in self.main_window.findChildren(QToolBar) 
            if self.main_window.toolBarArea(tb) == Qt.TopToolBarArea and tb.isVisible()
        ]

        if existing_toolbars:
            first_tb = existing_toolbars[0]
            self.main_window.insertToolBar(first_tb, self.ribbon_toolbar)
            self.main_window.insertToolBarBreak(first_tb)
        else:
            self.main_window.addToolBar(Qt.TopToolBarArea, self.ribbon_toolbar)

    def unload(self):
        self.main_window.setStyleSheet("")
        if self.ribbon_toolbar:
            self.main_window.removeToolBar(self.ribbon_toolbar)
            self.ribbon_toolbar.deleteLater()